const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "customer_alice";
const BOB_UID = "customer_bob";
const OWNER_UID = "owner_admin_123";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

// 1. Unauthenticated Visitor Tests
test("Visitor (Unauthenticated): Can read published products", async () => {
  await testEnv.withSecurityRulesDisabled(async (context) => {
    await context.firestore().collection("products").doc("p1").set({
      title: "Festive Kurti",
      brand: "ApnaBrand",
      category: "kurtis",
      price: 699,
      stockQuantity: 10
    });
  });

  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertSucceeds(unauthDb.collection("products").doc("p1").get());
});

test("Visitor (Unauthenticated): Cannot create or edit products", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("products").doc("p2").set({
    title: "Unauthorized Product",
    price: 99
  }));
});

test("Visitor (Unauthenticated): Cannot read customer orders", async () => {
  await testEnv.withSecurityRulesDisabled(async (context) => {
    await context.firestore().collection("orders").doc("ord_1").set({
      customerId: ALICE_UID,
      finalAmount: 1299,
      currentStatus: "CONFIRMED"
    });
  });

  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("orders").doc("ord_1").get());
});

// 2. Normal Customer Access Control Tests
test("Customer: Cannot promote themselves to admin or write /admins", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertFails(aliceDb.collection("admins").doc(ALICE_UID).set({
    role: "owner",
    email: "alice@example.com"
  }));
});

test("Customer: Cannot add, edit, or delete products", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertFails(aliceDb.collection("products").doc("p_alice").set({
    title: "Hacked Product",
    price: 1
  }));
});

test("Customer: Can create and read their own order", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertSucceeds(aliceDb.collection("orders").doc("ord_alice").set({
    customerId: ALICE_UID,
    finalAmount: 999,
    currentStatus: "CONFIRMED"
  }));

  await assertSucceeds(aliceDb.collection("orders").doc("ord_alice").get());
});

test("Customer: Cannot read Bob's private order", async () => {
  await testEnv.withSecurityRulesDisabled(async (context) => {
    await context.firestore().collection("orders").doc("ord_bob").set({
      customerId: BOB_UID,
      finalAmount: 2499,
      currentStatus: "CONFIRMED"
    });
  });

  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertFails(aliceDb.collection("orders").doc("ord_bob").get());
});

test("Customer: Cannot read or write Bob's cart or addresses", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertFails(aliceDb.collection("users").doc(BOB_UID).collection("addresses").doc("addr1").get());
  await assertFails(aliceDb.collection("users").doc(BOB_UID).collection("cart").doc("c1").set({ productId: "p1" }));
});

// 3. Authorized Owner / Admin Tests
test("Authorized Owner: Can add products, view all orders, and update fulfillment", async () => {
  // Provision owner admin in /admins/{OWNER_UID} via backend setup
  await testEnv.withSecurityRulesDisabled(async (context) => {
    await context.firestore().collection("admins").doc(OWNER_UID).set({
      role: "owner",
      email: "owner@apnacart.com"
    });
    await context.firestore().collection("orders").doc("ord_bob").set({
      customerId: BOB_UID,
      finalAmount: 2499,
      currentStatus: "CONFIRMED"
    });
  });

  const ownerDb = testEnv.authenticatedContext(OWNER_UID).firestore();

  // Owner adds product
  await assertSucceeds(ownerDb.collection("products").doc("p_admin").set({
    id: "p_admin",
    title: "Official Brand Silk Saree",
    brand: "Kanjivaram",
    category: "sarees",
    price: 2499,
    originalMrp: 4999,
    stockQuantity: 20
  }));

  // Owner reads Bob's order for fulfillment
  await assertSucceeds(ownerDb.collection("orders").doc("ord_bob").get());

  // Owner updates order fulfillment status
  await assertSucceeds(ownerDb.collection("orders").doc("ord_bob").update({
    currentStatus: "SHIPPED",
    awbNumber: "DEL123456"
  }));
});
