package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.LocalOffer
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppNotification
import com.example.ui.theme.ApnaActionOrange
import com.example.ui.theme.ApnaBlueContainer
import com.example.ui.theme.ApnaBlueDark
import com.example.ui.theme.ApnaBluePrimary
import com.example.ui.viewmodel.ApnaCartViewModel

@Composable
fun NotificationsScreen(
  viewModel: ApnaCartViewModel,
  onBack: () -> Unit,
  onNavigateToOrders: () -> Unit,
  onNavigateToOffers: () -> Unit,
  modifier: Modifier = Modifier
) {
  BackHandler { onBack() }

  val notifications by viewModel.notifications.collectAsState()

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
  ) {
    // Top Bar
    Surface(
      color = ApnaBluePrimary,
      tonalElevation = 4.dp,
      modifier = Modifier.fillMaxWidth()
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .statusBarsPadding()
          .padding(horizontal = 8.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        IconButton(onClick = onBack, modifier = Modifier.testTag("notifs_back_btn")) {
          Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
        }
        Text(
          text = "Notifications & Order Alerts",
          fontSize = 17.sp,
          fontWeight = FontWeight.Bold,
          color = Color.White
        )
      }
    }

    if (notifications.isEmpty()) {
      Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
      ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Icon(
            imageVector = Icons.Default.Notifications,
            contentDescription = null,
            tint = Color.LightGray,
            modifier = Modifier.size(56.dp)
          )
          Spacer(modifier = Modifier.height(12.dp))
          Text(text = "No notifications yet", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
          Text(text = "Order and delivery alerts will appear here", fontSize = 12.sp, color = Color.Gray)
        }
      }
    } else {
      LazyColumn(
        modifier = Modifier
          .fillMaxSize()
          .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        items(notifications, key = { it.id }) { notif ->
          val icon = when (notif.type) {
            "ORDER" -> Icons.Default.LocalShipping
            "OFFER" -> Icons.Default.LocalOffer
            "AUTH" -> Icons.Default.Security
            else -> Icons.Default.Notifications
          }

          val iconColor = when (notif.type) {
            "ORDER" -> ApnaBluePrimary
            "OFFER" -> ApnaActionOrange
            "AUTH" -> Color(0xFF2E7D32)
            else -> ApnaBluePrimary
          }

          Card(
            shape = RoundedCornerShape(10.dp),
            colors = CardDefaults.cardColors(
              containerColor = if (notif.isRead) MaterialTheme.colorScheme.surface else Color.White
            ),
            elevation = CardDefaults.cardElevation(defaultElevation = if (notif.isRead) 1.dp else 3.dp),
            modifier = Modifier
              .fillMaxWidth()
              .clickable {
                viewModel.markNotificationRead(notif.id)
                if (notif.type == "ORDER") onNavigateToOrders()
                if (notif.type == "OFFER") onNavigateToOffers()
              }
              .testTag("notif_card_${notif.id}")
          ) {
            Row(
              modifier = Modifier.padding(14.dp),
              verticalAlignment = Alignment.Top
            ) {
              Box(
                modifier = Modifier
                  .size(38.dp)
                  .clip(CircleShape)
                  .background(iconColor.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
              ) {
                Icon(imageVector = icon, contentDescription = null, tint = iconColor, modifier = Modifier.size(20.dp))
              }

              Spacer(modifier = Modifier.width(12.dp))

              Column(modifier = Modifier.weight(1f)) {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Text(
                    text = notif.title,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                  )
                  if (!notif.isRead) {
                    Box(
                      modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(ApnaActionOrange)
                    )
                  }
                }

                Spacer(modifier = Modifier.height(3.dp))
                Text(
                  text = notif.message,
                  fontSize = 12.sp,
                  color = Color.DarkGray,
                  lineHeight = 16.sp
                )

                Spacer(modifier = Modifier.height(6.dp))
                Text(
                  text = notif.timestamp,
                  fontSize = 10.sp,
                  color = Color.Gray
                )
              }
            }
          }
        }
      }
    }
  }
}
