package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LocalOffer
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.GridView
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.LocalOffer
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.ShoppingBag
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.model.ApnaStrings
import com.example.ui.components.ApnaTopBar
import com.example.ui.theme.ApnaActionOrange
import com.example.ui.theme.ApnaBlueContainer
import com.example.ui.theme.ApnaBluePrimary
import com.example.ui.viewmodel.ApnaCartViewModel
import com.example.ui.viewmodel.MainTab
import com.example.ui.viewmodel.ScreenDestination

@Composable
fun MainScreen(
  viewModel: ApnaCartViewModel,
  modifier: Modifier = Modifier
) {
  val currentScreen by viewModel.currentScreen.collectAsState()
  val currentTab by viewModel.currentTab.collectAsState()
  val wishlistIds by viewModel.wishlistIds.collectAsState()
  val cartItems by viewModel.cartItems.collectAsState()
  val deliveryPincode by viewModel.deliveryPincode.collectAsState()
  val currentLanguage by viewModel.currentLanguage.collectAsState()
  val isOnline by viewModel.isOnline.collectAsState()

  val snackbarHostState = remember { SnackbarHostState() }

  LaunchedEffect(Unit) {
    viewModel.toastEvent.collect { message ->
      snackbarHostState.showSnackbar(message)
    }
  }

  val isTabScreen = currentScreen is ScreenDestination.MainTabs

  Scaffold(
    topBar = {
      Column(modifier = Modifier.fillMaxWidth()) {
        if (!isOnline) {
          Surface(
            color = Color(0xFFC62828), // High-visibility red
            modifier = Modifier.fillMaxWidth().testTag("offline_network_banner")
          ) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 14.dp, vertical = 6.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(
                imageVector = Icons.Default.CloudOff,
                contentDescription = "Offline Mode",
                tint = Color.White,
                modifier = Modifier.size(16.dp)
              )
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = "No Internet Connection • Running in Offline Mode with Cached Catalog",
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color.White
              )
            }
          }
        }

        if (isTabScreen && currentTab != MainTab.CART) {
          ApnaTopBar(
            deliveryPincode = deliveryPincode,
            currentLanguage = currentLanguage,
            wishlistCount = wishlistIds.size,
            cartCount = cartItems.size,
            onLanguageToggle = {
              val nextLang = if (currentLanguage == AppLanguage.ENGLISH) AppLanguage.HINDI else AppLanguage.ENGLISH
              viewModel.setLanguage(nextLang)
            },
            onPincodeClick = {
              viewModel.navigateTo(ScreenDestination.AddressManager)
            },
            onWishlistClick = {
              viewModel.setTab(MainTab.WISHLIST)
            },
            onCartClick = {
              viewModel.setTab(MainTab.CART)
            },
            onAiAssistantClick = {
              viewModel.navigateTo(ScreenDestination.AiAssistant)
            }
          )
        }
      }
    },
    bottomBar = {
      if (isTabScreen) {
        NavigationBar(
          containerColor = MaterialTheme.colorScheme.surface,
          tonalElevation = 8.dp,
          modifier = Modifier
            .navigationBarsPadding()
            .testTag("main_bottom_nav_bar")
        ) {
          // 1. Home Tab
          NavigationBarItem(
            selected = currentTab == MainTab.HOME,
            onClick = { viewModel.setTab(MainTab.HOME) },
            icon = {
              Icon(
                imageVector = if (currentTab == MainTab.HOME) Icons.Filled.Home else Icons.Outlined.Home,
                contentDescription = ApnaStrings.get(currentLanguage, "tab_home")
              )
            },
            label = {
              Text(
                text = ApnaStrings.get(currentLanguage, "tab_home"),
                fontSize = 10.sp,
                maxLines = 1,
                fontWeight = if (currentTab == MainTab.HOME) FontWeight.Bold else FontWeight.Normal
              )
            },
            colors = NavigationBarItemDefaults.colors(
              selectedIconColor = ApnaBluePrimary,
              selectedTextColor = ApnaBluePrimary,
              indicatorColor = ApnaBlueContainer,
              unselectedIconColor = Color(0xFF717478),
              unselectedTextColor = Color(0xFF717478)
            ),
            modifier = Modifier.testTag("nav_tab_home")
          )

          // 2. Categories Tab
          NavigationBarItem(
            selected = currentTab == MainTab.CATEGORIES,
            onClick = { viewModel.setTab(MainTab.CATEGORIES) },
            icon = {
              Icon(
                imageVector = if (currentTab == MainTab.CATEGORIES) Icons.Filled.GridView else Icons.Outlined.GridView,
                contentDescription = ApnaStrings.get(currentLanguage, "tab_categories")
              )
            },
            label = {
              Text(
                text = ApnaStrings.get(currentLanguage, "tab_categories"),
                fontSize = 10.sp,
                maxLines = 1,
                fontWeight = if (currentTab == MainTab.CATEGORIES) FontWeight.Bold else FontWeight.Normal
              )
            },
            colors = NavigationBarItemDefaults.colors(
              selectedIconColor = ApnaBluePrimary,
              selectedTextColor = ApnaBluePrimary,
              indicatorColor = ApnaBlueContainer,
              unselectedIconColor = Color(0xFF717478),
              unselectedTextColor = Color(0xFF717478)
            ),
            modifier = Modifier.testTag("nav_tab_categories")
          )

          // 3. Offers Tab
          NavigationBarItem(
            selected = currentTab == MainTab.OFFERS,
            onClick = { viewModel.setTab(MainTab.OFFERS) },
            icon = {
              Icon(
                imageVector = if (currentTab == MainTab.OFFERS) Icons.Filled.LocalOffer else Icons.Outlined.LocalOffer,
                contentDescription = ApnaStrings.get(currentLanguage, "tab_offers")
              )
            },
            label = {
              Text(
                text = ApnaStrings.get(currentLanguage, "tab_offers"),
                fontSize = 10.sp,
                maxLines = 1,
                fontWeight = if (currentTab == MainTab.OFFERS) FontWeight.Bold else FontWeight.Normal
              )
            },
            colors = NavigationBarItemDefaults.colors(
              selectedIconColor = ApnaBluePrimary,
              selectedTextColor = ApnaBluePrimary,
              indicatorColor = ApnaBlueContainer,
              unselectedIconColor = Color(0xFF717478),
              unselectedTextColor = Color(0xFF717478)
            ),
            modifier = Modifier.testTag("nav_tab_offers")
          )

          // 4. Wishlist Tab
          NavigationBarItem(
            selected = currentTab == MainTab.WISHLIST,
            onClick = { viewModel.setTab(MainTab.WISHLIST) },
            icon = {
              BadgedBox(
                badge = {
                  if (wishlistIds.isNotEmpty()) {
                    Badge(
                      containerColor = ApnaActionOrange,
                      contentColor = Color.White
                    ) {
                      Text("${wishlistIds.size}")
                    }
                  }
                }
              ) {
                Icon(
                  imageVector = if (currentTab == MainTab.WISHLIST) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                  contentDescription = ApnaStrings.get(currentLanguage, "tab_wishlist")
                )
              }
            },
            label = {
              Text(
                text = ApnaStrings.get(currentLanguage, "tab_wishlist"),
                fontSize = 10.sp,
                maxLines = 1,
                fontWeight = if (currentTab == MainTab.WISHLIST) FontWeight.Bold else FontWeight.Normal
              )
            },
            colors = NavigationBarItemDefaults.colors(
              selectedIconColor = ApnaBluePrimary,
              selectedTextColor = ApnaBluePrimary,
              indicatorColor = ApnaBlueContainer,
              unselectedIconColor = Color(0xFF717478),
              unselectedTextColor = Color(0xFF717478)
            ),
            modifier = Modifier.testTag("nav_tab_wishlist")
          )

          // 5. Cart Tab
          NavigationBarItem(
            selected = currentTab == MainTab.CART,
            onClick = { viewModel.setTab(MainTab.CART) },
            icon = {
              BadgedBox(
                badge = {
                  if (cartItems.isNotEmpty()) {
                    Badge(
                      containerColor = ApnaActionOrange,
                      contentColor = Color.White
                    ) {
                      Text("${cartItems.size}")
                    }
                  }
                }
              ) {
                Icon(
                  imageVector = if (currentTab == MainTab.CART) Icons.Filled.ShoppingBag else Icons.Outlined.ShoppingBag,
                  contentDescription = ApnaStrings.get(currentLanguage, "tab_cart")
                )
              }
            },
            label = {
              Text(
                text = ApnaStrings.get(currentLanguage, "tab_cart"),
                fontSize = 10.sp,
                maxLines = 1,
                fontWeight = if (currentTab == MainTab.CART) FontWeight.Bold else FontWeight.Normal
              )
            },
            colors = NavigationBarItemDefaults.colors(
              selectedIconColor = ApnaBluePrimary,
              selectedTextColor = ApnaBluePrimary,
              indicatorColor = ApnaBlueContainer,
              unselectedIconColor = Color(0xFF717478),
              unselectedTextColor = Color(0xFF717478)
            ),
            modifier = Modifier.testTag("nav_tab_cart")
          )

          // 6. Profile / Account Tab
          NavigationBarItem(
            selected = currentTab == MainTab.PROFILE,
            onClick = { viewModel.setTab(MainTab.PROFILE) },
            icon = {
              Icon(
                imageVector = if (currentTab == MainTab.PROFILE) Icons.Filled.Person else Icons.Outlined.Person,
                contentDescription = ApnaStrings.get(currentLanguage, "tab_profile")
              )
            },
            label = {
              Text(
                text = ApnaStrings.get(currentLanguage, "tab_profile"),
                fontSize = 10.sp,
                maxLines = 1,
                fontWeight = if (currentTab == MainTab.PROFILE) FontWeight.Bold else FontWeight.Normal
              )
            },
            colors = NavigationBarItemDefaults.colors(
              selectedIconColor = ApnaBluePrimary,
              selectedTextColor = ApnaBluePrimary,
              indicatorColor = ApnaBlueContainer,
              unselectedIconColor = Color(0xFF717478),
              unselectedTextColor = Color(0xFF717478)
            ),
            modifier = Modifier.testTag("nav_tab_profile")
          )
        }
      }
    },
    snackbarHost = { SnackbarHost(snackbarHostState) },
    contentWindowInsets = WindowInsets(0, 0, 0, 0),
    modifier = modifier.fillMaxSize()
  ) { innerPadding ->
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
    ) {
      when (val screen = currentScreen) {
        is ScreenDestination.MainTabs -> {
          when (currentTab) {
            MainTab.HOME -> {
              HomeScreen(
                viewModel = viewModel,
                onProductClick = { product ->
                  viewModel.navigateTo(ScreenDestination.ProductDetail(product))
                }
              )
            }
            MainTab.CATEGORIES -> {
              CategoriesScreen(viewModel = viewModel)
            }
            MainTab.OFFERS -> {
              OffersScreen(viewModel = viewModel)
            }
            MainTab.WISHLIST -> {
              WishlistScreen(
                viewModel = viewModel,
                onProductClick = { product ->
                  viewModel.navigateTo(ScreenDestination.ProductDetail(product))
                }
              )
            }
            MainTab.CART -> {
              CartScreen(
                viewModel = viewModel,
                onProceedToCheckout = {
                  viewModel.navigateTo(ScreenDestination.Checkout)
                },
                onExploreProducts = {
                  viewModel.setTab(MainTab.HOME)
                }
              )
            }
            MainTab.PROFILE -> {
              ProfileScreen(
                viewModel = viewModel,
                onNavigateToOrders = {
                  viewModel.navigateTo(ScreenDestination.OrderHistory)
                },
                onNavigateToAddresses = {
                  viewModel.navigateTo(ScreenDestination.AddressManager)
                },
                onNavigateToAdmin = {
                  viewModel.navigateTo(ScreenDestination.DemoAdmin)
                },
                onNavigateToEditProfile = {
                  viewModel.navigateTo(ScreenDestination.EditProfile)
                },
                onNavigateToWallet = {
                  viewModel.navigateTo(ScreenDestination.WalletScreen)
                },
                onNavigateToRewards = {
                  viewModel.navigateTo(ScreenDestination.RewardsScreen)
                },
                onNavigateToReferral = {
                  viewModel.navigateTo(ScreenDestination.ReferralScreen)
                },
                onNavigateToLoyalty = {
                  viewModel.navigateTo(ScreenDestination.LoyaltyScreen)
                }
              )
            }
          }
        }
        is ScreenDestination.Splash -> {
          SplashScreen(
            onSplashFinished = {
              viewModel.dismissSplash()
            }
          )
        }
        is ScreenDestination.AiAssistant -> {
          AiShoppingAssistantScreen(
            viewModel = viewModel,
            onBack = { viewModel.navigateBack() },
            onProductClick = { product ->
              viewModel.navigateTo(ScreenDestination.ProductDetail(product))
            }
          )
        }
        is ScreenDestination.WalletScreen, is ScreenDestination.GiftCardsScreen -> {
          WalletScreen(
            viewModel = viewModel,
            onBack = { viewModel.navigateBack() }
          )
        }
        is ScreenDestination.RewardsScreen -> {
          RewardsScreen(
            viewModel = viewModel,
            onBack = { viewModel.navigateBack() }
          )
        }
        is ScreenDestination.PhotoSearchScreen -> {
          PhotoSearchScreen(
            viewModel = viewModel,
            onBack = { viewModel.navigateBack() },
            onProductClick = { product ->
              viewModel.navigateTo(ScreenDestination.ProductDetail(product))
            }
          )
        }
        is ScreenDestination.ReferralScreen -> {
          ReferralScreen(
            viewModel = viewModel,
            onBack = { viewModel.navigateBack() }
          )
        }
        is ScreenDestination.LoyaltyScreen -> {
          LoyaltyScreen(
            viewModel = viewModel,
            onBack = { viewModel.navigateBack() }
          )
        }
        is ScreenDestination.ProductDetail -> {
          ProductDetailScreen(
            product = screen.product,
            viewModel = viewModel,
            onBack = { viewModel.navigateBack() },
            onGoToCart = {
              viewModel.setTab(MainTab.CART)
            }
          )
        }
        is ScreenDestination.Checkout -> {
          CheckoutScreen(
            viewModel = viewModel,
            onBack = { viewModel.navigateBack() },
            onAddNewAddressClick = {
              viewModel.navigateTo(ScreenDestination.AddressManager)
            }
          )
        }
        is ScreenDestination.OrderPlacedSuccess -> {
          OrderSuccessScreen(
            order = screen.order,
            onTrackOrder = { orderId ->
              viewModel.navigateTo(ScreenDestination.OrderTracking(orderId))
            },
            onContinueShopping = {
              viewModel.setTab(MainTab.HOME)
            }
          )
        }
        is ScreenDestination.OrderTracking -> {
          OrderTrackingScreen(
            orderId = screen.orderId,
            viewModel = viewModel,
            onBack = { viewModel.navigateBack() }
          )
        }
        is ScreenDestination.OrderHistory -> {
          OrderHistoryScreen(
            viewModel = viewModel,
            onBack = { viewModel.navigateBack() },
            onTrackOrder = { orderId ->
              viewModel.navigateTo(ScreenDestination.OrderTracking(orderId))
            }
          )
        }
        is ScreenDestination.AddressManager -> {
          AddressManagerScreen(
            viewModel = viewModel,
            onBack = { viewModel.navigateBack() }
          )
        }
        is ScreenDestination.DemoAdmin -> {
          DemoAdminScreen(
            viewModel = viewModel,
            onBack = { viewModel.navigateBack() }
          )
        }
        is ScreenDestination.EditProfile -> {
          EditProfileScreen(
            viewModel = viewModel,
            onBack = { viewModel.navigateBack() }
          )
        }
        is ScreenDestination.Notifications -> {
          NotificationsScreen(
            viewModel = viewModel,
            onBack = { viewModel.navigateBack() },
            onNavigateToOrders = { viewModel.navigateTo(ScreenDestination.OrderHistory) },
            onNavigateToOffers = { viewModel.setTab(MainTab.OFFERS) }
          )
        }
        is ScreenDestination.OtpLogin -> {
          OtpLoginScreen(
            viewModel = viewModel,
            onBack = { viewModel.navigateBack() },
            onLoginSuccess = { viewModel.navigateBack() }
          )
        }
      }
    }
  }
}
