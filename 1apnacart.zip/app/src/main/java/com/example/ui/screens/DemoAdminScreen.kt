package com.example.ui.screens

import android.util.Log
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import android.content.Intent
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.QuestionAnswer
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.credentials.CredentialManager
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import com.example.R
import com.example.data.DemoDataProvider
import com.example.model.*
import com.example.ui.theme.ApnaActionOrange
import com.example.ui.theme.ApnaBlueContainer
import com.example.ui.theme.ApnaBlueDark
import com.example.ui.theme.ApnaBluePrimary
import com.example.ui.theme.ApnaDiscountGreen
import com.example.ui.viewmodel.ApnaCartViewModel
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.auth.GoogleAuthProvider
import java.util.UUID
import kotlinx.coroutines.launch

@Composable
fun DemoAdminScreen(
  viewModel: ApnaCartViewModel,
  onBack: () -> Unit,
  modifier: Modifier = Modifier
) {
  BackHandler { onBack() }

  val context = LocalContext.current
  val coroutineScope = rememberCoroutineScope()

  val isAdminAuthenticated by viewModel.isAdminAuthenticated.collectAsState()
  val adminStatus by viewModel.adminStatus.collectAsState()
  val firebaseUser by viewModel.firebaseUser.collectAsState()
  val products by viewModel.products.collectAsState()
  val orders by viewModel.orders.collectAsState()
  val coupons by viewModel.availableCoupons.collectAsState()
  val storeSettings by viewModel.storeSettings.collectAsState()
  val giftCards by viewModel.giftCards.collectAsState()
  val productQuestions by viewModel.productQuestions.collectAsState()
  val fraudAlerts by viewModel.fraudAlerts.collectAsState()

  var selectedAdminTab by remember { mutableIntStateOf(0) } // 0: Overview, 1: Products, 2: Orders, 3: Offers, 4: Operations, 5: Settings
  var isSigningIn by remember { mutableStateOf(false) }

  // Operations Form State
  var newGiftCardCode by remember { mutableStateOf("APNA${(1000..9999).random()}") }
  var newGiftCardAmount by remember { mutableStateOf("500") }
  var answeringQuestionId by remember { mutableStateOf<String?>(null) }
  var questionAnswerText by remember { mutableStateOf("") }

  // Add Product Form State
  var showAddProductDialog by remember { mutableStateOf(false) }
  var newTitle by remember { mutableStateOf("") }
  var newBrand by remember { mutableStateOf("") }
  var newCategory by remember { mutableStateOf("jeans") }
  var newPrice by remember { mutableStateOf("799") }
  var newMrp by remember { mutableStateOf("1599") }
  var newStock by remember { mutableStateOf("15") }
  var newDesc by remember { mutableStateOf("Premium Indian fabric tailored for daily festive and casual comfort.") }

  // Quick edit stock/price state
  var editingProductId by remember { mutableStateOf<String?>(null) }
  var editPriceText by remember { mutableStateOf("") }
  var editStockText by remember { mutableStateOf("") }

  // Add Coupon Form State
  var showAddCouponDialog by remember { mutableStateOf(false) }
  var newCouponCode by remember { mutableStateOf("") }
  var newCouponVal by remember { mutableStateOf("150") }
  var newCouponMin by remember { mutableStateOf("499") }

  // Settings State
  var upiEnabled by remember(storeSettings) { mutableStateOf(storeSettings.upiEnabled) }
  var codEnabled by remember(storeSettings) { mutableStateOf(storeSettings.codEnabled) }
  var cardsEnabled by remember(storeSettings) { mutableStateOf(storeSettings.cardsEnabled) }
  var partner by remember(storeSettings) { mutableStateOf(storeSettings.courierPartner) }
  var shippingFee by remember(storeSettings) { mutableStateOf("${storeSettings.standardShippingFee}") }
  var freeThreshold by remember(storeSettings) { mutableStateOf("${storeSettings.freeShippingThreshold}") }

  fun handleAdminGoogleSignIn() {
    isSigningIn = true
    coroutineScope.launch {
      try {
        val credentialManager = CredentialManager.create(context)
        val googleIdOption = GetSignInWithGoogleOption.Builder(
          context.getString(R.string.default_web_client_id)
        ).build()

        val request = GetCredentialRequest.Builder()
          .addCredentialOption(googleIdOption)
          .build()

        val result = credentialManager.getCredential(
          request = request,
          context = context
        )

        val googleIdTokenCredential = GoogleIdTokenCredential.createFrom(result.credential.data)
        val credential = GoogleAuthProvider.getCredential(googleIdTokenCredential.idToken, null)
        viewModel.signInWithGoogleCredential(credential)
      } catch (e: GetCredentialCancellationException) {
        Log.w("AdminScreen", "Google sign-in was cancelled by user")
      } catch (e: Exception) {
        Log.e("AdminScreen", "Google sign-in error", e)
      } finally {
        isSigningIn = false
      }
    }
  }

  // 1. GATE CHECK: If not authenticated or not authorized in Firestore /admins
  if (!isAdminAuthenticated) {
    Column(
      modifier = modifier
        .fillMaxSize()
        .background(MaterialTheme.colorScheme.background)
    ) {
      Surface(
        color = Color(0xFF0F172A),
        tonalElevation = 4.dp,
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(horizontal = 8.dp, vertical = 8.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          IconButton(onClick = onBack, modifier = Modifier.testTag("admin_gate_back_btn")) {
            Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
          }
          Text(text = "Protected Owner Administration", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Color.White)
        }
      }

      LazyColumn(
        modifier = Modifier
          .fillMaxSize()
          .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
      ) {
        item {
          Spacer(modifier = Modifier.height(10.dp))
          Box(
            modifier = Modifier
              .size(72.dp)
              .clip(CircleShape)
              .background(Color(0xFFFEF2F2)),
            contentAlignment = Alignment.Center
          ) {
            Icon(imageVector = Icons.Default.Lock, contentDescription = "Security Lock", tint = Color(0xFFDC2626), modifier = Modifier.size(36.dp))
          }
        }

        item {
          Text(
            text = "Owner Authorization Required",
            fontSize = 19.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF0F172A)
          )
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = "This administrative portal is restricted exclusively to the store owner authorized in Firebase Cloud Firestore.",
            fontSize = 12.sp,
            color = Color.Gray,
            lineHeight = 16.sp
          )
        }

        item {
          Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(16.dp)) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = Icons.Default.Security, contentDescription = null, tint = ApnaBluePrimary, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = "Identity & Role Verification", fontSize = 14.sp, fontWeight = FontWeight.Bold)
              }

              Spacer(modifier = Modifier.height(10.dp))

              if (firebaseUser == null) {
                Text(
                  text = "Please sign in with your authorized Google Account. Access is checked server-side against the protected '/admins' Firestore collection.",
                  fontSize = 12.sp,
                  color = Color.DarkGray,
                  lineHeight = 16.sp
                )

                Spacer(modifier = Modifier.height(14.dp))

                Button(
                  onClick = { handleAdminGoogleSignIn() },
                  enabled = !isSigningIn,
                  colors = ButtonDefaults.buttonColors(containerColor = ApnaBluePrimary),
                  shape = RoundedCornerShape(8.dp),
                  modifier = Modifier.fillMaxWidth().height(46.dp).testTag("admin_google_signin_btn")
                ) {
                  if (isSigningIn) {
                    CircularProgressIndicator(color = Color.White, modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Verifying Credentials...")
                  } else {
                    Text("Sign in with Google to Verify Owner", fontWeight = FontWeight.Bold)
                  }
                }
              } else {
                Text(text = "Signed in: ${firebaseUser?.email}", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = ApnaBlueDark)
                Text(text = "Firebase UID: ${firebaseUser?.uid}", fontSize = 11.sp, color = Color.Gray)

                Spacer(modifier = Modifier.height(10.dp))

                Box(
                  modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color(0xFFFEF2F2))
                    .padding(10.dp)
                ) {
                  Text(
                    text = "Access Denied: This account is authenticated as a customer but does not have verified owner permissions in Cloud Firestore.",
                    fontSize = 11.sp,
                    color = Color(0xFF991B1B),
                    fontWeight = FontWeight.SemiBold,
                    lineHeight = 15.sp
                  )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                  onClick = { viewModel.logoutCustomer() },
                  colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE2E8F0)),
                  shape = RoundedCornerShape(6.dp),
                  modifier = Modifier.fillMaxWidth().height(38.dp)
                ) {
                  Text("Sign Out & Use Different Account", color = Color(0xFF334155), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
              }
            }
          }
        }

        // Setup Instructions for Development
        item {
          Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFF1F5F9)),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(14.dp)) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = Icons.Default.Info, contentDescription = null, tint = ApnaBluePrimary, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(text = "Owner Setup Instructions (Firebase Console)", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = ApnaBlueDark)
              }

              Spacer(modifier = Modifier.height(6.dp))
              Text(
                text = "To grant administrative access to your account:\n" +
                  "1. Open Firebase Console for project 'gen-lang-client-0725307653'.\n" +
                  "2. Go to Cloud Firestore Database.\n" +
                  "3. In collection 'admins', create a document:\n" +
                  "   • Document ID: ${firebaseUser?.uid ?: "<Your Google Account UID>"}\n" +
                  "   • Field 'role' (string) = 'owner'\n" +
                  "   • Field 'email' (string) = '${firebaseUser?.email ?: "<Your Email>"}'\n" +
                  "4. Zero-trust security rules prevent public signup or client manipulation from creating admin accounts.\n" +
                  "5. Once saved, this screen will instantly grant access via real-time Firestore synchronization.",
                fontSize = 11.sp,
                color = Color(0xFF334155),
                lineHeight = 16.sp
              )
            }
          }
        }
      }
    }
    return
  }

  // 2. AUTHENTICATED & VERIFIED OWNER DASHBOARD
  Column(
    modifier = modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
  ) {
    // Top Bar
    Surface(
      color = Color(0xFF0F172A),
      tonalElevation = 4.dp,
      modifier = Modifier.fillMaxWidth()
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .statusBarsPadding()
          .padding(horizontal = 8.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          IconButton(onClick = onBack, modifier = Modifier.testTag("admin_back_btn")) {
            Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
          }
          Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Text(text = "ApnaCart Admin", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Color.White)
              Spacer(modifier = Modifier.width(6.dp))
              Box(
                modifier = Modifier
                  .clip(RoundedCornerShape(4.dp))
                  .background(ApnaDiscountGreen)
                  .padding(horizontal = 6.dp, vertical = 2.dp)
              ) {
                Text(text = "VERIFIED OWNER", fontSize = 9.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
              }
            }
            Text(text = "${firebaseUser?.email ?: "Owner"} • Live Backend Connected", fontSize = 11.sp, color = Color.LightGray)
          }
        }

        IconButton(
          onClick = { viewModel.logoutAdmin() },
          modifier = Modifier.testTag("admin_logout_btn")
        ) {
          Icon(imageVector = Icons.Default.ExitToApp, contentDescription = "Log Out Admin", tint = Color.White)
        }
      }
    }

    // Tab Selector (6 Tabs: Overview, Products, Orders, Offers, Operations, Settings)
    ScrollableTabRow(
      selectedTabIndex = selectedAdminTab,
      containerColor = Color.White,
      contentColor = ApnaBluePrimary,
      edgePadding = 12.dp
    ) {
      Tab(
        selected = selectedAdminTab == 0,
        onClick = { selectedAdminTab = 0 },
        text = { Text("Overview", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
      )
      Tab(
        selected = selectedAdminTab == 1,
        onClick = { selectedAdminTab = 1 },
        text = { Text("Products (${products.size})", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
      )
      Tab(
        selected = selectedAdminTab == 2,
        onClick = { selectedAdminTab = 2 },
        text = { Text("Orders (${orders.size})", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
      )
      Tab(
        selected = selectedAdminTab == 3,
        onClick = { selectedAdminTab = 3 },
        text = { Text("Coupons", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
      )
      Tab(
        selected = selectedAdminTab == 4,
        onClick = { selectedAdminTab = 4 },
        text = { Text("Operations", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
      )
      Tab(
        selected = selectedAdminTab == 5,
        onClick = { selectedAdminTab = 5 },
        text = { Text("Settings", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
      )
    }

    // Tab Content
    when (selectedAdminTab) {
      0 -> {
        // --- TAB 0: DASHBOARD METRICS & CSV EXPORT ---
        val stats = viewModel.getAdminStats()
        LazyColumn(
          modifier = Modifier.fillMaxSize(),
          contentPadding = PaddingValues(14.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          item {
            Text(text = "Live Business Analytics & Inventory", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = ApnaBlueDark)
          }

          item {
            Button(
              onClick = {
                val csv = StringBuilder()
                csv.append("Order ID,Date,Status,Total Amount (INR),Payment Method,Items Count\n")
                orders.forEach { o ->
                  csv.append("\"${o.orderId}\",\"${o.orderDate}\",\"${o.currentStatus.name}\",${o.finalAmount},\"${o.paymentMethod}\",${o.items.size}\n")
                }
                val sendIntent = Intent().apply {
                  action = Intent.ACTION_SEND
                  putExtra(Intent.EXTRA_TEXT, csv.toString())
                  putExtra(Intent.EXTRA_SUBJECT, "ApnaCart Sales & Orders Report")
                  type = "text/plain"
                }
                val shareIntent = Intent.createChooser(sendIntent, "Export Sales & Orders CSV Report")
                context.startActivity(shareIntent)
              },
              colors = ButtonDefaults.buttonColors(containerColor = ApnaBluePrimary),
              shape = RoundedCornerShape(8.dp),
              modifier = Modifier.fillMaxWidth().height(44.dp).testTag("export_csv_btn")
            ) {
              Icon(imageVector = Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(8.dp))
              Text("Export Sales & Orders Report (CSV)", fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
          }

          item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              AdminStatCard(
                title = "Total Catalog Products",
                value = "${stats.totalProducts}",
                icon = Icons.Default.Inventory,
                color = ApnaBluePrimary,
                modifier = Modifier.weight(1f)
              )
              AdminStatCard(
                title = "Customer Orders",
                value = "${stats.totalOrders}",
                icon = Icons.Default.ShoppingBag,
                color = ApnaDiscountGreen,
                modifier = Modifier.weight(1f)
              )
            }
          }

          item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              AdminStatCard(
                title = "Verified Revenue",
                value = "₹${stats.totalRevenue}",
                icon = Icons.Default.TrendingUp,
                color = Color(0xFF2E7D32),
                modifier = Modifier.weight(1f)
              )
              AdminStatCard(
                title = "Low Stock Alerts (<5)",
                value = "${stats.lowStockCount}",
                icon = Icons.Default.Warning,
                color = ApnaActionOrange,
                modifier = Modifier.weight(1f)
              )
            }
          }

          item {
            Card(
              shape = RoundedCornerShape(10.dp),
              colors = CardDefaults.cardColors(containerColor = Color.White),
              elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
              modifier = Modifier.fillMaxWidth()
            ) {
              Column(modifier = Modifier.padding(14.dp)) {
                Text(text = "Fulfillment Status Breakdown", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                  Text(text = "Pending / Processing Orders:", fontSize = 12.sp, color = Color.Gray)
                  Text(text = "${orders.count { it.currentStatus != OrderStatus.DEMO_COMPLETED && it.currentStatus != OrderStatus.DEMO_CANCELLED }}", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.height(4.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                  Text(text = "Delivered Orders:", fontSize = 12.sp, color = Color.Gray)
                  Text(text = "${orders.count { it.currentStatus == OrderStatus.DEMO_COMPLETED }}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = ApnaDiscountGreen)
                }
                Spacer(modifier = Modifier.height(4.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                  Text(text = "Cancelled Orders:", fontSize = 12.sp, color = Color.Gray)
                  Text(text = "${stats.cancelledOrdersCount}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.Red)
                }
              }
            }
          }
        }
      }

      1 -> {
        // --- TAB 1: PRODUCTS MANAGER ---
        LazyColumn(
          modifier = Modifier.fillMaxSize(),
          contentPadding = PaddingValues(14.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          item {
            Button(
              onClick = { showAddProductDialog = !showAddProductDialog },
              colors = ButtonDefaults.buttonColors(containerColor = ApnaBluePrimary),
              shape = RoundedCornerShape(8.dp),
              modifier = Modifier.fillMaxWidth().testTag("admin_add_product_toggle")
            ) {
              Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text(if (showAddProductDialog) "Close Form" else "+ Add New Product to Store")
            }
          }

          if (showAddProductDialog) {
            item {
              Card(
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                modifier = Modifier.fillMaxWidth()
              ) {
                Column(modifier = Modifier.padding(14.dp)) {
                  Text(text = "Add Product to Live Storefront", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = ApnaBlueDark)
                  Spacer(modifier = Modifier.height(8.dp))

                  OutlinedTextField(
                    value = newTitle,
                    onValueChange = { newTitle = it },
                    label = { Text("Product Title *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                  )
                  Spacer(modifier = Modifier.height(6.dp))

                  Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                      value = newBrand,
                      onValueChange = { newBrand = it },
                      label = { Text("Brand *") },
                      singleLine = true,
                      modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                      value = newCategory,
                      onValueChange = { newCategory = it },
                      label = { Text("Category (jeans, kurtis, etc.)") },
                      singleLine = true,
                      modifier = Modifier.weight(1f)
                    )
                  }
                  Spacer(modifier = Modifier.height(6.dp))

                  Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                      value = newPrice,
                      onValueChange = { if (it.all { c -> c.isDigit() }) newPrice = it },
                      label = { Text("Price (₹)") },
                      singleLine = true,
                      modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                      value = newMrp,
                      onValueChange = { if (it.all { c -> c.isDigit() }) newMrp = it },
                      label = { Text("MRP (₹)") },
                      singleLine = true,
                      modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                      value = newStock,
                      onValueChange = { if (it.all { c -> c.isDigit() }) newStock = it },
                      label = { Text("Stock") },
                      singleLine = true,
                      modifier = Modifier.weight(1f)
                    )
                  }
                  Spacer(modifier = Modifier.height(6.dp))

                  OutlinedTextField(
                    value = newDesc,
                    onValueChange = { newDesc = it },
                    label = { Text("Description") },
                    modifier = Modifier.fillMaxWidth()
                  )
                  Spacer(modifier = Modifier.height(10.dp))

                  Button(
                    onClick = {
                      if (newTitle.isNotBlank() && newBrand.isNotBlank()) {
                        val p = Product(
                          id = "p_${UUID.randomUUID().toString().take(8)}",
                          title = newTitle.trim(),
                          brand = newBrand.trim(),
                          category = newCategory.trim().lowercase(),
                          price = newPrice.toIntOrNull() ?: 799,
                          originalMrp = newMrp.toIntOrNull() ?: 1599,
                          rating = 4.6f,
                          reviewCount = 14,
                          description = newDesc.trim(),
                          highlights = listOf("Authentic Indian fabric", "Direct seller warranty", "All-India Delivery"),
                          availableSizes = listOf("S", "M", "L", "XL"),
                          availableColors = listOf("Royal Blue", "Crimson Red", "Classic Black"),
                          stockQuantity = newStock.toIntOrNull() ?: 15,
                          isBestseller = true
                        )
                        viewModel.adminAddProduct(p)
                        showAddProductDialog = false
                        newTitle = ""
                      }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ApnaDiscountGreen),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth().testTag("admin_save_new_product_btn")
                  ) {
                    Text("Publish to Customer Catalog", fontWeight = FontWeight.Bold)
                  }
                }
              }
            }
          }

          items(products, key = { it.id }) { product ->
            Card(
              shape = RoundedCornerShape(10.dp),
              colors = CardDefaults.cardColors(containerColor = Color.White),
              elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
              modifier = Modifier.fillMaxWidth()
            ) {
              Column(modifier = Modifier.padding(12.dp)) {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Column(modifier = Modifier.weight(1f)) {
                    Text(text = product.title, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                    Text(text = "${product.brand} • ${product.category}", fontSize = 11.sp, color = Color.Gray)
                  }

                  IconButton(onClick = { viewModel.adminDeleteProduct(product.id) }) {
                    Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete", tint = Color.Red, modifier = Modifier.size(18.dp))
                  }
                }

                Spacer(modifier = Modifier.height(6.dp))

                if (editingProductId == product.id) {
                  Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(
                      value = editPriceText,
                      onValueChange = { editPriceText = it },
                      label = { Text("Price ₹") },
                      singleLine = true,
                      modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                      value = editStockText,
                      onValueChange = { editStockText = it },
                      label = { Text("Stock") },
                      singleLine = true,
                      modifier = Modifier.weight(1f)
                    )
                    Button(
                      onClick = {
                        val p = editPriceText.toIntOrNull() ?: product.price
                        val s = editStockText.toIntOrNull() ?: product.stockQuantity
                        viewModel.adminUpdateStockAndPrice(product.id, s, p)
                        editingProductId = null
                      },
                      colors = ButtonDefaults.buttonColors(containerColor = ApnaDiscountGreen),
                      shape = RoundedCornerShape(6.dp)
                    ) {
                      Text("Save")
                    }
                  }
                } else {
                  Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                      Text(text = "₹${product.price}", fontSize = 15.sp, fontWeight = FontWeight.ExtraBold)
                      Spacer(modifier = Modifier.width(10.dp))
                      Box(
                        modifier = Modifier
                          .clip(RoundedCornerShape(4.dp))
                          .background(if (product.inStock) Color(0xFFE8F5E9) else Color(0xFFFFEBEE))
                          .padding(horizontal = 6.dp, vertical = 2.dp)
                      ) {
                        Text(
                          text = if (product.inStock) "${product.stockQuantity} in stock" else "Out of Stock",
                          fontSize = 11.sp,
                          fontWeight = FontWeight.Bold,
                          color = if (product.inStock) ApnaDiscountGreen else Color.Red
                        )
                      }
                    }

                    Button(
                      onClick = {
                        editingProductId = product.id
                        editPriceText = "${product.price}"
                        editStockText = "${product.stockQuantity}"
                      },
                      colors = ButtonDefaults.buttonColors(containerColor = ApnaBlueContainer),
                      shape = RoundedCornerShape(6.dp),
                      modifier = Modifier.height(30.dp)
                    ) {
                      Icon(imageVector = Icons.Default.Edit, contentDescription = null, tint = ApnaBlueDark, modifier = Modifier.size(12.dp))
                      Spacer(modifier = Modifier.width(4.dp))
                      Text(text = "Edit Stock/Price", fontSize = 11.sp, color = ApnaBlueDark, fontWeight = FontWeight.Bold)
                    }
                  }
                }
              }
            }
          }
        }
      }

      2 -> {
        // --- TAB 2: ORDERS & FULFILLMENT ---
        LazyColumn(
          modifier = Modifier.fillMaxSize(),
          contentPadding = PaddingValues(14.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          item {
            Text(text = "Customer Orders Fulfillment", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = ApnaBlueDark)
          }

          items(orders, key = { it.orderId }) { order ->
            Card(
              shape = RoundedCornerShape(10.dp),
              colors = CardDefaults.cardColors(containerColor = Color.White),
              elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
              modifier = Modifier.fillMaxWidth().testTag("admin_order_${order.orderId}")
            ) {
              Column(modifier = Modifier.padding(14.dp)) {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween
                ) {
                  Column {
                    Text(text = "Order #${order.orderId}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = ApnaBlueDark)
                    Text(text = "${order.orderDate} • ₹${order.finalAmount} via ${order.paymentMethod}", fontSize = 11.sp, color = Color.Gray)
                  }

                  Box(
                    modifier = Modifier
                      .clip(RoundedCornerShape(4.dp))
                      .background(ApnaBlueContainer)
                      .padding(horizontal = 8.dp, vertical = 3.dp)
                  ) {
                    Text(text = order.currentStatus.label, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = ApnaBlueDark)
                  }
                }

                Spacer(modifier = Modifier.height(6.dp))
                Text(text = "Customer: ${order.deliveryAddress.fullName} (+91 ${order.deliveryAddress.phone})", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Text(text = "Ship To: ${order.deliveryAddress.formattedFullAddress}", fontSize = 11.sp, color = Color.DarkGray)
                Text(text = "AWB: ${order.awbNumber} (${order.courierPartner})", fontSize = 11.sp, color = Color.Gray)

                Spacer(modifier = Modifier.height(10.dp))
                HorizontalDivider(color = Color(0xFFF1F5F9))
                Spacer(modifier = Modifier.height(8.dp))

                Text(text = "Update Fulfillment Status:", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(6.dp))

                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                  Button(
                    onClick = { viewModel.adminUpdateOrderStatus(order.orderId, OrderStatus.DEMO_SHIPPED) },
                    colors = ButtonDefaults.buttonColors(containerColor = ApnaBluePrimary),
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier.weight(1f).height(32.dp)
                  ) {
                    Text("Ship", fontSize = 11.sp)
                  }

                  Button(
                    onClick = { viewModel.adminUpdateOrderStatus(order.orderId, OrderStatus.DEMO_OUT_FOR_DELIVERY) },
                    colors = ButtonDefaults.buttonColors(containerColor = ApnaActionOrange),
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier.weight(1f).height(32.dp)
                  ) {
                    Text("Out Delivery", fontSize = 11.sp)
                  }

                  Button(
                    onClick = { viewModel.adminUpdateOrderStatus(order.orderId, OrderStatus.DEMO_COMPLETED) },
                    colors = ButtonDefaults.buttonColors(containerColor = ApnaDiscountGreen),
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier.weight(1f).height(32.dp)
                  ) {
                    Text("Delivered", fontSize = 11.sp)
                  }
                }
              }
            }
          }
        }
      }

      3 -> {
        // --- TAB 3: MARKETING & OFFERS ---
        LazyColumn(
          modifier = Modifier.fillMaxSize(),
          contentPadding = PaddingValues(14.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          item {
            Text(text = "Coupons & Promotional Discounts", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = ApnaBlueDark)
          }

          item {
            Button(
              onClick = { showAddCouponDialog = !showAddCouponDialog },
              colors = ButtonDefaults.buttonColors(containerColor = ApnaDiscountGreen),
              shape = RoundedCornerShape(8.dp),
              modifier = Modifier.fillMaxWidth()
            ) {
              Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text(if (showAddCouponDialog) "Close Form" else "+ Create Offer Coupon")
            }
          }

          if (showAddCouponDialog) {
            item {
              Card(
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier.fillMaxWidth()
              ) {
                Column(modifier = Modifier.padding(14.dp)) {
                  OutlinedTextField(
                    value = newCouponCode,
                    onValueChange = { newCouponCode = it },
                    label = { Text("Coupon Code (e.g. FESTIVE150)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                  )
                  Spacer(modifier = Modifier.height(6.dp))
                  Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                      value = newCouponVal,
                      onValueChange = { newCouponVal = it },
                      label = { Text("Flat Discount (₹)") },
                      singleLine = true,
                      modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                      value = newCouponMin,
                      onValueChange = { newCouponMin = it },
                      label = { Text("Min Cart (₹)") },
                      singleLine = true,
                      modifier = Modifier.weight(1f)
                    )
                  }
                  Spacer(modifier = Modifier.height(8.dp))
                  Button(
                    onClick = {
                      if (newCouponCode.isNotBlank()) {
                        val c = OfferCoupon(
                          code = newCouponCode.trim().uppercase(),
                          title = "Special Admin Offer",
                          description = "Instant store checkout discount",
                          discountType = "FLAT",
                          discountValue = newCouponVal.toIntOrNull() ?: 150,
                          minCartValue = newCouponMin.toIntOrNull() ?: 499
                        )
                        viewModel.adminAddCoupon(c)
                        newCouponCode = ""
                        showAddCouponDialog = false
                      }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ApnaDiscountGreen),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.fillMaxWidth()
                  ) {
                    Text("Add Coupon to Store")
                  }
                }
              }
            }
          }

          items(coupons, key = { it.code }) { coupon ->
            Card(
              shape = RoundedCornerShape(8.dp),
              colors = CardDefaults.cardColors(containerColor = Color.White),
              modifier = Modifier.fillMaxWidth()
            ) {
              Row(
                modifier = Modifier.padding(12.dp).fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Column {
                  Text(text = coupon.code, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, color = ApnaBluePrimary)
                  Text(text = "Flat ₹${coupon.discountValue} OFF on min ₹${coupon.minCartValue}", fontSize = 11.sp, color = Color.Gray)
                }
                IconButton(onClick = { viewModel.adminDeleteCoupon(coupon.code) }) {
                  Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete", tint = Color.Red, modifier = Modifier.size(16.dp))
                }
              }
            }
          }
        }
      }

      4 -> {
        // --- TAB 4: OPERATIONS (GIFT CARDS, Q&A, FRAUD PROTECTION) ---
        LazyColumn(
          modifier = Modifier.fillMaxSize(),
          contentPadding = PaddingValues(14.dp),
          verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
          // 1. Gift Cards Generator & Management
          item {
            Card(
              shape = RoundedCornerShape(10.dp),
              colors = CardDefaults.cardColors(containerColor = Color.White),
              elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
              modifier = Modifier.fillMaxWidth().testTag("admin_gift_card_section")
            ) {
              Column(modifier = Modifier.padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Icon(imageVector = Icons.Default.CardGiftcard, contentDescription = null, tint = ApnaBluePrimary, modifier = Modifier.size(20.dp))
                  Spacer(modifier = Modifier.width(8.dp))
                  Text(text = "Gift Cards Manager", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = ApnaBlueDark)
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                  OutlinedTextField(
                    value = newGiftCardCode,
                    onValueChange = { newGiftCardCode = it.uppercase() },
                    label = { Text("Code") },
                    singleLine = true,
                    modifier = Modifier.weight(1.2f)
                  )
                  OutlinedTextField(
                    value = newGiftCardAmount,
                    onValueChange = { newGiftCardAmount = it },
                    label = { Text("Amount (₹)") },
                    singleLine = true,
                    modifier = Modifier.weight(0.8f)
                  )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Button(
                  onClick = {
                    val amt = newGiftCardAmount.toIntOrNull() ?: 500
                    if (newGiftCardCode.isNotBlank()) {
                      viewModel.adminCreateGiftCard(newGiftCardCode.trim().uppercase(), amt)
                      newGiftCardCode = "APNA${(1000..9999).random()}"
                    }
                  },
                  colors = ButtonDefaults.buttonColors(containerColor = ApnaBluePrimary),
                  shape = RoundedCornerShape(6.dp),
                  modifier = Modifier.fillMaxWidth().testTag("admin_create_gift_card_btn")
                ) {
                  Text("Issue New Gift Card", fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(10.dp))
                Text(text = "Issued Gift Cards (${giftCards.size}):", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Spacer(modifier = Modifier.height(6.dp))

                giftCards.forEach { card ->
                  Row(
                    modifier = Modifier
                      .fillMaxWidth()
                      .clip(RoundedCornerShape(6.dp))
                      .background(Color(0xFFF8FAFC))
                      .padding(8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    Column {
                      Text(text = card.code, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                      Text(text = "Value: ₹${card.amount}", fontSize = 11.sp, color = Color.Gray)
                    }
                    Box(
                      modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (card.isRedeemed) Color(0xFFE2E8F0) else Color(0xFFDCFCE7))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                      Text(
                        text = if (card.isRedeemed) "REDEEMED" else "ACTIVE",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (card.isRedeemed) Color(0xFF64748B) else Color(0xFF16A34A)
                      )
                    }
                  }
                  Spacer(modifier = Modifier.height(4.dp))
                }
              }
            }
          }

          // 2. Customer Product Q&A Moderation
          item {
            Card(
              shape = RoundedCornerShape(10.dp),
              colors = CardDefaults.cardColors(containerColor = Color.White),
              elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
              modifier = Modifier.fillMaxWidth().testTag("admin_qna_section")
            ) {
              Column(modifier = Modifier.padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Icon(imageVector = Icons.Default.QuestionAnswer, contentDescription = null, tint = ApnaActionOrange, modifier = Modifier.size(20.dp))
                  Spacer(modifier = Modifier.width(8.dp))
                  Text(text = "Product Q&A Moderation (${productQuestions.size})", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = ApnaBlueDark)
                }

                Spacer(modifier = Modifier.height(10.dp))

                if (productQuestions.isEmpty()) {
                  Text(text = "No questions submitted by customers yet.", fontSize = 12.sp, color = Color.Gray)
                } else {
                  productQuestions.forEach { q ->
                    Card(
                      shape = RoundedCornerShape(8.dp),
                      colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC)),
                      modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                    ) {
                      Column(modifier = Modifier.padding(10.dp)) {
                        Text(text = "Q: ${q.question}", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text(text = "By ${q.customerName} on Product #${q.productId}", fontSize = 10.sp, color = Color.Gray)

                        if (!q.answer.isNullOrBlank()) {
                          Spacer(modifier = Modifier.height(4.dp))
                          Text(text = "Seller Answer: ${q.answer}", fontSize = 11.sp, color = ApnaDiscountGreen, fontWeight = FontWeight.SemiBold)
                        } else {
                          Spacer(modifier = Modifier.height(6.dp))
                          if (answeringQuestionId == q.id) {
                            OutlinedTextField(
                              value = questionAnswerText,
                              onValueChange = { questionAnswerText = it },
                              label = { Text("Your Verified Seller Answer") },
                              modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                              Button(
                                onClick = {
                                  if (questionAnswerText.isNotBlank()) {
                                    viewModel.adminAnswerQuestion(q.id, questionAnswerText.trim())
                                    answeringQuestionId = null
                                    questionAnswerText = ""
                                  }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = ApnaDiscountGreen),
                                shape = RoundedCornerShape(4.dp),
                                modifier = Modifier.height(34.dp)
                              ) {
                                Text("Publish Answer", fontSize = 11.sp)
                              }
                              Button(
                                onClick = { answeringQuestionId = null },
                                colors = ButtonDefaults.buttonColors(containerColor = Color.Gray),
                                shape = RoundedCornerShape(4.dp),
                                modifier = Modifier.height(34.dp)
                              ) {
                                Text("Cancel", fontSize = 11.sp)
                              }
                            }
                          } else {
                            Button(
                              onClick = {
                                answeringQuestionId = q.id
                                questionAnswerText = ""
                              },
                              colors = ButtonDefaults.buttonColors(containerColor = ApnaActionOrange),
                              shape = RoundedCornerShape(4.dp),
                              modifier = Modifier.height(32.dp)
                            ) {
                              Text("Answer Question", fontSize = 11.sp)
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }

          // 3. Fraud & Security Monitoring
          item {
            Card(
              shape = RoundedCornerShape(10.dp),
              colors = CardDefaults.cardColors(containerColor = Color.White),
              elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
              modifier = Modifier.fillMaxWidth().testTag("admin_fraud_section")
            ) {
              Column(modifier = Modifier.padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Icon(imageVector = Icons.Default.Shield, contentDescription = null, tint = Color.Red, modifier = Modifier.size(20.dp))
                  Spacer(modifier = Modifier.width(8.dp))
                  Text(text = "Fraud Protection & Abuse Monitor", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = ApnaBlueDark)
                }

                Spacer(modifier = Modifier.height(6.dp))
                Text(
                  text = "Automated server-side rate-limiting and rapid velocity check detects burst ordering.",
                  fontSize = 11.sp,
                  color = Color.Gray
                )

                Spacer(modifier = Modifier.height(10.dp))

                if (fraudAlerts.isEmpty()) {
                  Box(
                    modifier = Modifier
                      .fillMaxWidth()
                      .clip(RoundedCornerShape(6.dp))
                      .background(Color(0xFFF0FDF4))
                      .padding(10.dp)
                  ) {
                    Text(
                      text = "🛡️ All Clear: No suspicious order activity or velocity spikes detected.",
                      fontSize = 11.sp,
                      color = Color(0xFF15803D),
                      fontWeight = FontWeight.SemiBold
                    )
                  }
                } else {
                  fraudAlerts.forEach { alert ->
                    Card(
                      shape = RoundedCornerShape(8.dp),
                      colors = CardDefaults.cardColors(containerColor = if (alert.resolved) Color(0xFFF8FAFC) else Color(0xFFFEF2F2)),
                      modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                    ) {
                      Column(modifier = Modifier.padding(10.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                          Text(text = alert.type, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (alert.resolved) Color.Black else Color.Red)
                          Text(text = if (alert.resolved) "RESOLVED" else "FLAGGED", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = if (alert.resolved) Color.Gray else Color.Red)
                        }
                        Text(text = alert.description, fontSize = 11.sp, color = Color.DarkGray)
                        if (!alert.resolved) {
                          Spacer(modifier = Modifier.height(6.dp))
                          Button(
                            onClick = { viewModel.adminResolveFraudAlert(alert.id) },
                            colors = ButtonDefaults.buttonColors(containerColor = ApnaBluePrimary),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier.height(30.dp)
                          ) {
                            Text("Resolve / Mark Safe", fontSize = 10.sp)
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }

      5 -> {
        // --- TAB 5: STORE INTEGRATIONS & SETTINGS ---
        LazyColumn(
          modifier = Modifier.fillMaxSize(),
          contentPadding = PaddingValues(14.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          item {
            Text(text = "Payment & Shipping Integrations", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = ApnaBlueDark)
          }

          item {
            Card(
              shape = RoundedCornerShape(10.dp),
              colors = CardDefaults.cardColors(containerColor = Color.White),
              modifier = Modifier.fillMaxWidth()
            ) {
              Column(modifier = Modifier.padding(14.dp)) {
                Text(text = "Payment Gateways", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(10.dp))

                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Text(text = "UPI / QR Payments", fontSize = 12.sp)
                  Switch(checked = upiEnabled, onCheckedChange = { upiEnabled = it })
                }

                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Text(text = "Cash on Delivery (COD)", fontSize = 12.sp)
                  Switch(checked = codEnabled, onCheckedChange = { codEnabled = it })
                }

                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Text(text = "Credit / Debit Cards", fontSize = 12.sp)
                  Switch(checked = cardsEnabled, onCheckedChange = { cardsEnabled = it })
                }
              }
            }
          }

          item {
            Card(
              shape = RoundedCornerShape(10.dp),
              colors = CardDefaults.cardColors(containerColor = Color.White),
              modifier = Modifier.fillMaxWidth()
            ) {
              Column(modifier = Modifier.padding(14.dp)) {
                Text(text = "Logistics & Delivery Rules", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                  value = partner,
                  onValueChange = { partner = it },
                  label = { Text("Primary Courier Partner") },
                  singleLine = true,
                  modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                  OutlinedTextField(
                    value = shippingFee,
                    onValueChange = { if (it.all { c -> c.isDigit() }) shippingFee = it },
                    label = { Text("Standard Fee (₹)") },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                  )
                  OutlinedTextField(
                    value = freeThreshold,
                    onValueChange = { if (it.all { c -> c.isDigit() }) freeThreshold = it },
                    label = { Text("Free Shipping Over (₹)") },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                  )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                  onClick = {
                    val s = StoreSettings(
                      upiEnabled = upiEnabled,
                      codEnabled = codEnabled,
                      cardsEnabled = cardsEnabled,
                      courierPartner = partner.trim(),
                      standardShippingFee = shippingFee.toIntOrNull() ?: 50,
                      freeShippingThreshold = freeThreshold.toIntOrNull() ?: 499
                    )
                    viewModel.adminUpdateStoreSettings(s)
                  },
                  colors = ButtonDefaults.buttonColors(containerColor = ApnaBluePrimary),
                  shape = RoundedCornerShape(8.dp),
                  modifier = Modifier.fillMaxWidth()
                ) {
                  Text("Save Store Settings to Cloud", fontWeight = FontWeight.Bold)
                }
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun AdminStatCard(
  title: String,
  value: String,
  icon: ImageVector,
  color: Color,
  modifier: Modifier = Modifier
) {
  Card(
    shape = RoundedCornerShape(10.dp),
    colors = CardDefaults.cardColors(containerColor = Color.White),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    modifier = modifier
  ) {
    Row(
      modifier = Modifier.padding(12.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Box(
        modifier = Modifier
          .size(36.dp)
          .clip(RoundedCornerShape(8.dp))
          .background(color.copy(alpha = 0.15f)),
        contentAlignment = Alignment.Center
      ) {
        Icon(imageVector = icon, contentDescription = null, tint = color, modifier = Modifier.size(20.dp))
      }
      Spacer(modifier = Modifier.width(10.dp))
      Column {
        Text(text = value, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
        Text(text = title, fontSize = 10.sp, color = Color.Gray)
      }
    }
  }
}
