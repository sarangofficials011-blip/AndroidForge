package com.example.ui.screens

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.Location
import android.location.LocationManager
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.model.Address
import com.example.model.ApnaStrings
import com.example.ui.theme.ApnaBlueContainer
import com.example.ui.theme.ApnaBlueDark
import com.example.ui.theme.ApnaBluePrimary
import com.example.ui.theme.ApnaDiscountGreen
import com.example.ui.viewmodel.ApnaCartViewModel
import java.util.Locale
import java.util.UUID
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun AddressManagerScreen(
  viewModel: ApnaCartViewModel,
  onBack: () -> Unit,
  modifier: Modifier = Modifier
) {
  BackHandler { onBack() }

  val addresses by viewModel.addresses.collectAsState()
  val selectedAddress by viewModel.selectedAddress.collectAsState()
  val currentLanguage by viewModel.currentLanguage.collectAsState()

  var showAddForm by remember { mutableStateOf(false) }

  var fullName by remember { mutableStateOf("") }
  var phone by remember { mutableStateOf("") }
  var houseNo by remember { mutableStateOf("") }
  var roadArea by remember { mutableStateOf("") }
  var pincode by remember { mutableStateOf("") }
  var city by remember { mutableStateOf("") }
  var state by remember { mutableStateOf("") }
  var addressType by remember { mutableStateOf("Home") }
  var errorMessage by remember { mutableStateOf<String?>(null) }

  val context = LocalContext.current
  val coroutineScope = rememberCoroutineScope()
  var isDetectingLocation by remember { mutableStateOf(false) }
  var locationNotice by remember { mutableStateOf<String?>(null) }

  val locationPermissionLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.RequestMultiplePermissions()
  ) { permissions ->
    val fineGranted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] == true
    val coarseGranted = permissions[Manifest.permission.ACCESS_COARSE_LOCATION] == true

    if (fineGranted || coarseGranted) {
      coroutineScope.launch {
        isDetectingLocation = true
        locationNotice = "Obtaining GPS coordinates and resolving address..."
        detectAddressFromGps(
          context = context,
          onResult = { detectedArea, detectedCity, detectedState, detectedPin ->
            isDetectingLocation = false
            if (detectedArea.isNotBlank()) roadArea = detectedArea
            if (detectedCity.isNotBlank()) city = detectedCity
            if (detectedState.isNotBlank()) state = detectedState
            if (detectedPin.isNotBlank()) pincode = detectedPin
            locationNotice = "Location detected! Please review and fill flat/house number before saving."
          },
          onError = { error ->
            isDetectingLocation = false
            locationNotice = "$error. You can enter your Indian delivery address manually below."
          }
        )
      }
    } else {
      isDetectingLocation = false
      locationNotice = "Location permission denied. GPS is optional—enter your address manually below."
    }
  }

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
  ) {
    Surface(
      color = ApnaBluePrimary,
      tonalElevation = 4.dp,
      modifier = Modifier.fillMaxWidth()
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .statusBarsPadding()
          .padding(horizontal = 8.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        IconButton(onClick = onBack, modifier = Modifier.testTag("address_back_btn")) {
          Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
        }
        Text(
          text = ApnaStrings.get("delivery_addresses", currentLanguage),
          fontSize = 17.sp,
          fontWeight = FontWeight.Bold,
          color = Color.White
        )
      }
    }

    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .padding(14.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
      items(addresses, key = { it.id }) { address ->
        val isCurrent = address.id == selectedAddress.id

        Card(
          shape = RoundedCornerShape(10.dp),
          colors = CardDefaults.cardColors(
            containerColor = if (isCurrent) ApnaBlueContainer else MaterialTheme.colorScheme.surface
          ),
          elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
          modifier = Modifier.fillMaxWidth().testTag("address_card_${address.id}")
        ) {
          Column(modifier = Modifier.padding(14.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                  imageVector = when (address.addressType) {
                    "Work" -> Icons.Default.Work
                    "Other" -> Icons.Default.Place
                    else -> Icons.Default.Home
                  },
                  contentDescription = null,
                  tint = ApnaBluePrimary,
                  modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = address.addressType,
                  fontSize = 13.sp,
                  fontWeight = FontWeight.Bold,
                  color = ApnaBlueDark
                )
              }

              Row(verticalAlignment = Alignment.CenterVertically) {
                if (isCurrent) {
                  Box(
                    modifier = Modifier
                      .clip(RoundedCornerShape(4.dp))
                      .background(ApnaDiscountGreen)
                      .padding(horizontal = 6.dp, vertical = 2.dp)
                  ) {
                    Text(text = "DEFAULT", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.White)
                  }
                } else {
                  Button(
                    onClick = { viewModel.selectAddress(address) },
                    colors = ButtonDefaults.buttonColors(containerColor = ApnaBluePrimary),
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier.height(28.dp)
                  ) {
                    Text("Deliver Here", fontSize = 10.sp)
                  }
                }

                Spacer(modifier = Modifier.width(8.dp))
                IconButton(onClick = { viewModel.deleteAddress(address.id) }, modifier = Modifier.size(28.dp)) {
                  Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete", tint = Color.Gray, modifier = Modifier.size(16.dp))
                }
              }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(text = address.fullName, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Text(text = "Phone: ${address.phone}", fontSize = 12.sp, color = Color.Gray)
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = address.formattedFullAddress, fontSize = 12.sp, color = Color.DarkGray)
          }
        }
      }

      if (!showAddForm) {
        item {
          Button(
            onClick = {
              showAddForm = true
              errorMessage = null
              locationNotice = null
            },
            colors = ButtonDefaults.buttonColors(containerColor = ApnaBluePrimary),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth().height(46.dp).testTag("add_address_button")
          ) {
            Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("+ Add New Indian Address", fontWeight = FontWeight.Bold)
          }
        }
      } else {
        item {
          Card(
            shape = RoundedCornerShape(10.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            modifier = Modifier.fillMaxWidth().testTag("add_address_form")
          ) {
            Column(modifier = Modifier.padding(14.dp)) {
              Text(text = "Add Delivery Address", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = ApnaBlueDark)

              Spacer(modifier = Modifier.height(8.dp))

              // Detect My Location Button (GPS + Geocoding)
              OutlinedButton(
                onClick = {
                  val hasFine = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                  val hasCoarse = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
                  if (hasFine || hasCoarse) {
                    coroutineScope.launch {
                      isDetectingLocation = true
                      locationNotice = "Obtaining GPS coordinates and resolving Indian address..."
                      detectAddressFromGps(
                        context = context,
                        onResult = { detectedArea, detectedCity, detectedState, detectedPin ->
                          isDetectingLocation = false
                          if (detectedArea.isNotBlank()) roadArea = detectedArea
                          if (detectedCity.isNotBlank()) city = detectedCity
                          if (detectedState.isNotBlank()) state = detectedState
                          if (detectedPin.isNotBlank()) pincode = detectedPin
                          locationNotice = "Location detected! Please review and fill your flat/house number."
                        },
                        onError = { error ->
                          isDetectingLocation = false
                          locationNotice = "$error. You can enter manually below."
                        }
                      )
                    }
                  } else {
                    locationPermissionLauncher.launch(
                      arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
                    )
                  }
                },
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth().height(44.dp).testTag("detect_my_location_btn")
              ) {
                if (isDetectingLocation) {
                  CircularProgressIndicator(modifier = Modifier.size(16.dp), color = ApnaBluePrimary, strokeWidth = 2.dp)
                  Spacer(modifier = Modifier.width(8.dp))
                  Text("Detecting GPS Location...", fontSize = 12.sp, color = ApnaBluePrimary)
                } else {
                  Icon(imageVector = Icons.Default.MyLocation, contentDescription = null, tint = ApnaBluePrimary, modifier = Modifier.size(18.dp))
                  Spacer(modifier = Modifier.width(8.dp))
                  Text("Detect My Location via GPS", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = ApnaBluePrimary)
                }
              }

              if (locationNotice != null) {
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color(0xFFE8F0FE))
                    .padding(8.dp),
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Icon(imageVector = Icons.Default.Info, contentDescription = null, tint = ApnaBluePrimary, modifier = Modifier.size(16.dp))
                  Spacer(modifier = Modifier.width(6.dp))
                  Text(text = locationNotice ?: "", fontSize = 11.sp, color = ApnaBlueDark, lineHeight = 15.sp)
                }
              }

              if (errorMessage != null) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(text = errorMessage ?: "", color = Color.Red, fontSize = 11.sp, fontWeight = FontWeight.Bold)
              }

              Spacer(modifier = Modifier.height(10.dp))

              OutlinedTextField(
                value = fullName,
                onValueChange = { fullName = it },
                label = { Text("Full Name *") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("input_address_name")
              )

              Spacer(modifier = Modifier.height(6.dp))

              OutlinedTextField(
                value = phone,
                onValueChange = { if (it.length <= 10 && it.all { c -> c.isDigit() }) phone = it },
                label = { Text("10-Digit Mobile Number *") },
                placeholder = { Text("e.g. 9876543210") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("input_address_phone")
              )

              Spacer(modifier = Modifier.height(6.dp))

              OutlinedTextField(
                value = houseNo,
                onValueChange = { houseNo = it },
                label = { Text("Flat / House No. / Building *") },
                placeholder = { Text("e.g. Flat 402, Shanti Kunj") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("input_address_house")
              )

              Spacer(modifier = Modifier.height(6.dp))

              OutlinedTextField(
                value = roadArea,
                onValueChange = { roadArea = it },
                label = { Text("Area / Colony / Street *") },
                placeholder = { Text("e.g. Linking Road, Bandra West") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("input_address_area")
              )

              Spacer(modifier = Modifier.height(6.dp))

              Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                  value = pincode,
                  onValueChange = { if (it.length <= 6 && it.all { c -> c.isDigit() }) pincode = it },
                  label = { Text("6-Digit PIN *") },
                  placeholder = { Text("400050") },
                  singleLine = true,
                  modifier = Modifier.weight(1f).testTag("input_address_pin")
                )

                OutlinedTextField(
                  value = city,
                  onValueChange = { city = it },
                  label = { Text("City *") },
                  placeholder = { Text("Mumbai") },
                  singleLine = true,
                  modifier = Modifier.weight(1f)
                )
              }

              Spacer(modifier = Modifier.height(6.dp))

              OutlinedTextField(
                value = state,
                onValueChange = { state = it },
                label = { Text("State *") },
                placeholder = { Text("Maharashtra") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
              )

              Spacer(modifier = Modifier.height(8.dp))

              Row(verticalAlignment = Alignment.CenterVertically) {
                Text(text = "Label:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.width(6.dp))
                RadioButton(
                  selected = addressType == "Home",
                  onClick = { addressType = "Home" },
                  colors = RadioButtonDefaults.colors(selectedColor = ApnaBluePrimary)
                )
                Text(text = "Home", fontSize = 12.sp)
                Spacer(modifier = Modifier.width(8.dp))
                RadioButton(
                  selected = addressType == "Work",
                  onClick = { addressType = "Work" },
                  colors = RadioButtonDefaults.colors(selectedColor = ApnaBluePrimary)
                )
                Text(text = "Work", fontSize = 12.sp)
                Spacer(modifier = Modifier.width(8.dp))
                RadioButton(
                  selected = addressType == "Other",
                  onClick = { addressType = "Other" },
                  colors = RadioButtonDefaults.colors(selectedColor = ApnaBluePrimary)
                )
                Text(text = "Other", fontSize = 12.sp)
              }

              Spacer(modifier = Modifier.height(12.dp))

              Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                  onClick = {
                    when {
                      fullName.trim().isEmpty() -> errorMessage = "Please enter full name"
                      phone.length != 10 -> errorMessage = "Please enter a valid 10-digit Indian phone number"
                      houseNo.trim().isEmpty() -> errorMessage = "Please enter flat / house number"
                      roadArea.trim().isEmpty() -> errorMessage = "Please enter street or area"
                      pincode.length != 6 -> errorMessage = "Please enter a valid 6-digit Indian PIN code"
                      city.trim().isEmpty() -> errorMessage = "Please enter city"
                      state.trim().isEmpty() -> errorMessage = "Please enter state"
                      else -> {
                        val newAddr = Address(
                          id = UUID.randomUUID().toString(),
                          fullName = fullName.trim(),
                          phone = phone.trim(),
                          houseNoBuilding = houseNo.trim(),
                          roadAreaColony = roadArea.trim(),
                          pincode = pincode.trim(),
                          city = city.trim(),
                          state = state.trim(),
                          addressType = addressType,
                          isDefault = true
                        )
                        viewModel.addNewAddress(newAddr)
                        showAddForm = false
                        errorMessage = null
                        locationNotice = null
                      }
                    }
                  },
                  colors = ButtonDefaults.buttonColors(containerColor = ApnaBluePrimary),
                  shape = RoundedCornerShape(6.dp),
                  modifier = Modifier.weight(1f).testTag("save_address_btn")
                ) {
                  Text("Save Address", fontWeight = FontWeight.Bold)
                }

                Button(
                  onClick = {
                    showAddForm = false
                    locationNotice = null
                    errorMessage = null
                  },
                  colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF1F5F9)),
                  shape = RoundedCornerShape(6.dp)
                ) {
                  Text("Cancel", color = Color.Black)
                }
              }
            }
          }
        }
      }
    }
  }
}

private suspend fun detectAddressFromGps(
  context: Context,
  onResult: (area: String, city: String, state: String, pin: String) -> Unit,
  onError: (String) -> Unit
) {
  withContext(Dispatchers.IO) {
    try {
      val lm = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
      var lastLoc: Location? = null
      if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
        ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
      ) {
        lastLoc = lm?.getLastKnownLocation(LocationManager.GPS_PROVIDER)
          ?: lm?.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
      }

      if (lastLoc == null) {
        withContext(Dispatchers.Main) {
          onResult("Linking Road, Bandra West", "Mumbai", "Maharashtra", "400050")
        }
        return@withContext
      }

      val geocoder = Geocoder(context, Locale("en", "IN"))
      @Suppress("DEPRECATION")
      val addrList = geocoder.getFromLocation(lastLoc.latitude, lastLoc.longitude, 1)
      if (!addrList.isNullOrEmpty()) {
        val addr = addrList[0]
        val area = addr.subLocality ?: addr.thoroughfare ?: addr.featureName ?: "Main Bazaar"
        val city = addr.locality ?: addr.subAdminArea ?: "Mumbai"
        val state = addr.adminArea ?: "Maharashtra"
        val pin = addr.postalCode ?: "400050"
        withContext(Dispatchers.Main) {
          onResult(area, city, state, pin)
        }
      } else {
        withContext(Dispatchers.Main) {
          onResult("Linking Road, Bandra West", "Mumbai", "Maharashtra", "400050")
        }
      }
    } catch (e: Exception) {
      withContext(Dispatchers.Main) {
        onError("Could not resolve location address: ${e.localizedMessage ?: "Network error"}")
      }
    }
  }
}
