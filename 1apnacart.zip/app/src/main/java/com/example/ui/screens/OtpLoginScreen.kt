package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ApnaStrings
import com.example.ui.theme.ApnaActionOrange
import androidx.compose.ui.platform.LocalContext
import androidx.credentials.CredentialManager
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import com.example.R
import com.example.ui.theme.ApnaBlueContainer
import com.example.ui.theme.ApnaBlueDark
import com.example.ui.theme.ApnaBluePrimary
import com.example.ui.theme.ApnaDiscountGreen
import com.example.ui.viewmodel.ApnaCartViewModel
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.auth.GoogleAuthProvider
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import android.util.Log

@Composable
fun OtpLoginScreen(
  viewModel: ApnaCartViewModel,
  onBack: () -> Unit,
  onLoginSuccess: () -> Unit,
  modifier: Modifier = Modifier
) {
  BackHandler { onBack() }

  val authUser by viewModel.authUser.collectAsState()
  val currentLanguage by viewModel.currentLanguage.collectAsState()

  var phoneNumber by remember { mutableStateOf(authUser?.phone ?: "") }
  var fullName by remember { mutableStateOf(authUser?.fullName ?: "") }
  var otpInput by remember { mutableStateOf("") }
  var isOtpSent by remember { mutableStateOf(false) }
  var simulatedCode by remember { mutableStateOf<String?>(null) }
  var resendCountdown by remember { mutableIntStateOf(0) }
  var errorMessage by remember { mutableStateOf<String?>(null) }
  var successMessage by remember { mutableStateOf<String?>(null) }

  val context = LocalContext.current
  val coroutineScope = rememberCoroutineScope()
  var isSigningInGoogle by remember { mutableStateOf(false) }

  fun handleGoogleSignIn() {
    isSigningInGoogle = true
    coroutineScope.launch {
      try {
        val credentialManager = CredentialManager.create(context)
        val googleIdOption = GetSignInWithGoogleOption.Builder(
          context.getString(R.string.default_web_client_id)
        ).build()

        val request = GetCredentialRequest.Builder()
          .addCredentialOption(googleIdOption)
          .build()

        val result = credentialManager.getCredential(request = request, context = context)
        val googleIdTokenCredential = GoogleIdTokenCredential.createFrom(result.credential.data)
        val credential = GoogleAuthProvider.getCredential(googleIdTokenCredential.idToken, null)
        val res = viewModel.signInWithGoogleCredential(credential)
        if (res.isSuccess) {
          onLoginSuccess()
        }
      } catch (e: GetCredentialCancellationException) {
        Log.w("OtpLoginScreen", "Google sign-in was cancelled by user")
      } catch (e: Exception) {
        Log.e("OtpLoginScreen", "Google sign-in error", e)
      } finally {
        isSigningInGoogle = false
      }
    }
  }

  // Resend Countdown Ticker
  LaunchedEffect(resendCountdown) {
    if (resendCountdown > 0) {
      delay(1000L)
      resendCountdown--
    }
  }

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
  ) {
    // Header
    Surface(
      color = ApnaBluePrimary,
      tonalElevation = 4.dp,
      modifier = Modifier.fillMaxWidth()
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .statusBarsPadding()
          .padding(horizontal = 8.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        IconButton(onClick = onBack, modifier = Modifier.testTag("otp_login_back_btn")) {
          Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
        }
        Text(
          text = if (authUser != null) "Customer Account & Authentication" else "Login / Sign Up",
          fontSize = 17.sp,
          fontWeight = FontWeight.Bold,
          color = Color.White
        )
      }
    }

    Column(
      modifier = Modifier
        .fillMaxSize()
        .verticalScroll(rememberScrollState())
        .padding(16.dp)
    ) {
      if (authUser != null) {
        // Logged-in State Card
        Card(
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = Color.White),
          elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = ApnaDiscountGreen, modifier = Modifier.size(28.dp))
              Spacer(modifier = Modifier.width(10.dp))
              Column {
                Text(text = "Currently Logged In", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = ApnaBlueDark)
                Text(text = "Customer ID: ${authUser?.customerId}", fontSize = 11.sp, color = Color.Gray)
              }
            }

            Spacer(modifier = Modifier.height(14.dp))
            Text(text = "Name: ${authUser?.fullName}", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Text(text = "Mobile: +91 ${authUser?.phone}", fontSize = 13.sp, color = Color.DarkGray)
            Text(text = "Email: ${authUser?.email}", fontSize = 12.sp, color = Color.Gray)

            Spacer(modifier = Modifier.height(16.dp))

            Button(
              onClick = {
                viewModel.logoutCustomer()
                isOtpSent = false
                simulatedCode = null
                otpInput = ""
              },
              colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFEBEE)),
              shape = RoundedCornerShape(8.dp),
              modifier = Modifier.fillMaxWidth().testTag("customer_logout_btn")
            ) {
              Text("Log Out from this Device", color = Color.Red, fontWeight = FontWeight.Bold)
            }
          }
        }

        Spacer(modifier = Modifier.height(16.dp))
      }

      // Login / Register Form Card
      Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(imageVector = Icons.Default.Phone, contentDescription = null, tint = ApnaBluePrimary, modifier = Modifier.size(24.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Column {
              Text(
                text = if (authUser != null) "Switch or Re-verify Mobile" else "Indian Mobile Number Verification",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = ApnaBlueDark
              )
              Text(
                text = "We will send an OTP to verify your identity",
                fontSize = 11.sp,
                color = Color.Gray
              )
            }
          }

          Spacer(modifier = Modifier.height(14.dp))

          // 1-Tap Google Sign-In via Credential Manager
          Button(
            onClick = { handleGoogleSignIn() },
            enabled = !isSigningInGoogle,
            colors = ButtonDefaults.buttonColors(containerColor = ApnaBluePrimary),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth().height(46.dp).testTag("otp_google_sign_in_btn")
          ) {
            if (isSigningInGoogle) {
              CircularProgressIndicator(color = Color.White, modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
              Spacer(modifier = Modifier.width(8.dp))
              Text("Connecting Google Account...", fontWeight = FontWeight.Bold)
            } else {
              Text("Sign in with Google", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
          }

          Spacer(modifier = Modifier.height(14.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
          ) {
            HorizontalDivider(modifier = Modifier.weight(1f), color = Color(0xFFE2E8F0))
            Text(text = "  OR USE MOBILE OTP  ", fontSize = 10.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
            HorizontalDivider(modifier = Modifier.weight(1f), color = Color(0xFFE2E8F0))
          }
          Spacer(modifier = Modifier.height(14.dp))

          // Full Name
          OutlinedTextField(
            value = fullName,
            onValueChange = { fullName = it },
            label = { Text("Your Name (Optional)") },
            placeholder = { Text("e.g. Priya Sharma") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("otp_input_fullname"),
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = ApnaBluePrimary,
              unfocusedBorderColor = Color(0xFFD0D7E2)
            )
          )

          Spacer(modifier = Modifier.height(10.dp))

          // Mobile Number Input with +91 Prefix
          OutlinedTextField(
            value = phoneNumber,
            onValueChange = {
              if (it.length <= 10 && it.all { c -> c.isDigit() }) {
                phoneNumber = it
                errorMessage = null
              }
            },
            label = { Text("Mobile Number *") },
            placeholder = { Text("10-digit number (e.g. 9876543210)") },
            prefix = {
              Text(text = "+91 ", fontWeight = FontWeight.Bold, color = ApnaBlueDark)
            },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("otp_input_phone"),
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = ApnaBluePrimary,
              unfocusedBorderColor = Color(0xFFD0D7E2)
            )
          )

          Spacer(modifier = Modifier.height(12.dp))

          if (!isOtpSent) {
            Button(
              onClick = {
                val res = viewModel.requestOtp(phoneNumber)
                if (res.first) {
                  isOtpSent = true
                  simulatedCode = res.second
                  resendCountdown = 30
                  errorMessage = null
                  successMessage = "OTP generated! Please enter the 6-digit code below."
                } else {
                  errorMessage = res.second
                }
              },
              colors = ButtonDefaults.buttonColors(containerColor = ApnaBluePrimary),
              shape = RoundedCornerShape(8.dp),
              modifier = Modifier.fillMaxWidth().height(48.dp).testTag("send_otp_btn")
            ) {
              Text("Request OTP", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
          } else {
            // OTP Input Field
            OutlinedTextField(
              value = otpInput,
              onValueChange = {
                if (it.length <= 6 && it.all { c -> c.isDigit() }) {
                  otpInput = it
                  errorMessage = null
                }
              },
              label = { Text("Enter 6-Digit OTP *") },
              placeholder = { Text("e.g. 123456") },
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
              singleLine = true,
              modifier = Modifier.fillMaxWidth().testTag("otp_input_code"),
              colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = ApnaBluePrimary,
                unfocusedBorderColor = Color(0xFFD0D7E2)
              )
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Action: Verify OTP
            Button(
              onClick = {
                val res = viewModel.verifyOtp(phoneNumber, otpInput, fullName)
                if (res.first) {
                  successMessage = res.second
                  errorMessage = null
                  onLoginSuccess()
                } else {
                  errorMessage = res.second
                }
              },
              enabled = otpInput.length == 6,
              colors = ButtonDefaults.buttonColors(containerColor = ApnaActionOrange),
              shape = RoundedCornerShape(8.dp),
              modifier = Modifier.fillMaxWidth().height(48.dp).testTag("verify_otp_btn")
            ) {
              Text("Verify & Continue", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.White)
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Resend OTP Countdown
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              if (resendCountdown > 0) {
                Text(
                  text = "Resend OTP in ${resendCountdown}s",
                  fontSize = 12.sp,
                  color = Color.Gray,
                  fontWeight = FontWeight.Medium
                )
              } else {
                TextButton(
                  onClick = {
                    val res = viewModel.requestOtp(phoneNumber)
                    if (res.first) {
                      simulatedCode = res.second
                      resendCountdown = 30
                      successMessage = "New OTP generated."
                    } else {
                      errorMessage = res.second
                    }
                  }
                ) {
                  Text("Resend OTP", color = ApnaBluePrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
              }

              TextButton(
                onClick = {
                  isOtpSent = false
                  simulatedCode = null
                  otpInput = ""
                }
              ) {
                Text("Change Number", color = Color.Gray, fontSize = 12.sp)
              }
            }
          }

          if (errorMessage != null) {
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = errorMessage ?: "", color = Color.Red, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
          }

          if (successMessage != null) {
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = successMessage ?: "", color = ApnaDiscountGreen, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
          }
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      // Transparent Gateway & Architecture Disclosure Card
      Card(
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = ApnaBlueContainer),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(imageVector = Icons.Default.Security, contentDescription = null, tint = ApnaBluePrimary, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(text = "Security & SMS Gateway Architecture", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = ApnaBlueDark)
          }

          Spacer(modifier = Modifier.height(6.dp))

          Text(
            text = "• Environment: Free Development & Local Persistence Mode.\n" +
              "• Rate limiting: Max 3 requests per 2-minute window.\n" +
              "• Expiry: Verification codes expire in 5 minutes.\n" +
              "• Production Integration: For live SMS delivery across Indian telecom operators (DLT registered), wire to Firebase Phone Authentication (reCAPTCHA/SafetyNet) or Indian SMS gateways (Fast2SMS / Gupshup / Msg91).",
            fontSize = 11.sp,
            lineHeight = 16.sp,
            color = MaterialTheme.colorScheme.onSurface
          )

          if (simulatedCode != null) {
            Spacer(modifier = Modifier.height(8.dp))
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(6.dp))
                .background(Color.White)
                .border(1.dp, ApnaBluePrimary, RoundedCornerShape(6.dp))
                .padding(10.dp)
            ) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text(text = "Generated Test OTP:", fontSize = 12.sp, color = Color.Gray)
                Text(text = simulatedCode ?: "", fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = ApnaBluePrimary)
              }
            }
          }
        }
      }
    }
  }
}
