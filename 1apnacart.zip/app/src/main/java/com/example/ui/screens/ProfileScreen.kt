package com.example.ui.screens

import android.util.Log
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Login
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Stars
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.credentials.CredentialManager
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import com.example.BuildConfig
import com.example.R
import com.example.model.*
import com.example.ui.theme.ApnaActionOrange
import com.example.ui.theme.ApnaBlueContainer
import com.example.ui.theme.ApnaBlueDark
import com.example.ui.theme.ApnaBluePrimary
import com.example.ui.theme.ApnaDiscountGreen
import com.example.ui.viewmodel.ApnaCartViewModel
import com.example.ui.viewmodel.MainTab
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.auth.GoogleAuthProvider
import kotlinx.coroutines.launch

@Composable
fun ProfileScreen(
  viewModel: ApnaCartViewModel,
  onNavigateToOrders: () -> Unit,
  onNavigateToAddresses: () -> Unit,
  onNavigateToAdmin: () -> Unit,
  onNavigateToEditProfile: () -> Unit,
  onNavigateToWallet: () -> Unit = {},
  onNavigateToRewards: () -> Unit = {},
  onNavigateToReferral: () -> Unit = {},
  onNavigateToLoyalty: () -> Unit = {},
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  val coroutineScope = rememberCoroutineScope()

  val orders by viewModel.orders.collectAsState()
  val wishlistIds by viewModel.wishlistIds.collectAsState()
  val userProfile by viewModel.userProfile.collectAsState()
  val currentLanguage by viewModel.currentLanguage.collectAsState()
  val firebaseUser by viewModel.firebaseUser.collectAsState()
  val adminStatus by viewModel.adminStatus.collectAsState()
  val walletBalance by viewModel.walletBalance.collectAsState()
  val rewardPoints by viewModel.rewardPoints.collectAsState()
  val membership by viewModel.membership.collectAsState()

  var isSigningIn by remember { mutableStateOf(false) }
  var showExportGuide by remember { mutableStateOf(false) }
  var showDevSetupGuide by remember { mutableStateOf(false) }

  // Interactive Google Sign-In via Jetpack Credential Manager
  fun handleGoogleSignIn() {
    isSigningIn = true
    coroutineScope.launch {
      try {
        val credentialManager = CredentialManager.create(context)
        val googleIdOption = GetSignInWithGoogleOption.Builder(
          context.getString(R.string.default_web_client_id)
        ).build()

        val request = GetCredentialRequest.Builder()
          .addCredentialOption(googleIdOption)
          .build()

        val result = credentialManager.getCredential(
          request = request,
          context = context
        )

        val googleIdTokenCredential = GoogleIdTokenCredential.createFrom(result.credential.data)
        val credential = GoogleAuthProvider.getCredential(googleIdTokenCredential.idToken, null)
        viewModel.signInWithGoogleCredential(credential)
      } catch (e: GetCredentialCancellationException) {
        Log.w("ProfileScreen", "Google sign-in was cancelled by user")
      } catch (e: Exception) {
        Log.e("ProfileScreen", "Google sign-in error", e)
      } finally {
        isSigningIn = false
      }
    }
  }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background),
    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 96.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    // 1. Customer Profile / Authentication Header
    item {
      Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth().testTag("profile_user_card")
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          if (firebaseUser != null) {
            // Logged-in Customer View
            Row(
              modifier = Modifier.fillMaxWidth(),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                  modifier = Modifier
                    .size(56.dp)
                    .clip(CircleShape)
                    .background(ApnaBlueContainer),
                  contentAlignment = Alignment.Center
                ) {
                  Icon(
                    imageVector = Icons.Default.Person,
                    contentDescription = "Avatar",
                    tint = ApnaBluePrimary,
                    modifier = Modifier.size(32.dp)
                  )
                }

                Spacer(modifier = Modifier.width(14.dp))

                Column {
                  Text(
                    text = firebaseUser?.displayName ?: userProfile.fullName,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                  )
                  Text(
                    text = firebaseUser?.email ?: userProfile.email,
                    fontSize = 12.sp,
                    color = Color.Gray
                  )
                  if (!userProfile.phone.isNullOrBlank()) {
                    Text(
                      text = "+91 ${userProfile.phone}",
                      fontSize = 11.sp,
                      color = Color.Gray
                    )
                  }
                }
              }

              IconButton(
                onClick = onNavigateToEditProfile,
                modifier = Modifier.testTag("profile_edit_btn")
              ) {
                Icon(imageVector = Icons.Default.Edit, contentDescription = "Edit Profile", tint = ApnaBluePrimary)
              }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = Icons.Default.VerifiedUser, contentDescription = null, tint = ApnaDiscountGreen, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(text = "Customer Account Active", fontSize = 11.sp, color = ApnaDiscountGreen, fontWeight = FontWeight.SemiBold)
              }

              OutlinedButton(
                onClick = { viewModel.logoutCustomer() },
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.height(32.dp)
              ) {
                Icon(imageVector = Icons.Default.Logout, contentDescription = null, modifier = Modifier.size(12.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Sign Out", fontSize = 11.sp)
              }
            }
          } else {
            // Logged-out Visitor View: Customer Login Promotion
            Row(verticalAlignment = Alignment.CenterVertically) {
              Box(
                modifier = Modifier
                  .size(52.dp)
                  .clip(CircleShape)
                  .background(ApnaBlueContainer),
                contentAlignment = Alignment.Center
              ) {
                Icon(
                  imageVector = Icons.Default.AccountCircle,
                  contentDescription = "Visitor",
                  tint = ApnaBluePrimary,
                  modifier = Modifier.size(32.dp)
                )
              }

              Spacer(modifier = Modifier.width(14.dp))

              Column {
                Text(
                  text = "Welcome to ApnaCart!",
                  fontSize = 16.sp,
                  fontWeight = FontWeight.Bold,
                  color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                  text = "Sign in to track orders & save delivery addresses",
                  fontSize = 11.sp,
                  color = Color.Gray
                )
              }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Button(
              onClick = { handleGoogleSignIn() },
              enabled = !isSigningIn,
              colors = ButtonDefaults.buttonColors(containerColor = ApnaBluePrimary),
              shape = RoundedCornerShape(8.dp),
              modifier = Modifier.fillMaxWidth().height(46.dp).testTag("google_sign_in_btn")
            ) {
              if (isSigningIn) {
                CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Signing in...", fontWeight = FontWeight.Bold)
              } else {
                Icon(imageVector = Icons.Default.Login, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Sign in with Google", fontWeight = FontWeight.Bold)
              }
            }
          }
        }
      }
    }

    // 2. PRIVILEGED OWNER ACCESS (ONLY shown to verified owners)
    // Customers NEVER see the admin dashboard, buttons or controls
    if (adminStatus.isAuthorizedOwner) {
      item {
        Card(
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
          elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
          modifier = Modifier.fillMaxWidth().testTag("owner_admin_card")
        ) {
          Column(modifier = Modifier.padding(14.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = Icons.Default.Security, contentDescription = null, tint = ApnaActionOrange, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = "Store Owner Console", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White)
              }
              Box(
                modifier = Modifier
                  .clip(RoundedCornerShape(4.dp))
                  .background(ApnaDiscountGreen)
                  .padding(horizontal = 6.dp, vertical = 2.dp)
              ) {
                Text(text = "VERIFIED OWNER", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.White)
              }
            }

            Spacer(modifier = Modifier.height(6.dp))
            Text(
              text = "You are authorized as the verified owner. Access catalog management, customer orders, stock, and business reports.",
              fontSize = 11.sp,
              color = Color(0xFFCBD5E1),
              lineHeight = 15.sp
            )

            Spacer(modifier = Modifier.height(12.dp))

            Button(
              onClick = onNavigateToAdmin,
              colors = ButtonDefaults.buttonColors(containerColor = ApnaActionOrange),
              shape = RoundedCornerShape(8.dp),
              modifier = Modifier.fillMaxWidth().height(42.dp).testTag("open_admin_dashboard_btn")
            ) {
              Icon(imageVector = Icons.Default.AdminPanelSettings, contentDescription = null, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(8.dp))
              Text("Open Admin Management Dashboard", fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
          }
        }
      }
    }

    // 3. Customer Quick Navigations (Visible to all users & customers)
    item {
      Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(6.dp)) {
          ProfileNavRow(
            title = ApnaStrings.get("my_orders", currentLanguage),
            subtitle = "${orders.size} orders placed",
            icon = Icons.Default.LocalShipping,
            onClick = onNavigateToOrders,
            testTag = "profile_orders_link"
          )

          HorizontalDivider(color = Color(0xFFEEEEEE))

          ProfileNavRow(
            title = ApnaStrings.get("my_wishlist", currentLanguage),
            subtitle = "${wishlistIds.size} saved items",
            icon = Icons.Default.Favorite,
            onClick = { viewModel.setTab(MainTab.WISHLIST) },
            testTag = "profile_wishlist_link"
          )

          HorizontalDivider(color = Color(0xFFEEEEEE))

          ProfileNavRow(
            title = ApnaStrings.get("delivery_addresses", currentLanguage),
            subtitle = "Manage shipping addresses",
            icon = Icons.Default.LocationOn,
            onClick = onNavigateToAddresses,
            testTag = "profile_address_link"
          )
        }
      }
    }

    // 4. Wallet, Rewards & Perks Hub
    item {
      Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth().testTag("profile_perks_card")
      ) {
        Column(modifier = Modifier.padding(6.dp)) {
          ProfileNavRow(
            title = "ApnaCart Wallet",
            subtitle = "₹$walletBalance available • Add gift card or pay at checkout",
            icon = Icons.Default.AccountBalanceWallet,
            iconTint = ApnaBluePrimary,
            onClick = onNavigateToWallet,
            testTag = "profile_wallet_link"
          )

          HorizontalDivider(color = Color(0xFFEEEEEE))

          ProfileNavRow(
            title = "SuperCoins & Rewards",
            subtitle = "$rewardPoints SuperCoins earned • Redeem ₹1 per coin",
            icon = Icons.Default.Stars,
            iconTint = ApnaActionOrange,
            onClick = onNavigateToRewards,
            testTag = "profile_rewards_link"
          )

          HorizontalDivider(color = Color(0xFFEEEEEE))

          ProfileNavRow(
            title = "Refer & Earn (Get ₹100)",
            subtitle = "Invite friends with code APNA100",
            icon = Icons.Default.Share,
            iconTint = ApnaDiscountGreen,
            onClick = onNavigateToReferral,
            testTag = "profile_referral_link"
          )

          HorizontalDivider(color = Color(0xFFEEEEEE))

          ProfileNavRow(
            title = "ApnaClub VIP Membership",
            subtitle = "${membership.tier.name.lowercase().replaceFirstChar { it.uppercase() }} Tier Member • View exclusive benefits",
            icon = Icons.Default.WorkspacePremium,
            iconTint = Color(0xFF9333EA),
            onClick = onNavigateToLoyalty,
            testTag = "profile_loyalty_link"
          )
        }
      }
    }

    // 4. Language Selection (Bilingual English / Hindi)
    item {
      Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(imageVector = Icons.Default.Language, contentDescription = null, tint = ApnaBluePrimary, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = ApnaStrings.get("app_language", currentLanguage),
              fontSize = 14.sp,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.onSurface
            )
          }

          Spacer(modifier = Modifier.height(10.dp))

          Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            AppLanguage.values().forEach { lang ->
              val isChosen = currentLanguage == lang
              Box(
                modifier = Modifier
                  .clip(RoundedCornerShape(8.dp))
                  .background(if (isChosen) ApnaBluePrimary else ApnaBlueContainer)
                  .clickable { viewModel.setLanguage(lang) }
                  .padding(horizontal = 14.dp, vertical = 8.dp)
                  .testTag("lang_btn_${lang.code}")
              ) {
                Text(
                  text = "${lang.displayName} (${lang.nativeName})",
                  fontSize = 12.sp,
                  fontWeight = FontWeight.Bold,
                  color = if (isChosen) Color.White else ApnaBlueDark
                )
              }
            }
          }
        }
      }
    }

    // 5. Development Mode: Owner Configuration Instructions (ONLY shown in debug / non-admin dev)
    if (BuildConfig.DEBUG && !adminStatus.isAuthorizedOwner) {
      item {
        Card(
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC)),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(14.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = Icons.Default.Lock, contentDescription = null, tint = Color(0xFF64748B), modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = "Owner Setup (Developer Mode)", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFF334155))
              }
              Text(
                text = if (showDevSetupGuide) "Hide" else "Setup Info",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = ApnaBluePrimary,
                modifier = Modifier.clickable { showDevSetupGuide = !showDevSetupGuide }
              )
            }

            if (showDevSetupGuide) {
              Spacer(modifier = Modifier.height(8.dp))
              Text(
                text = "• Public users and customers have zero admin access.\n" +
                  "• Active Account: ${firebaseUser?.email ?: "Not signed in"}\n" +
                  "• User UID: ${firebaseUser?.uid ?: "N/A"}\n" +
                  "• To grant owner access: In Firebase Console -> Cloud Firestore -> add doc in 'admins' with ID '${firebaseUser?.uid ?: "<Your UID>"}' and { role: 'owner' }.\n" +
                  "• Admin access remains strictly denied until backend verification.",
                fontSize = 11.sp,
                lineHeight = 16.sp,
                color = Color(0xFF475569)
              )

              if (firebaseUser != null) {
                Spacer(modifier = Modifier.height(10.dp))
                Button(
                  onClick = onNavigateToAdmin,
                  colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF334155)),
                  shape = RoundedCornerShape(6.dp),
                  modifier = Modifier.fillMaxWidth()
                ) {
                  Text("Check Admin Verification Status", fontSize = 11.sp)
                }
              }
            }
          }
        }
      }
    }

    // 6. How to Export & Install APK Section
    item {
      Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = ApnaBlueContainer),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(imageVector = Icons.Default.Android, contentDescription = null, tint = ApnaBluePrimary, modifier = Modifier.size(20.dp))
              Spacer(modifier = Modifier.width(8.dp))
              Text(text = "How to Export APK", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = ApnaBlueDark)
            }
            Text(
              text = if (showExportGuide) "Hide" else "Show",
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold,
              color = ApnaBluePrimary,
              modifier = Modifier.clickable { showExportGuide = !showExportGuide }
            )
          }

          if (showExportGuide) {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
              text = "• Native Android Gradle Project with Kotlin and Jetpack Compose.\n" +
                "• In Google AI Studio Build, tap Settings / Project menu at top-right.\n" +
                "• Choose 'Export APK' or 'Download Project ZIP'.\n" +
                "• To build manually: run 'gradle assembleDebug' to create 'app-debug.apk' in 'app/build/outputs/apk/debug/'.",
              fontSize = 11.sp,
              lineHeight = 16.sp,
              color = MaterialTheme.colorScheme.onSurface
            )
          }
        }
      }
    }

    // 7. About ApnaCart & Notice
    item {
      Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(36.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(Color.White)
                .padding(2.dp),
              contentAlignment = Alignment.Center
            ) {
              androidx.compose.foundation.Image(
                painter = androidx.compose.ui.res.painterResource(id = com.example.R.drawable.ic_apna_logo),
                contentDescription = "ApnaCart Logo",
                modifier = Modifier.size(32.dp)
              )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(text = ApnaStrings.get("about_apnacart", currentLanguage), fontSize = 14.sp, fontWeight = FontWeight.Bold)
              Text(text = "ApnaCart v1.0 • Indian Shopping", fontSize = 11.sp, color = ApnaBluePrimary, fontWeight = FontWeight.SemiBold)
            }
          }
          Spacer(modifier = Modifier.height(8.dp))
          Text(
            text = "ApnaCart provides a Flipkart-inspired Indian shopping experience. Customers browse published products, manage their personal cart, and track orders with zero access to administrative controls.",
            fontSize = 11.sp,
            color = Color.Gray,
            lineHeight = 16.sp
          )
        }
      }
    }
  }
}

@Composable
private fun ProfileNavRow(
  title: String,
  subtitle: String,
  icon: ImageVector,
  iconTint: Color = ApnaBluePrimary,
  onClick: () -> Unit,
  testTag: String
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .clickable { onClick() }
      .padding(horizontal = 10.dp, vertical = 10.dp)
      .testTag(testTag),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Row(verticalAlignment = Alignment.CenterVertically) {
      Box(
        modifier = Modifier
          .size(36.dp)
          .clip(RoundedCornerShape(8.dp))
          .background(iconTint.copy(alpha = 0.12f)),
        contentAlignment = Alignment.Center
      ) {
        Icon(imageVector = icon, contentDescription = null, tint = iconTint, modifier = Modifier.size(18.dp))
      }
      Spacer(modifier = Modifier.width(12.dp))
      Column {
        Text(text = title, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
        Text(text = subtitle, fontSize = 11.sp, color = Color.Gray)
      }
    }

    Icon(imageVector = Icons.Default.ChevronRight, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(18.dp))
  }
}
