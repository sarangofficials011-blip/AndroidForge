package com.example.ui.screens

import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.ui.theme.ApnaActionOrange
import com.example.ui.theme.ApnaBluePrimary
import com.example.ui.theme.ApnaDiscountGreen
import com.example.ui.viewmodel.ApnaCartViewModel

@Composable
fun ReferralScreen(
  viewModel: ApnaCartViewModel,
  onBack: () -> Unit,
  modifier: Modifier = Modifier
) {
  BackHandler { onBack() }
  val context = LocalContext.current
  val referralData by viewModel.referralData.collectAsState()
  var inputReferralCode by remember { mutableStateOf("") }

  Surface(
    color = MaterialTheme.colorScheme.background,
    modifier = modifier.fillMaxSize()
  ) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .statusBarsPadding()
    ) {
      // Header
      Surface(
        color = ApnaBluePrimary,
        tonalElevation = 4.dp,
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 12.dp)
        ) {
          IconButton(onClick = onBack) {
            Icon(
              imageVector = Icons.AutoMirrored.Filled.ArrowBack,
              contentDescription = "Back",
              tint = Color.White
            )
          }
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = "Refer & Earn",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
          )
        }
      }

      LazyColumn(
        modifier = Modifier
          .fillMaxSize()
          .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
      ) {
        // Hero Card
        item {
          Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1565C0)),
            elevation = CardDefaults.cardElevation(6.dp),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(
              horizontalAlignment = Alignment.CenterHorizontally,
              modifier = Modifier.padding(20.dp)
            ) {
              Box(
                modifier = Modifier
                  .size(54.dp)
                  .clip(CircleShape)
                  .background(Color(0xFFFFD200)),
                contentAlignment = Alignment.Center
              ) {
                Icon(
                  imageVector = Icons.Default.CardGiftcard,
                  contentDescription = null,
                  tint = ApnaBluePrimary,
                  modifier = Modifier.size(32.dp)
                )
              }
              Spacer(modifier = Modifier.height(12.dp))
              Text(
                text = "Give ₹100, Get ₹100",
                fontSize = 20.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Color.White
              )
              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = "Share your invite code. When your friend completes their first qualifying order, you both get ₹100 wallet credits!",
                fontSize = 12.sp,
                color = Color.White.copy(alpha = 0.85f),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
              )
              Spacer(modifier = Modifier.height(16.dp))
              // Referral Code Box
              Box(
                modifier = Modifier
                  .clip(RoundedCornerShape(8.dp))
                  .background(Color.White)
                  .padding(horizontal = 24.dp, vertical = 8.dp)
              ) {
                Text(
                  text = referralData.referralCode,
                  fontSize = 20.sp,
                  fontWeight = FontWeight.ExtraBold,
                  color = ApnaBluePrimary,
                  letterSpacing = 2.sp
                )
              }
              Spacer(modifier = Modifier.height(14.dp))
              Button(
                onClick = {
                  val shareIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(
                      Intent.EXTRA_TEXT,
                      "Join ApnaCart with my referral code ${referralData.referralCode} to get ₹100 instant wallet credit! Download: https://ais-pre-oizqy7nfdj25nrmxnp2tbi-326079129429.asia-east1.run.app"
                    )
                  }
                  context.startActivity(Intent.createChooser(shareIntent, "Share Referral Code"))
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFD200)),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
              ) {
                Icon(imageVector = Icons.Default.Share, contentDescription = null, tint = ApnaBluePrimary)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Share with Friends & Family", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = ApnaBluePrimary)
              }
            }
          }
        }

        // Apply Friend's Referral Code
        item {
          Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(2.dp),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(16.dp)) {
              Text(text = "Referred by a friend?", fontSize = 14.sp, fontWeight = FontWeight.Bold)
              Spacer(modifier = Modifier.height(8.dp))
              Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                  value = inputReferralCode,
                  onValueChange = { inputReferralCode = it.uppercase() },
                  placeholder = { Text("Enter code (e.g., APNA100)", fontSize = 12.sp) },
                  singleLine = true,
                  shape = RoundedCornerShape(8.dp),
                  colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = ApnaBluePrimary,
                    unfocusedBorderColor = Color(0xFFD0D7E2)
                  ),
                  modifier = Modifier.weight(1f)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Button(
                  onClick = {
                    if (inputReferralCode.isNotBlank()) {
                      viewModel.submitReferralCode(inputReferralCode)
                      inputReferralCode = ""
                    }
                  },
                  colors = ButtonDefaults.buttonColors(containerColor = ApnaBluePrimary),
                  shape = RoundedCornerShape(8.dp)
                ) {
                  Text("Apply", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
              }
            }
          }
        }

        // Referral Stats
        item {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
          ) {
            Card(
              shape = RoundedCornerShape(12.dp),
              colors = CardDefaults.cardColors(containerColor = Color.White),
              elevation = CardDefaults.cardElevation(2.dp),
              modifier = Modifier.weight(1f)
            ) {
              Column(modifier = Modifier.padding(14.dp)) {
                Text(text = "Total Friends Invited", fontSize = 11.sp, color = Color.Gray)
                Spacer(modifier = Modifier.height(4.dp))
                Text(text = "${referralData.totalInvited}", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = ApnaBluePrimary)
              }
            }
            Card(
              shape = RoundedCornerShape(12.dp),
              colors = CardDefaults.cardColors(containerColor = Color.White),
              elevation = CardDefaults.cardElevation(2.dp),
              modifier = Modifier.weight(1f)
            ) {
              Column(modifier = Modifier.padding(14.dp)) {
                Text(text = "Earned Wallet Credits", fontSize = 11.sp, color = Color.Gray)
                Spacer(modifier = Modifier.height(4.dp))
                Text(text = "₹${referralData.earnedCredits}", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = ApnaDiscountGreen)
              }
            }
          }
        }

        // Referral History
        item {
          Text(text = "Referral Activity", fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }

        items(referralData.history) { entry ->
          Card(
            shape = RoundedCornerShape(10.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(1.dp),
            modifier = Modifier.fillMaxWidth()
          ) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = ApnaDiscountGreen, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                  Text(text = entry.refereeName, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                  Text(text = entry.date, fontSize = 10.sp, color = Color.Gray)
                }
              }
              Text(text = "+₹${entry.rewardAmount}", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = ApnaDiscountGreen)
            }
          }
        }
      }
    }
  }
}
