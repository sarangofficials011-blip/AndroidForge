package com.example.ui.screens

import android.provider.Settings
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.ApnaBluePrimary
import kotlinx.coroutines.delay

@Composable
fun SplashScreen(
  onSplashFinished: () -> Unit,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  // Check reduced motion setting
  val animScale = try {
    Settings.Global.getFloat(context.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1.0f)
  } catch (e: Exception) {
    1.0f
  }
  val isReducedMotion = animScale == 0.0f

  val logoScale = remember { Animatable(if (isReducedMotion) 1f else 0.65f) }
  val logoAlpha = remember { Animatable(if (isReducedMotion) 1f else 0f) }
  val textAlpha = remember { Animatable(if (isReducedMotion) 1f else 0f) }
  val taglineAlpha = remember { Animatable(if (isReducedMotion) 1f else 0f) }
  val cartOffset = remember { Animatable(if (isReducedMotion) 0f else -18f) }

  val infiniteTransition = rememberInfiniteTransition(label = "accent_pulse")
  val pulseGlow by infiniteTransition.animateFloat(
    initialValue = 0.85f,
    targetValue = 1.05f,
    animationSpec = infiniteRepeatable(
      animation = tween(1200, easing = FastOutSlowInEasing),
      repeatMode = RepeatMode.Reverse
    ),
    label = "glow"
  )

  val accentProgress by infiniteTransition.animateFloat(
    initialValue = -120f,
    targetValue = 240f,
    animationSpec = infiniteRepeatable(
      animation = tween(1600, easing = LinearEasing),
      repeatMode = RepeatMode.Restart
    ),
    label = "accent_progress"
  )

  LaunchedEffect(Unit) {
    if (!isReducedMotion) {
      // 1. Smooth scale and fade in of the royal-blue logo container
      logoAlpha.animateTo(1f, animationSpec = tween(450, easing = FastOutSlowInEasing))
      logoScale.animateTo(
        1f,
        animationSpec = spring(dampingRatio = 0.65f, stiffness = 400f)
      )
      // 2. Subtle shopping cart movement
      cartOffset.animateTo(
        0f,
        animationSpec = spring(dampingRatio = 0.7f, stiffness = 500f)
      )
      // 3. Reveal brand text and tagline
      textAlpha.animateTo(1f, animationSpec = tween(400))
      taglineAlpha.animateTo(1f, animationSpec = tween(450))
      // 4. Brief dwell time for smooth opening experience
      delay(950)
    } else {
      delay(500)
    }
    onSplashFinished()
  }

  Surface(
    modifier = modifier
      .fillMaxSize()
      .testTag("apnacart_splash_screen")
  ) {
    Box(
      modifier = Modifier
        .fillMaxSize()
        .background(
          brush = Brush.verticalGradient(
            colors = listOf(
              Color(0xFF0D47A1), // Royal Blue Deep
              ApnaBluePrimary,   // 0xFF1040D0 Royal Blue
              Color(0xFF09296B)  // Dark Royal Blue
            )
          )
        ),
      contentAlignment = Alignment.Center
    ) {
      // Decorative background ambient circles
      Box(
        modifier = Modifier
          .size(320.dp)
          .scale(pulseGlow)
          .clip(CircleShape)
          .background(Color.White.copy(alpha = 0.04f))
      )
      Box(
        modifier = Modifier
          .size(240.dp)
          .clip(CircleShape)
          .background(Color(0xFFFFD200).copy(alpha = 0.05f))
      )

      Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
        modifier = Modifier.padding(24.dp)
      ) {
        // Redesigned ApnaCart Logo Card
        Box(
          modifier = Modifier
            .scale(logoScale.value)
            .alpha(logoAlpha.value)
            .offset(x = cartOffset.value.dp)
            .size(118.dp)
            .shadow(16.dp, RoundedCornerShape(28.dp), spotColor = Color(0xFFFFD200).copy(alpha = 0.5f))
            .clip(RoundedCornerShape(28.dp))
            .background(Color.White)
            .padding(8.dp),
          contentAlignment = Alignment.Center
        ) {
          Image(
            painter = painterResource(id = R.drawable.apnacart_logo),
            contentDescription = "ApnaCart Brand Symbol",
            contentScale = ContentScale.Fit,
            modifier = Modifier.size(100.dp)
          )
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Brand Name "ApnaCart"
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier
            .alpha(textAlpha.value)
            .testTag("splash_brand_title")
        ) {
          Text(
            text = "Apna",
            fontSize = 34.sp,
            fontWeight = FontWeight.ExtraBold,
            color = Color.White,
            letterSpacing = 0.5.sp
          )
          Text(
            text = "Cart",
            fontSize = 34.sp,
            fontWeight = FontWeight.Black,
            fontStyle = FontStyle.Italic,
            color = Color(0xFFFFD200), // Bright Yellow Flipkart/ApnaCart Accent
            letterSpacing = 0.5.sp
          )
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Tagline "Sab Kuch, Apke Liye"
        Text(
          text = "Sab Kuch, Apke Liye",
          fontSize = 15.sp,
          fontWeight = FontWeight.Medium,
          color = Color.White.copy(alpha = 0.92f),
          letterSpacing = 1.sp,
          modifier = Modifier
            .alpha(taglineAlpha.value)
            .testTag("splash_tagline")
        )

        Spacer(modifier = Modifier.height(36.dp))

        // Subtle Yellow-and-Blue Animated Accent Loading Bar
        Box(
          modifier = Modifier
            .width(140.dp)
            .height(4.dp)
            .clip(RoundedCornerShape(2.dp))
            .background(Color.White.copy(alpha = 0.25f))
        ) {
          Box(
            modifier = Modifier
              .offset(x = accentProgress.dp)
              .width(48.dp)
              .height(4.dp)
              .clip(RoundedCornerShape(2.dp))
              .background(
                Brush.horizontalGradient(
                  listOf(
                    Color(0xFFFFD200),
                    Color.White,
                    Color(0xFFFFD200)
                  )
                )
              )
          )
        }
      }

      // Bottom app version & security badge
      Text(
        text = "100% Genuine • Verified Indian Store",
        fontSize = 11.sp,
        color = Color.White.copy(alpha = 0.7f),
        fontWeight = FontWeight.Normal,
        modifier = Modifier
          .align(Alignment.BottomCenter)
          .padding(bottom = 32.dp)
      )
    }
  }
}
