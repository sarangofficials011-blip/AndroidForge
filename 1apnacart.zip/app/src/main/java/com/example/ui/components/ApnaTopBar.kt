package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.ShoppingBag
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.AppLanguage
import com.example.model.ApnaStrings
import com.example.ui.theme.ApnaActionOrange
import com.example.ui.theme.ApnaBlueDark
import com.example.ui.theme.ApnaBluePrimary
import com.example.ui.theme.ApnaYellowRating

@Composable
fun ApnaTopBar(
  deliveryPincode: String,
  currentLanguage: AppLanguage,
  wishlistCount: Int,
  cartCount: Int,
  onLanguageToggle: () -> Unit,
  onPincodeClick: () -> Unit,
  onWishlistClick: () -> Unit,
  onCartClick: () -> Unit,
  onAiAssistantClick: (() -> Unit)? = null,
  modifier: Modifier = Modifier
) {
  Surface(
    color = ApnaBluePrimary,
    tonalElevation = 4.dp,
    shadowElevation = 4.dp,
    modifier = modifier.fillMaxWidth()
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .statusBarsPadding()
        .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        // ApnaCart Brand Logo & Title (Flipkart-inspired blue header)
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.testTag("app_logo_title")
        ) {
          Box(
            modifier = Modifier
              .size(36.dp)
              .clip(RoundedCornerShape(8.dp))
              .background(Color.White)
              .padding(2.dp),
            contentAlignment = Alignment.Center
          ) {
            Image(
              painter = painterResource(id = R.drawable.ic_apna_logo),
              contentDescription = "ApnaCart Logo",
              contentScale = ContentScale.Fit,
              modifier = Modifier.size(32.dp)
            )
          }

          Spacer(modifier = Modifier.width(10.dp))

          Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Text(
                text = "Apna",
                fontSize = 20.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Color.White
              )
              Text(
                text = "Cart",
                fontSize = 20.sp,
                fontWeight = FontWeight.ExtraBold,
                fontStyle = FontStyle.Italic,
                color = Color(0xFFFFE500) // Golden-yellow Flipkart style accent
              )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
              Text(
                text = "Explore ",
                fontSize = 10.sp,
                color = Color.White.copy(alpha = 0.9f)
              )
              Text(
                text = "Plus ✦",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                fontStyle = FontStyle.Italic,
                color = Color(0xFFFFE500)
              )
            }
          }
        }

        // Action Icons: Language switcher + Wishlist + Cart with Badges
        Row(verticalAlignment = Alignment.CenterVertically) {
          // Language Switcher Chip
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(16.dp))
              .background(Color.White.copy(alpha = 0.2f))
              .clickable { onLanguageToggle() }
              .padding(horizontal = 8.dp, vertical = 4.dp)
              .testTag("top_bar_language_toggle"),
            contentAlignment = Alignment.Center
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = Icons.Default.Language,
                contentDescription = "Language",
                tint = Color.White,
                modifier = Modifier.size(14.dp)
              )
              Spacer(modifier = Modifier.width(4.dp))
              Text(
                text = if (currentLanguage == AppLanguage.ENGLISH) "हिन्दी" else "EN",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
              )
            }
          }

          // AI Assistant Shortcut
          if (onAiAssistantClick != null) {
            IconButton(
              onClick = onAiAssistantClick,
              modifier = Modifier.testTag("top_bar_ai_assistant_button")
            ) {
              Box(
                modifier = Modifier
                  .size(32.dp)
                  .clip(CircleShape)
                  .background(Color(0xFFFFD200)),
                contentAlignment = Alignment.Center
              ) {
                Icon(
                  imageVector = Icons.Default.SmartToy,
                  contentDescription = "AI Shopping Assistant",
                  tint = ApnaBluePrimary,
                  modifier = Modifier.size(18.dp)
                )
              }
            }
          }

          IconButton(
            onClick = onWishlistClick,
            modifier = Modifier.testTag("top_bar_wishlist_button")
          ) {
            BadgedBox(
              badge = {
                if (wishlistCount > 0) {
                  Badge(
                    containerColor = ApnaActionOrange,
                    contentColor = Color.White
                  ) {
                    Text("$wishlistCount")
                  }
                }
              }
            ) {
              Icon(
                imageVector = if (wishlistCount > 0) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                contentDescription = "Wishlist",
                tint = Color.White
              )
            }
          }

          IconButton(
            onClick = onCartClick,
            modifier = Modifier.testTag("top_bar_cart_button")
          ) {
            BadgedBox(
              badge = {
                if (cartCount > 0) {
                  Badge(
                    containerColor = ApnaActionOrange,
                    contentColor = Color.White
                  ) {
                    Text("$cartCount")
                  }
                }
              }
            ) {
              Icon(
                imageVector = if (cartCount > 0) Icons.Filled.ShoppingBag else Icons.Outlined.ShoppingBag,
                contentDescription = "Cart",
                tint = Color.White
              )
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(6.dp))

      // Delivery Pincode Strip in Header
      Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
          .clip(RoundedCornerShape(6.dp))
          .background(Color.White.copy(alpha = 0.15f))
          .clickable { onPincodeClick() }
          .padding(horizontal = 8.dp, vertical = 4.dp)
          .testTag("delivery_pincode_strip")
      ) {
        Icon(
          imageVector = Icons.Default.LocationOn,
          contentDescription = "Location",
          tint = Color(0xFFFFE500),
          modifier = Modifier.size(14.dp)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
          text = "${ApnaStrings.get("deliver_to", currentLanguage)}: ",
          fontSize = 11.sp,
          color = Color.White.copy(alpha = 0.9f)
        )
        Text(
          text = "$deliveryPincode (${ApnaStrings.get("tap_to_change", currentLanguage)})",
          fontSize = 11.sp,
          fontWeight = FontWeight.Bold,
          color = Color.White
        )
        Icon(
          imageVector = Icons.Default.KeyboardArrowDown,
          contentDescription = null,
          tint = Color.White.copy(alpha = 0.8f),
          modifier = Modifier.size(14.dp)
        )
      }
    }
  }
}
