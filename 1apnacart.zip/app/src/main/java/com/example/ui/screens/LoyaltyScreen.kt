package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Diamond
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Percent
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.ui.theme.ApnaBluePrimary
import com.example.ui.theme.ApnaDiscountGreen
import com.example.ui.viewmodel.ApnaCartViewModel

@Composable
fun LoyaltyScreen(
  viewModel: ApnaCartViewModel,
  onBack: () -> Unit,
  modifier: Modifier = Modifier
) {
  BackHandler { onBack() }
  val membership by viewModel.membership.collectAsState()

  Surface(
    color = MaterialTheme.colorScheme.background,
    modifier = modifier.fillMaxSize()
  ) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .statusBarsPadding()
    ) {
      // Header
      Surface(
        color = ApnaBluePrimary,
        tonalElevation = 4.dp,
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 12.dp)
        ) {
          IconButton(onClick = onBack) {
            Icon(
              imageVector = Icons.AutoMirrored.Filled.ArrowBack,
              contentDescription = "Back",
              tint = Color.White
            )
          }
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = "ApnaClub VIP Membership",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
          )
        }
      }

      LazyColumn(
        modifier = Modifier
          .fillMaxSize()
          .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
      ) {
        // Membership VIP Pass
        item {
          Card(
            shape = RoundedCornerShape(16.dp),
            elevation = CardDefaults.cardElevation(8.dp),
            modifier = Modifier
              .fillMaxWidth()
              .testTag("vip_membership_card")
          ) {
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .background(
                  brush = Brush.horizontalGradient(
                    listOf(
                      Color(0xFF1E293B),
                      Color(0xFF0F172A)
                    )
                  )
                )
                .padding(20.dp)
            ) {
              Column {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                      imageVector = Icons.Default.Diamond,
                      contentDescription = null,
                      tint = Color(0xFFFFD200),
                      modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                      text = "APNACLUB VIP",
                      fontSize = 14.sp,
                      fontWeight = FontWeight.ExtraBold,
                      color = Color(0xFFFFD200),
                      letterSpacing = 1.sp
                    )
                  }
                  Box(
                    modifier = Modifier
                      .clip(RoundedCornerShape(12.dp))
                      .background(Color(membership.tier.badgeColorHex))
                      .padding(horizontal = 10.dp, vertical = 4.dp)
                  ) {
                    Text(
                      text = membership.tier.label,
                      fontSize = 11.sp,
                      fontWeight = FontWeight.Bold,
                      color = Color.White
                    )
                  }
                }

                Spacer(modifier = Modifier.height(24.dp))

                Text(
                  text = "Cumulative Qualifying Spend",
                  fontSize = 11.sp,
                  color = Color.White.copy(alpha = 0.7f)
                )
                Text(
                  text = "₹${membership.totalSpend}",
                  fontSize = 28.sp,
                  fontWeight = FontWeight.ExtraBold,
                  color = Color.White
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Progress to Gold / Platinum
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween
                ) {
                  Text(
                    text = "Next Tier: Gold VIP (₹2000)",
                    fontSize = 11.sp,
                    color = Color.White.copy(alpha = 0.8f)
                  )
                  Text(
                    text = "${(membership.nextTierProgress * 100).toInt()}%",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFFFD200)
                  )
                }
                Spacer(modifier = Modifier.height(6.dp))
                LinearProgressIndicator(
                  progress = { membership.nextTierProgress },
                  color = Color(0xFFFFD200),
                  trackColor = Color.White.copy(alpha = 0.2f),
                  modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp))
                )
              }
            }
          }
        }

        // Tiers Breakdown
        item {
          Text(text = "Membership Tiers & Perks", fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }

        item {
          TierCard(
            tier = MembershipTier.SILVER,
            isCurrent = membership.tier == MembershipTier.SILVER,
            criteria = "Default on joining ApnaCart",
            perks = listOf("Standard order rewards (1 coin per ₹100)", "7-day easy returns policy")
          )
        }

        item {
          TierCard(
            tier = MembershipTier.GOLD,
            isCurrent = membership.tier == MembershipTier.GOLD,
            criteria = "Spend ₹2,000+ in verified purchases",
            perks = listOf("Flat 5% Extra Member Discount on all products", "FREE Delivery on all orders (no minimum order limit)", "Early access to Diwali & festive flash sales")
          )
        }

        item {
          TierCard(
            tier = MembershipTier.PLATINUM,
            isCurrent = membership.tier == MembershipTier.PLATINUM,
            criteria = "Spend ₹5,000+ in verified purchases",
            perks = listOf("Flat 10% Extra VIP Discount across full catalog", "FREE 24-Hour Express Air Delivery", "Dedicated VIP WhatsApp & Priority Concierge Support")
          )
        }
      }
    }
  }
}

@Composable
private fun TierCard(
  tier: MembershipTier,
  isCurrent: Boolean,
  criteria: String,
  perks: List<String>
) {
  Card(
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(containerColor = Color.White),
    elevation = CardDefaults.cardElevation(2.dp),
    modifier = Modifier
      .fillMaxWidth()
      .then(if (isCurrent) Modifier.border(2.dp, ApnaBluePrimary, RoundedCornerShape(12.dp)) else Modifier)
  ) {
    Column(modifier = Modifier.padding(16.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Box(
            modifier = Modifier
              .size(10.dp)
              .clip(CircleShape)
              .background(Color(tier.badgeColorHex))
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(text = tier.label, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        }
        if (isCurrent) {
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(6.dp))
              .background(ApnaBluePrimary)
              .padding(horizontal = 8.dp, vertical = 2.dp)
          ) {
            Text(text = "CURRENT TIER", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.White)
          }
        }
      }
      Spacer(modifier = Modifier.height(4.dp))
      Text(text = criteria, fontSize = 11.sp, color = Color.Gray)
      Spacer(modifier = Modifier.height(10.dp))
      perks.forEach { perk ->
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.padding(vertical = 2.dp)
        ) {
          Icon(
            imageVector = Icons.Default.Check,
            contentDescription = null,
            tint = ApnaDiscountGreen,
            modifier = Modifier.size(14.dp)
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(text = perk, fontSize = 12.sp, color = Color(0xFF374151))
        }
      }
    }
  }
}
