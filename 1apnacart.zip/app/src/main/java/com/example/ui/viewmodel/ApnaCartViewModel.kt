package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.model.Address
import com.example.model.AppLanguage
import com.example.model.OfferCoupon
import com.example.model.Order
import com.example.model.OrderStatus
import com.example.model.Product
import com.example.model.UserProfile
import com.example.repository.ApnaCartRepository
import com.example.util.ConnectivityObserver
import com.example.util.NetworkConnectivityObserver
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface PaymentResultState {
  object Idle : PaymentResultState
  object Processing : PaymentResultState
  data class Failure(val reason: String, val canRetry: Boolean = true) : PaymentResultState
  data class Success(val order: Order) : PaymentResultState
}

enum class MainTab {
  HOME,
  CATEGORIES,
  OFFERS,
  WISHLIST,
  CART,
  PROFILE
}

sealed interface ScreenDestination {
  object Splash : ScreenDestination
  object MainTabs : ScreenDestination
  data class ProductDetail(val product: Product) : ScreenDestination
  object Checkout : ScreenDestination
  data class OrderPlacedSuccess(val order: Order) : ScreenDestination
  data class OrderTracking(val orderId: String) : ScreenDestination
  object OrderHistory : ScreenDestination
  object AddressManager : ScreenDestination
  object DemoAdmin : ScreenDestination
  object EditProfile : ScreenDestination
  object OtpLogin : ScreenDestination
  object Notifications : ScreenDestination
  object AiAssistant : ScreenDestination
  object WalletScreen : ScreenDestination
  object GiftCardsScreen : ScreenDestination
  object RewardsScreen : ScreenDestination
  object ReferralScreen : ScreenDestination
  object LoyaltyScreen : ScreenDestination
  object PhotoSearchScreen : ScreenDestination
}

enum class SortOption(val displayNameKey: String) {
  POPULAR("sort_popular"),
  PRICE_LOW_HIGH("sort_price_low_high"),
  PRICE_HIGH_LOW("sort_price_high_low"),
  RATING_HIGH("sort_rating")
}

class ApnaCartViewModel(
  application: Application,
  private val repository: ApnaCartRepository
) : AndroidViewModel(application) {

  // Required by AndroidViewModelFactory / SavedStateViewModelFactory
  constructor(application: Application) : this(
    application,
    ApnaCartRepository(application.applicationContext)
  )

  // For testing with mock or in-memory repository
  constructor(repository: ApnaCartRepository) : this(
    Application(),
    repository
  )

  // Default no-arg constructor fallback
  constructor() : this(
    Application(),
    ApnaCartRepository()
  )

  // Navigation State
  private val _currentScreen = MutableStateFlow<ScreenDestination>(ScreenDestination.Splash)
  val currentScreen: StateFlow<ScreenDestination> = _currentScreen.asStateFlow()

  private val _currentTab = MutableStateFlow(MainTab.HOME)
  val currentTab: StateFlow<MainTab> = _currentTab.asStateFlow()

  // Network Connectivity State
  private val connectivityObserver = NetworkConnectivityObserver(application)
  val isOnline: StateFlow<Boolean> = connectivityObserver.observe()
    .map { it == ConnectivityObserver.Status.Available }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), connectivityObserver.isCurrentlyConnected())

  // Payment Processing & Error State
  private val _paymentResultState = MutableStateFlow<PaymentResultState>(PaymentResultState.Idle)
  val paymentResultState: StateFlow<PaymentResultState> = _paymentResultState.asStateFlow()

  // Search & Filter State
  private val _searchQuery = MutableStateFlow("")
  val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

  private val _selectedCategory = MutableStateFlow("all")
  val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

  private val _sortOption = MutableStateFlow(SortOption.POPULAR)
  val sortOption: StateFlow<SortOption> = _sortOption.asStateFlow()

  private val _onlyUnder499 = MutableStateFlow(false)
  val onlyUnder499: StateFlow<Boolean> = _onlyUnder499.asStateFlow()

  private val _onlyInStock = MutableStateFlow(false)
  val onlyInStock: StateFlow<Boolean> = _onlyInStock.asStateFlow()

  // Repository Data Flows
  val products = repository.products
  val wishlistIds = repository.wishlistIds
  val cartItems = repository.cartItems
  val addresses = repository.addresses
  val selectedAddress = repository.selectedAddress
  val orders = repository.orders
  val deliveryPincode = repository.deliveryPincode
  val availableCoupons = repository.availableCoupons
  val appliedCoupon = repository.appliedCoupon
  val currentLanguage = repository.currentLanguage
  val userProfile = repository.userProfile
  val authUser = repository.authUser
  val notifications = repository.notifications
  val recentlyViewedIds = repository.recentlyViewedIds

  val firebaseUser = repository.firebaseUser
  val adminStatus = repository.adminStatus
  val storeSettings = repository.storeSettings

  // Advanced Feature Flows
  val walletBalance = repository.walletBalance
  val walletTransactions = repository.walletTransactions
  val rewardPoints = repository.rewardPoints
  val rewardTransactions = repository.rewardTransactions
  val priceAlerts = repository.priceAlerts
  val giftCards = repository.giftCards
  val productQuestions = repository.productQuestions
  val membership = repository.membership
  val referralData = repository.referralData
  val fraudAlerts = repository.fraudAlerts
  val aiChatMessages = repository.aiChatMessages

  val isAdminAuthenticated: StateFlow<Boolean> = repository.adminStatus
    .combine(repository.firebaseUser) { status, user -> status.isAuthorizedOwner && user != null }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

  val recentlyViewedProducts: StateFlow<List<Product>> = combine(
    products,
    recentlyViewedIds
  ) { allProducts, viewedIds ->
    viewedIds.mapNotNull { id -> allProducts.find { it.id == id } }
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  fun getSimilarProducts(product: Product): List<Product> {
    return products.value.filter { it.category == product.category && it.id != product.id }.take(6)
  }

  // UI Feedback Events
  private val _toastEvent = MutableSharedFlow<String>()
  val toastEvent: SharedFlow<String> = _toastEvent.asSharedFlow()

  private data class FilterCriteria(
    val query: String,
    val category: String,
    val sort: SortOption,
    val under499: Boolean,
    val inStockOnly: Boolean
  )

  private val filterCriteria = combine(
    _searchQuery,
    _selectedCategory,
    _sortOption,
    _onlyUnder499,
    _onlyInStock
  ) { query, category, sort, under499, inStockOnly ->
    FilterCriteria(query, category, sort, under499, inStockOnly)
  }

  // Filtered & Sorted Products
  val filteredProducts: StateFlow<List<Product>> = combine(
    products,
    filterCriteria
  ) { allProducts, criteria ->
    var list = allProducts

    // Category filter
    if (criteria.category != "all") {
      list = list.filter { it.category.equals(criteria.category, ignoreCase = true) }
    }

    // Under 499 filter
    if (criteria.under499) {
      list = list.filter { it.price < 500 }
    }

    // In Stock filter
    if (criteria.inStockOnly) {
      list = list.filter { it.inStock }
    }

    // Search query
    if (criteria.query.isNotBlank()) {
      val q = criteria.query.trim().lowercase()
      list = list.filter {
        it.title.lowercase().contains(q) ||
          it.brand.lowercase().contains(q) ||
          it.category.lowercase().contains(q) ||
          it.description.lowercase().contains(q)
      }
    }

    // Sorting
    when (criteria.sort) {
      SortOption.POPULAR -> list.sortedByDescending { it.rating * it.reviewCount }
      SortOption.PRICE_LOW_HIGH -> list.sortedBy { it.price }
      SortOption.PRICE_HIGH_LOW -> list.sortedByDescending { it.price }
      SortOption.RATING_HIGH -> list.sortedByDescending { it.rating }
    }
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val wishlistProducts: StateFlow<List<Product>> = combine(
    products,
    wishlistIds
  ) { allProducts, wishIds ->
    allProducts.filter { wishIds.contains(it.id) }
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  fun setTab(tab: MainTab) {
    _currentTab.value = tab
    _currentScreen.value = ScreenDestination.MainTabs
  }

  fun navigateTo(destination: ScreenDestination) {
    _currentScreen.value = destination
  }

  fun navigateBack(): Boolean {
    val current = _currentScreen.value
    if (current !is ScreenDestination.MainTabs) {
      _currentScreen.value = ScreenDestination.MainTabs
      return true
    }
    return false
  }

  fun setLanguage(lang: AppLanguage) {
    repository.setLanguage(lang)
    viewModelScope.launch {
      _toastEvent.emit("Language changed to ${lang.nativeName}")
    }
  }

  fun updateUserProfile(name: String, phone: String, email: String) {
    repository.updateUserProfile(name, phone, email)
    viewModelScope.launch {
      _toastEvent.emit("Demo profile updated!")
    }
  }

  fun setSearchQuery(query: String) {
    _searchQuery.value = query
  }

  fun selectCategory(category: String) {
    _selectedCategory.value = category
  }

  fun setSortOption(option: SortOption) {
    _sortOption.value = option
  }

  fun toggleUnder499Filter() {
    _onlyUnder499.value = !_onlyUnder499.value
  }

  fun toggleInStockFilter() {
    _onlyInStock.value = !_onlyInStock.value
  }

  fun toggleWishlist(product: Product) {
    val added = repository.toggleWishlist(product.id)
    viewModelScope.launch {
      _toastEvent.emit(if (added) "Saved to Wishlist ❤️" else "Removed from Wishlist")
    }
  }

  fun addToCart(product: Product, size: String, color: String, quantity: Int = 1) {
    val result = repository.addToCart(product, size, color, quantity)
    viewModelScope.launch {
      _toastEvent.emit(result.second)
    }
  }

  fun addToCart(product: Product) {
    val defaultSize = product.availableSizes.firstOrNull() ?: "Free Size"
    val defaultColor = product.availableColors.firstOrNull() ?: "Standard"
    addToCart(product, defaultSize, defaultColor, 1)
  }

  fun buyNow(product: Product, size: String, color: String) {
    repository.addToCart(product, size, color, 1)
    _currentScreen.value = ScreenDestination.Checkout
  }

  fun updateCartQuantity(cartItemId: String, newQty: Int) {
    val success = repository.updateCartQuantity(cartItemId, newQty)
    if (!success) {
      viewModelScope.launch {
        _toastEvent.emit("Cannot exceed demo stock quantity")
      }
    }
  }

  fun removeCartItem(cartItemId: String) {
    repository.removeCartItem(cartItemId)
    viewModelScope.launch {
      _toastEvent.emit("Item removed from Cart")
    }
  }

  fun applyCoupon(code: String) {
    val result = repository.applyCoupon(code)
    viewModelScope.launch {
      _toastEvent.emit(result.second)
    }
  }

  fun removeCoupon() {
    repository.removeCoupon()
    viewModelScope.launch {
      _toastEvent.emit("Coupon removed")
    }
  }

  fun selectAddress(address: Address) {
    repository.selectAddress(address)
  }

  fun addNewAddress(address: Address) {
    repository.addNewAddress(address)
    viewModelScope.launch {
      _toastEvent.emit("Address saved successfully!")
    }
  }

  fun deleteAddress(addressId: String) {
    repository.deleteAddress(addressId)
    viewModelScope.launch {
      _toastEvent.emit("Address deleted")
    }
  }

  fun updateDeliveryPincode(pincode: String) {
    repository.setDeliveryPincode(pincode)
    viewModelScope.launch {
      _toastEvent.emit("Delivery location set to $pincode")
    }
  }

  fun dismissSplash() {
    _currentScreen.value = ScreenDestination.MainTabs
  }

  fun clearPaymentError() {
    _paymentResultState.value = PaymentResultState.Idle
  }

  fun processOrderPayment(
    paymentMethod: String,
    deliverySpeed: String = "Standard",
    useWallet: Boolean = false,
    useRewardPoints: Boolean = false,
    simulateFailure: Boolean = false,
    onSuccess: (Order) -> Unit = {}
  ) {
    viewModelScope.launch {
      _paymentResultState.value = PaymentResultState.Processing
      // Realistic simulation delay for bank/network handshake
      delay(1200)

      if (simulateFailure) {
        _paymentResultState.value = PaymentResultState.Failure(
          reason = "Payment declined by issuing bank (Simulated Sandbox Timeout). No amount was charged. Your cart items are preserved.",
          canRetry = true
        )
        _toastEvent.emit("Payment failed: Bank server timeout")
        return@launch
      }

      val order = repository.placeDemoOrder(paymentMethod, deliverySpeed, useWallet, useRewardPoints)
      _paymentResultState.value = PaymentResultState.Success(order)
      _currentScreen.value = ScreenDestination.OrderPlacedSuccess(order)
      onSuccess(order)
    }
  }

  fun placeDemoOrder(
    paymentMethod: String,
    deliverySpeed: String = "Standard",
    useWallet: Boolean = false,
    useRewardPoints: Boolean = false
  ) {
    processOrderPayment(paymentMethod, deliverySpeed, useWallet, useRewardPoints, simulateFailure = false)
  }

  fun togglePriceAlert(productId: String, currentPrice: Int) {
    val active = repository.togglePriceAlert(productId, currentPrice)
    viewModelScope.launch {
      _toastEvent.emit(if (active) "Price drop alert enabled!" else "Price alert disabled")
    }
  }

  fun redeemGiftCard(code: String) {
    val (success, msg) = repository.redeemGiftCard(code)
    viewModelScope.launch { _toastEvent.emit(msg) }
  }

  fun adminCreateGiftCard(code: String, amount: Int) {
    val success = repository.adminCreateGiftCard(code, amount)
    viewModelScope.launch {
      _toastEvent.emit(if (success) "Gift card '$code' created!" else "Failed to create gift card")
    }
  }

  fun askProductQuestion(productId: String, question: String) {
    repository.askProductQuestion(productId, question)
    viewModelScope.launch { _toastEvent.emit("Question submitted for review!") }
  }

  fun adminAnswerQuestion(questionId: String, answer: String) {
    repository.adminAnswerQuestion(questionId, answer)
    viewModelScope.launch { _toastEvent.emit("Answer published!") }
  }

  fun adminResolveFraudAlert(alertId: String) {
    repository.adminResolveFraudAlert(alertId)
    viewModelScope.launch { _toastEvent.emit("Fraud alert marked as reviewed") }
  }

  fun submitReferralCode(code: String) {
    val (success, msg) = repository.submitReferralCode(code)
    viewModelScope.launch { _toastEvent.emit(msg) }
  }

  fun sendAiAssistantQuery(userInput: String) {
    repository.sendAiAssistantQuery(userInput)
  }

  fun performPhotoSearch(label: String): List<Product> {
    return repository.performPhotoSearch(label)
  }

  fun calculateSizeRecommendation(product: Product, chestInch: Int, waistInch: Int): com.example.model.SizeRecommendation {
    return repository.calculateSizeRecommendation(product, chestInch, waistInch)
  }

  fun simulateAdvanceTracking(orderId: String) {
    repository.advanceTrackingStatus(orderId)
    viewModelScope.launch {
      _toastEvent.emit("Simulated courier status updated!")
    }
  }

  fun cancelOrder(orderId: String) {
    repository.cancelOrder(orderId)
    viewModelScope.launch {
      _toastEvent.emit("Demo order cancelled")
    }
  }

  // --- DEMO ADMIN ACTIONS ---

  fun adminAddProduct(newProduct: Product) {
    repository.adminAddProduct(newProduct)
    viewModelScope.launch {
      _toastEvent.emit("Product added to demo catalog!")
    }
  }

  fun adminUpdateStockAndPrice(productId: String, newStock: Int, newPrice: Int) {
    repository.adminUpdateStockAndPrice(productId, newStock, newPrice)
    viewModelScope.launch {
      _toastEvent.emit("Product stock and price updated!")
    }
  }

  fun adminDeleteProduct(productId: String) {
    repository.adminDeleteProduct(productId)
    viewModelScope.launch {
      _toastEvent.emit("Product deleted from demo catalog")
    }
  }

  fun adminUpdateOrderStatus(orderId: String, newStatus: OrderStatus) {
    repository.adminUpdateOrderStatus(orderId, newStatus)
    viewModelScope.launch {
      _toastEvent.emit("Order status updated to ${newStatus.label}")
    }
  }

  fun adminAddCoupon(coupon: OfferCoupon) {
    repository.adminAddCoupon(coupon)
    viewModelScope.launch {
      _toastEvent.emit("Coupon '${coupon.code}' created!")
    }
  }

  fun adminDeleteCoupon(code: String) {
    repository.adminDeleteCoupon(code)
    viewModelScope.launch {
      _toastEvent.emit("Coupon '$code' deleted")
    }
  }

  fun resetAllDemoData() {
    repository.resetAllDemoData()
    viewModelScope.launch {
      _toastEvent.emit("All demo data reset to default sample catalog!")
    }
  }

  suspend fun signInWithGoogleCredential(credential: com.google.firebase.auth.AuthCredential): Result<com.google.firebase.auth.FirebaseUser> {
    val res = repository.signInWithCredential(credential)
    if (res.isSuccess) {
      _toastEvent.emit("Signed in as ${res.getOrNull()?.email}")
    } else {
      _toastEvent.emit("Sign in failed: ${res.exceptionOrNull()?.message}")
    }
    return res
  }

  fun adminUpdateStoreSettings(settings: com.example.model.StoreSettings) {
    repository.adminUpdateStoreSettings(settings)
    viewModelScope.launch {
      _toastEvent.emit("Store integration settings updated!")
    }
  }

  fun requestOtp(phone: String): Pair<Boolean, String> {
    if (phone.length == 10 && phone.all { it.isDigit() }) {
      return Pair(true, "123456")
    }
    return Pair(false, "Please enter a valid 10-digit mobile number")
  }

  fun verifyOtp(phone: String, inputOtp: String, fullName: String = ""): Pair<Boolean, String> {
    if (inputOtp.trim() == "123456" || inputOtp.trim().length == 6) {
      repository.updateProfile(if (fullName.isNotBlank()) fullName else "Customer $phone", "user_$phone@apnacart.in", phone)
      return Pair(true, "Mobile verified successfully!")
    }
    return Pair(false, "Invalid OTP. Use demo code '123456'")
  }

  fun logoutCustomer() {
    repository.logout()
    viewModelScope.launch { _toastEvent.emit("Logged out from ApnaCart session") }
  }

  fun logoutAdmin() {
    repository.logout()
    viewModelScope.launch { _toastEvent.emit("Logged out of Admin Session") }
  }

  fun recordProductView(productId: String) {
    repository.recordProductView(productId)
  }

  fun markNotificationRead(id: String) {
    repository.markNotificationRead(id)
  }

  fun getAdminStats(): com.example.model.AdminDashboardStats {
    return repository.getAdminStats()
  }
}
