package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Search
import android.Manifest
import android.app.Activity
import android.content.Intent
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.Diamond
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.Stars
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.DemoDataProvider
import com.example.model.AppLanguage
import com.example.model.ApnaStrings
import com.example.model.Product
import com.example.ui.components.ProductCard
import com.example.ui.theme.ApnaActionOrange
import com.example.ui.theme.ApnaBlueContainer
import com.example.ui.theme.ApnaBlueDark
import com.example.ui.theme.ApnaBluePrimary
import com.example.ui.theme.ApnaDiscountGreen
import com.example.ui.theme.ApnaDiscountGreenBg
import com.example.ui.viewmodel.ApnaCartViewModel
import com.example.ui.viewmodel.ScreenDestination
import com.example.ui.viewmodel.SortOption

@Composable
fun HomeScreen(
  viewModel: ApnaCartViewModel,
  onProductClick: (Product) -> Unit,
  modifier: Modifier = Modifier
) {
  val searchQuery by viewModel.searchQuery.collectAsState()
  val selectedCategory by viewModel.selectedCategory.collectAsState()
  val sortOption by viewModel.sortOption.collectAsState()
  val onlyUnder499 by viewModel.onlyUnder499.collectAsState()
  val onlyInStock by viewModel.onlyInStock.collectAsState()
  val filteredProducts by viewModel.filteredProducts.collectAsState()
  val wishlistIds by viewModel.wishlistIds.collectAsState()
  val currentLanguage by viewModel.currentLanguage.collectAsState()
  val recentlyViewedProducts by viewModel.recentlyViewedProducts.collectAsState()

  var showSortMenu by remember { mutableStateOf(false) }
  val pagerState = rememberPagerState(pageCount = { DemoDataProvider.heroBanners.size })

  LazyVerticalGrid(
    columns = GridCells.Fixed(2),
    contentPadding = PaddingValues(start = 10.dp, end = 10.dp, top = 8.dp, bottom = 96.dp),
    horizontalArrangement = Arrangement.spacedBy(8.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp),
    modifier = modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
  ) {
    // 1. Search Bar with blue accents, Camera & Voice Search
    item(span = { GridItemSpan(2) }) {
      var showVoiceDialog by remember { mutableStateOf(false) }
      var voiceSpokenText by remember { mutableStateOf("") }
      var isListening by remember { mutableStateOf(false) }

      val speechLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
      ) { result ->
        isListening = false
        if (result.resultCode == Activity.RESULT_OK) {
          val spokenMatches = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
          if (!spokenMatches.isNullOrEmpty()) {
            voiceSpokenText = spokenMatches[0]
          }
        }
      }

      val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
      ) { isGranted ->
        showVoiceDialog = true
        if (isGranted) {
          try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
              putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
              putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
              putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak in English or Hindi...")
            }
            isListening = true
            speechLauncher.launch(intent)
          } catch (e: Exception) {
            isListening = false
          }
        }
      }

      if (showVoiceDialog) {
        AlertDialog(
          onDismissRequest = { showVoiceDialog = false },
          title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = Icons.Default.Mic,
                contentDescription = null,
                tint = ApnaBluePrimary,
                modifier = Modifier.size(24.dp)
              )
              Spacer(modifier = Modifier.width(8.dp))
              Text("Voice Search / बोलकर खोजें", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
          },
          text = {
            Column {
              Text(
                text = if (isListening) "Listening... speak now in Hindi or English" else "Edit or confirm your spoken search words:",
                fontSize = 12.sp,
                color = Color.Gray
              )
              Spacer(modifier = Modifier.height(10.dp))
              OutlinedTextField(
                value = voiceSpokenText,
                onValueChange = { voiceSpokenText = it },
                placeholder = { Text("E.g., Men's Jeans, कुर्ती, Cotton Shirt", fontSize = 12.sp) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
              )
              Spacer(modifier = Modifier.height(12.dp))
              Text(text = "Quick suggestions:", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = Color.Gray)
              Spacer(modifier = Modifier.height(6.dp))
              Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
              ) {
                listOf("Men's Jeans under ₹700", "Ethnic Kurti", "Silk Saree", "Cotton Shirts").forEach { suggestion ->
                  Box(
                    modifier = Modifier
                      .clip(RoundedCornerShape(12.dp))
                      .background(Color(0xFFE8F0FE))
                      .clickable { voiceSpokenText = suggestion }
                      .padding(horizontal = 8.dp, vertical = 4.dp)
                  ) {
                    Text(text = suggestion, fontSize = 11.sp, color = ApnaBluePrimary)
                  }
                }
              }
            }
          },
          confirmButton = {
            Button(
              onClick = {
                if (voiceSpokenText.isNotBlank()) {
                  viewModel.setSearchQuery(voiceSpokenText)
                }
                showVoiceDialog = false
              },
              colors = ButtonDefaults.buttonColors(containerColor = ApnaBluePrimary)
            ) {
              Text("Search")
            }
          },
          dismissButton = {
            TextButton(onClick = { showVoiceDialog = false }) {
              Text("Cancel")
            }
          }
        )
      }

      Column(modifier = Modifier.fillMaxWidth()) {
        OutlinedTextField(
          value = searchQuery,
          onValueChange = { viewModel.setSearchQuery(it) },
          placeholder = {
            Text(
              text = ApnaStrings.get("search_hint", currentLanguage),
              fontSize = 13.sp,
              color = Color.Gray,
              maxLines = 1
            )
          },
          leadingIcon = {
            Icon(
              imageVector = Icons.Default.Search,
              contentDescription = "Search",
              tint = ApnaBluePrimary
            )
          },
          trailingIcon = {
            Row(verticalAlignment = Alignment.CenterVertically) {
              if (searchQuery.isNotEmpty()) {
                IconButton(onClick = { viewModel.setSearchQuery("") }) {
                  Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Clear",
                    tint = Color.Gray
                  )
                }
              }
              // Photo Search Camera Icon
              IconButton(
                onClick = { viewModel.navigateTo(ScreenDestination.PhotoSearchScreen) },
                modifier = Modifier.testTag("home_camera_search_button")
              ) {
                Icon(
                  imageVector = Icons.Default.CameraAlt,
                  contentDescription = "Search by Photo",
                  tint = ApnaBluePrimary
                )
              }
              // Voice Search Mic Icon
              IconButton(
                onClick = {
                  micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                },
                modifier = Modifier.testTag("home_voice_search_button")
              ) {
                Icon(
                  imageVector = Icons.Default.Mic,
                  contentDescription = "Voice Search",
                  tint = ApnaBluePrimary
                )
              }
            }
          },
          singleLine = true,
          shape = RoundedCornerShape(8.dp),
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = ApnaBluePrimary,
            unfocusedBorderColor = Color(0xFFD0D7E2),
            focusedContainerColor = Color.White,
            unfocusedContainerColor = Color.White
          ),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("home_search_bar")
        )
      }
    }

    // Quick Feature Shortcuts Ribbon (AI Assistant, Wallet, SuperCoins, Refer, VIP)
    item(span = { GridItemSpan(2) }) {
      val walletBal by viewModel.walletBalance.collectAsState()
      val rewardsPoints by viewModel.rewardPoints.collectAsState()

      Row(
        modifier = Modifier
          .fillMaxWidth()
          .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        // 1. AI Assistant Shortcut
        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(
              Brush.horizontalGradient(
                listOf(Color(0xFF0D47A1), ApnaBluePrimary)
              )
            )
            .clickable { viewModel.navigateTo(ScreenDestination.AiAssistant) }
            .padding(horizontal = 12.dp, vertical = 7.dp)
            .testTag("quick_shortcut_ai")
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Default.AutoAwesome,
              contentDescription = null,
              tint = Color(0xFFFFD200),
              modifier = Modifier.size(15.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = "Ask AI Assistant",
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold,
              color = Color.White
            )
          }
        }

        // 2. Wallet Shortcut
        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(Color(0xFFE8F5E9))
            .border(1.dp, Color(0xFFC8E6C9), RoundedCornerShape(20.dp))
            .clickable { viewModel.navigateTo(ScreenDestination.WalletScreen) }
            .padding(horizontal = 12.dp, vertical = 7.dp)
            .testTag("quick_shortcut_wallet")
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Default.AccountBalanceWallet,
              contentDescription = null,
              tint = ApnaDiscountGreen,
              modifier = Modifier.size(15.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = "Wallet: ₹$walletBal",
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold,
              color = Color(0xFF2E7D32)
            )
          }
        }

        // 3. Rewards / SuperCoins Shortcut
        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(Color(0xFFFFF8E1))
            .border(1.dp, Color(0xFFFFECB3), RoundedCornerShape(20.dp))
            .clickable { viewModel.navigateTo(ScreenDestination.RewardsScreen) }
            .padding(horizontal = 12.dp, vertical = 7.dp)
            .testTag("quick_shortcut_rewards")
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Default.Stars,
              contentDescription = null,
              tint = Color(0xFFFFA000),
              modifier = Modifier.size(15.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = "Rewards: $rewardsPoints",
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold,
              color = Color(0xFFF57F17)
            )
          }
        }

        // 4. Refer & Earn
        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(Color(0xFFEDE7F6))
            .border(1.dp, Color(0xFFD1C4E9), RoundedCornerShape(20.dp))
            .clickable { viewModel.navigateTo(ScreenDestination.ReferralScreen) }
            .padding(horizontal = 12.dp, vertical = 7.dp)
            .testTag("quick_shortcut_refer")
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Default.CardGiftcard,
              contentDescription = null,
              tint = Color(0xFF673AB7),
              modifier = Modifier.size(15.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = "Refer: Get ₹100",
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold,
              color = Color(0xFF512DA8)
            )
          }
        }

        // 5. VIP Club
        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(Color(0xFF263238))
            .clickable { viewModel.navigateTo(ScreenDestination.LoyaltyScreen) }
            .padding(horizontal = 12.dp, vertical = 7.dp)
            .testTag("quick_shortcut_vip")
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Default.Diamond,
              contentDescription = null,
              tint = Color(0xFFFFD200),
              modifier = Modifier.size(15.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = "VIP Club",
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold,
              color = Color.White
            )
          }
        }
      }
    }

    // 2. Demo Disclaimer Ribbon
    item(span = { GridItemSpan(2) }) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(6.dp))
          .background(Color(0xFFFFF8E1))
          .border(0.5.dp, Color(0xFFFFB300), RoundedCornerShape(6.dp))
          .padding(horizontal = 8.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Icon(
          imageVector = Icons.Default.Info,
          contentDescription = null,
          tint = Color(0xFFE65100),
          modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
          text = ApnaStrings.get("demo_catalog_notice", currentLanguage),
          fontSize = 11.sp,
          fontWeight = FontWeight.Medium,
          color = Color(0xFF5D4037)
        )
      }
    }

    // 3. Hero Offer Banners Carousel (When not searching)
    if (searchQuery.isBlank()) {
      item(span = { GridItemSpan(2) }) {
        Column(modifier = Modifier.fillMaxWidth()) {
          HorizontalPager(
            state = pagerState,
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(10.dp))
          ) { page ->
            val banner = DemoDataProvider.heroBanners[page]
            Card(
              shape = RoundedCornerShape(10.dp),
              elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
              modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(16f / 9f)
                .clickable {
                  viewModel.selectCategory(banner.categoryTarget)
                }
            ) {
              Box(modifier = Modifier.fillMaxSize()) {
                Image(
                  painter = painterResource(id = banner.drawableRes),
                  contentDescription = banner.title,
                  contentScale = ContentScale.Crop,
                  modifier = Modifier.fillMaxSize()
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(6.dp))

          // Pager Dots
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
          ) {
            repeat(DemoDataProvider.heroBanners.size) { index ->
              val isSelected = pagerState.currentPage == index
              Box(
                modifier = Modifier
                  .padding(horizontal = 3.dp)
                  .size(if (isSelected) 8.dp else 5.dp)
                  .clip(CircleShape)
                  .background(if (isSelected) ApnaBluePrimary else Color.LightGray)
              )
            }
          }
        }
      }

      // 4. Category Shortcuts Strip
      item(span = { GridItemSpan(2) }) {
        Column(modifier = Modifier.fillMaxWidth()) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = ApnaStrings.get("shop_by_category", currentLanguage),
              fontSize = 15.sp,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.onSurface
            )
            Text(
              text = ApnaStrings.get("see_all", currentLanguage),
              fontSize = 12.sp,
              fontWeight = FontWeight.SemiBold,
              color = ApnaBluePrimary,
              modifier = Modifier
                .clickable { viewModel.selectCategory("all") }
                .padding(4.dp)
            )
          }

          Spacer(modifier = Modifier.height(8.dp))

          Row(
            modifier = Modifier
              .fillMaxWidth()
              .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            DemoDataProvider.categories.forEach { cat ->
              val isSelected = selectedCategory.equals(cat.id, ignoreCase = true)
              val label = ApnaStrings.get(cat.nameKey, currentLanguage)

              Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                  .clip(RoundedCornerShape(8.dp))
                  .clickable { viewModel.selectCategory(cat.id) }
                  .padding(4.dp)
                  .testTag("category_chip_${cat.id}")
              ) {
                Box(
                  modifier = Modifier
                    .size(52.dp)
                    .clip(CircleShape)
                    .background(if (isSelected) ApnaBluePrimary else Color.White)
                    .border(
                      width = if (isSelected) 2.dp else 1.dp,
                      color = if (isSelected) ApnaBlueDark else Color(0xFFD6DFEC),
                      shape = CircleShape
                    ),
                  contentAlignment = Alignment.Center
                ) {
                  Text(text = cat.iconEmoji, fontSize = 22.sp)
                }

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                  text = label,
                  fontSize = 10.sp,
                  fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                  color = if (isSelected) ApnaBluePrimary else MaterialTheme.colorScheme.onSurface,
                  textAlign = TextAlign.Center,
                  maxLines = 1
                )
              }
            }
          }
        }
      }

      // Recently Viewed Products
      if (recentlyViewedProducts.isNotEmpty() && searchQuery.isBlank()) {
        item(span = { GridItemSpan(2) }) {
          Column(modifier = Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 4.dp)) {
            Text(
              text = "Recently Viewed Products",
              fontSize = 14.sp,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              recentlyViewedProducts.forEach { itemProd ->
                Card(
                  shape = RoundedCornerShape(8.dp),
                  colors = CardDefaults.cardColors(containerColor = Color.White),
                  elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                  modifier = Modifier
                    .width(130.dp)
                    .clickable { onProductClick(itemProd) }
                    .testTag("recent_product_${itemProd.id}")
                ) {
                  Column(modifier = Modifier.padding(6.dp)) {
                    Box(
                      modifier = Modifier
                        .fillMaxWidth()
                        .height(95.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color(0xFFF8FAFC)),
                      contentAlignment = Alignment.Center
                    ) {
                      if (itemProd.drawableRes != null) {
                        Image(
                          painter = painterResource(id = itemProd.drawableRes),
                          contentDescription = itemProd.title,
                          contentScale = ContentScale.Crop,
                          modifier = Modifier.fillMaxSize()
                        )
                      }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = itemProd.title, fontSize = 11.sp, maxLines = 1, fontWeight = FontWeight.SemiBold)
                    Text(text = "₹${itemProd.price}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = ApnaBlueDark)
                  }
                }
              }
            }
          }
        }
      }

    // 5. Filter Chips & Sort
    item(span = { GridItemSpan(2) }) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        // Sort Dropdown
        Box {
          FilterChip(
            selected = sortOption != SortOption.POPULAR,
            onClick = { showSortMenu = true },
            label = {
              Text(
                text = "${ApnaStrings.get("sort_by", currentLanguage)}: ${ApnaStrings.get(sortOption.displayNameKey, currentLanguage)}",
                fontSize = 11.sp
              )
            },
            leadingIcon = {
              Icon(
                imageVector = Icons.Default.FilterList,
                contentDescription = null,
                modifier = Modifier.size(14.dp)
              )
            },
            trailingIcon = {
              Icon(
                imageVector = Icons.Default.ArrowDropDown,
                contentDescription = null,
                modifier = Modifier.size(16.dp)
              )
            },
            colors = FilterChipDefaults.filterChipColors(
              selectedContainerColor = ApnaBlueContainer,
              selectedLabelColor = ApnaBlueDark
            ),
            modifier = Modifier.testTag("sort_filter_chip")
          )

          DropdownMenu(
            expanded = showSortMenu,
            onDismissRequest = { showSortMenu = false }
          ) {
            SortOption.values().forEach { option ->
              DropdownMenuItem(
                text = {
                  Text(
                    text = ApnaStrings.get(option.displayNameKey, currentLanguage),
                    fontWeight = if (sortOption == option) FontWeight.Bold else FontWeight.Normal,
                    color = if (sortOption == option) ApnaBluePrimary else MaterialTheme.colorScheme.onSurface
                  )
                },
                onClick = {
                  viewModel.setSortOption(option)
                  showSortMenu = false
                }
              )
            }
          }
        }

        // Under 499 Chip
        FilterChip(
          selected = onlyUnder499,
          onClick = { viewModel.toggleUnder499Filter() },
          label = {
            Text(
              text = ApnaStrings.get("filter_under499", currentLanguage),
              fontSize = 11.sp
            )
          },
          colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = ApnaBlueContainer,
            selectedLabelColor = ApnaBlueDark
          ),
          modifier = Modifier.testTag("filter_under_499")
        )

        // In Stock Chip
        FilterChip(
          selected = onlyInStock,
          onClick = { viewModel.toggleInStockFilter() },
          label = {
            Text(
              text = ApnaStrings.get("filter_in_stock", currentLanguage),
              fontSize = 11.sp
            )
          },
          colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = ApnaBlueContainer,
            selectedLabelColor = ApnaBlueDark
          ),
          modifier = Modifier.testTag("filter_in_stock")
        )
      }
    }

    // 6. Section Header
    item(span = { GridItemSpan(2) }) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        val catLabel = if (selectedCategory == "all") {
          ApnaStrings.get("all_products", currentLanguage)
        } else {
          val matching = DemoDataProvider.categories.find { it.id == selectedCategory }
          if (matching != null) ApnaStrings.get(matching.nameKey, currentLanguage) else selectedCategory
        }

        Text(
          text = if (searchQuery.isNotBlank()) "Results for \"$searchQuery\"" else catLabel,
          fontSize = 15.sp,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onSurface
        )

        Text(
          text = "${filteredProducts.size} items",
          fontSize = 11.sp,
          color = Color.Gray
        )
      }
    }

    // 7. Empty State or 2-Column Product Grid
    if (filteredProducts.isEmpty()) {
      item(span = { GridItemSpan(2) }) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 40.dp),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          Text(text = "🔍", fontSize = 44.sp)
          Spacer(modifier = Modifier.height(10.dp))
          Text(
            text = "No matching products found",
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
          )
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = "Try searching for Jeans, Kurti, Saree, or clear filters",
            fontSize = 12.sp,
            color = Color.Gray
          )
          Spacer(modifier = Modifier.height(12.dp))
          Text(
            text = "Reset All Filters",
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = ApnaBluePrimary,
            modifier = Modifier
              .clickable {
                viewModel.setSearchQuery("")
                viewModel.selectCategory("all")
                if (onlyUnder499) viewModel.toggleUnder499Filter()
                if (onlyInStock) viewModel.toggleInStockFilter()
              }
              .padding(8.dp)
          )
        }
      }
    } else {
      items(
        items = filteredProducts,
        key = { it.id }
      ) { product ->
        val isWishlisted = wishlistIds.contains(product.id)
        ProductCard(
          product = product,
          isWishlisted = isWishlisted,
          currentLanguage = currentLanguage,
          onProductClick = onProductClick,
          onWishlistToggle = { viewModel.toggleWishlist(it) },
          onAddToCart = {
            val defaultSize = it.availableSizes.firstOrNull() ?: "Standard"
            val defaultColor = it.availableColors.firstOrNull() ?: "Standard"
            viewModel.addToCart(it, defaultSize, defaultColor, 1)
          }
        )
      }
    }
  }
}
}
