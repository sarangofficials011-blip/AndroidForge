package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.LocalOffer
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.ApnaStrings
import com.example.model.CartItem
import com.example.ui.theme.ApnaActionOrange
import com.example.ui.theme.ApnaBlueContainer
import com.example.ui.theme.ApnaBlueDark
import com.example.ui.theme.ApnaBluePrimary
import com.example.ui.theme.ApnaDiscountGreen
import com.example.ui.theme.ApnaDiscountGreenBg
import com.example.ui.viewmodel.ApnaCartViewModel
import com.example.ui.viewmodel.MainTab

@Composable
fun CartScreen(
  viewModel: ApnaCartViewModel,
  onProceedToCheckout: () -> Unit,
  onExploreProducts: () -> Unit,
  modifier: Modifier = Modifier
) {
  val cartItems by viewModel.cartItems.collectAsState()
  val selectedAddress by viewModel.selectedAddress.collectAsState()
  val appliedCoupon by viewModel.appliedCoupon.collectAsState()
  val currentLanguage by viewModel.currentLanguage.collectAsState()

  var couponInput by remember { mutableStateOf("") }

  // Calculation
  val subtotalMrp = cartItems.sumOf { it.itemTotalMrp }
  val productTotal = cartItems.sumOf { it.itemTotalPrice }
  val productDiscount = (subtotalMrp - productTotal).coerceAtLeast(0)

  val couponDiscount = when (appliedCoupon?.discountType) {
    "FLAT" -> appliedCoupon?.discountValue ?: 0
    "PERCENT" -> (((productTotal * (appliedCoupon?.discountValue ?: 0)) / 100)).coerceAtMost(400)
    else -> 0
  }

  val baseDelivery = if (productTotal >= 499 || appliedCoupon?.discountType == "FREESHIP") 0 else 50
  val totalPayable = (productTotal - couponDiscount + baseDelivery).coerceAtLeast(0)
  val totalSavings = productDiscount + couponDiscount + if (baseDelivery == 0 && productTotal > 0) 50 else 0

  if (cartItems.isEmpty()) {
    // Empty Cart State
    Box(
      modifier = modifier
        .fillMaxSize()
        .background(MaterialTheme.colorScheme.background)
        .padding(20.dp),
      contentAlignment = Alignment.Center
    ) {
      Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
        modifier = Modifier.fillMaxWidth()
      ) {
        Surface(
          shape = RoundedCornerShape(24.dp),
          color = ApnaBlueContainer,
          modifier = Modifier.size(96.dp)
        ) {
          Box(contentAlignment = Alignment.Center) {
            Text(text = "🛒", fontSize = 48.sp)
          }
        }
        Spacer(modifier = Modifier.height(18.dp))
        Text(
          text = ApnaStrings.get("empty_cart", currentLanguage),
          fontSize = 20.sp,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onSurface
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
          text = "Your ApnaCart basket is empty. Browse genuine fashion, festive kurtis, denim jeans, and electronics!",
          fontSize = 12.sp,
          color = Color.Gray,
          textAlign = TextAlign.Center,
          modifier = Modifier.padding(horizontal = 16.dp)
        )
        Spacer(modifier = Modifier.height(20.dp))

        // Quick Category Suggestions
        Row(
          modifier = Modifier.padding(vertical = 4.dp),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          listOf("jeans" to "👖 Jeans", "kurti" to "👗 Kurtis", "saree" to "🥻 Sarees").forEach { (catId, label) ->
            Surface(
              shape = RoundedCornerShape(16.dp),
              color = Color.White,
              border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFD6DFEC)),
              modifier = Modifier.clickable {
                viewModel.selectCategory(catId)
                viewModel.setTab(MainTab.HOME)
                onExploreProducts()
              }
            ) {
              Text(
                text = label,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                color = ApnaBluePrimary,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(20.dp))
        Button(
          onClick = {
            viewModel.setTab(MainTab.HOME)
            onExploreProducts()
          },
          colors = ButtonDefaults.buttonColors(containerColor = ApnaActionOrange),
          shape = RoundedCornerShape(8.dp),
          modifier = Modifier
            .fillMaxWidth(0.7f)
            .height(44.dp)
            .testTag("cart_explore_products_btn")
        ) {
          Text(text = "Start Shopping Now", fontSize = 13.sp, fontWeight = FontWeight.Bold)
        }
      }
    }
  } else {
    Box(
      modifier = modifier
        .fillMaxSize()
        .background(MaterialTheme.colorScheme.background)
    ) {
      LazyColumn(
        modifier = Modifier
          .fillMaxSize()
          .padding(bottom = 84.dp),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        // 1. Delivery Address Card
        item {
          Card(
            shape = RoundedCornerShape(8.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth()
          ) {
            Row(
              modifier = Modifier.fillMaxWidth().padding(12.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Icon(imageVector = Icons.Default.LocationOn, contentDescription = null, tint = ApnaBluePrimary, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                  Text(
                    text = "${ApnaStrings.get("deliver_to", currentLanguage)}: ${selectedAddress.fullName}, ${selectedAddress.pincode}",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                  )
                  Text(
                    text = "${selectedAddress.houseNoBuilding}, ${selectedAddress.city}",
                    fontSize = 11.sp,
                    color = Color.Gray,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                  )
                }
              }

              Text(
                text = "Change",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = ApnaBluePrimary,
                modifier = Modifier
                  .clickable {
                    val all = viewModel.addresses.value
                    val next = all.firstOrNull { it.id != selectedAddress.id } ?: selectedAddress
                    viewModel.selectAddress(next)
                  }
                  .padding(4.dp)
              )
            }
          }
        }

        // 2. Free Delivery Ribbon
        item {
          val remaining = (499 - productTotal).coerceAtLeast(0)
          Card(
            shape = RoundedCornerShape(8.dp),
            colors = CardDefaults.cardColors(
              containerColor = if (remaining == 0) ApnaDiscountGreenBg else ApnaBlueContainer
            ),
            modifier = Modifier.fillMaxWidth()
          ) {
            Row(
              modifier = Modifier.fillMaxWidth().padding(10.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(text = if (remaining == 0) "🎉" else "🚚", fontSize = 16.sp)
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = if (remaining == 0) {
                  "You have qualified for FREE Delivery!"
                } else {
                  "Add items worth ₹$remaining more for FREE Delivery"
                },
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = if (remaining == 0) ApnaDiscountGreen else ApnaBlueDark
              )
            }
          }
        }

        // 3. Cart Items
        items(cartItems, key = { it.cartItemId }) { item ->
          CartItemRow(
            cartItem = item,
            onQuantityChange = { newQty ->
              viewModel.updateCartQuantity(item.cartItemId, newQty)
            },
            onRemove = { viewModel.removeCartItem(item.cartItemId) },
            onMoveToWishlist = {
              viewModel.toggleWishlist(item.product)
              viewModel.removeCartItem(item.cartItemId)
            }
          )
        }

        // 4. Coupons & Offers
        item {
          Card(
            shape = RoundedCornerShape(8.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(12.dp)) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = Icons.Default.LocalOffer, contentDescription = null, tint = ApnaBluePrimary, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(text = ApnaStrings.get("offers_and_coupons", currentLanguage), fontSize = 13.sp, fontWeight = FontWeight.Bold)
              }

              Spacer(modifier = Modifier.height(8.dp))

              if (appliedCoupon != null) {
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(6.dp))
                    .background(ApnaDiscountGreenBg)
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.SpaceBetween
                ) {
                  Column {
                    Text(text = "Coupon '${appliedCoupon?.code}' Applied", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = ApnaDiscountGreen)
                    Text(text = "Saved ₹$couponDiscount on your order!", fontSize = 11.sp, color = Color(0xFF1B5E20))
                  }
                  IconButton(onClick = { viewModel.removeCoupon() }, modifier = Modifier.size(24.dp)) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "Remove", tint = Color.DarkGray, modifier = Modifier.size(16.dp))
                  }
                }
              } else {
                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                  OutlinedTextField(
                    value = couponInput,
                    onValueChange = { couponInput = it.uppercase() },
                    placeholder = { Text("Enter coupon (e.g. APNA150)") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = ApnaBluePrimary),
                    modifier = Modifier.weight(1f).height(46.dp).testTag("cart_coupon_input")
                  )
                  Spacer(modifier = Modifier.width(8.dp))
                  Button(
                    onClick = {
                      if (couponInput.isNotBlank()) {
                        viewModel.applyCoupon(couponInput)
                        couponInput = ""
                      }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ApnaBluePrimary),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.height(46.dp)
                  ) {
                    Text("Apply", fontWeight = FontWeight.Bold)
                  }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Suggestion chips
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                  listOf("APNA150", "FLIP20", "FREESHIP").forEach { code ->
                    Box(
                      modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(ApnaBlueContainer)
                        .clickable { viewModel.applyCoupon(code) }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                      Text(text = code, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = ApnaBlueDark)
                    }
                  }
                }
              }
            }
          }
        }

        // 5. Price Breakdown
        item {
          Card(
            shape = RoundedCornerShape(8.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(14.dp)) {
              Text(text = "Price Details (${cartItems.sumOf { it.quantity }} Items)", fontSize = 14.sp, fontWeight = FontWeight.Bold)
              Spacer(modifier = Modifier.height(10.dp))

              PriceRow(label = "Total MRP", value = "₹$subtotalMrp")
              PriceRow(label = "Discount on MRP", value = "- ₹$productDiscount", isDiscount = true)
              if (couponDiscount > 0) {
                PriceRow(label = "Coupon Discount (${appliedCoupon?.code})", value = "- ₹$couponDiscount", isDiscount = true)
              }
              PriceRow(label = "Delivery Fee", value = if (baseDelivery == 0) "FREE" else "₹$baseDelivery", isDiscount = baseDelivery == 0)

              Spacer(modifier = Modifier.height(8.dp))
              HorizontalDivider(color = Color(0xFFEEEEEE))
              Spacer(modifier = Modifier.height(8.dp))

              Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(text = ApnaStrings.get("total_amount", currentLanguage), fontSize = 15.sp, fontWeight = FontWeight.Bold)
                Text(text = "₹$totalPayable", fontSize = 17.sp, fontWeight = FontWeight.ExtraBold, color = ApnaBluePrimary)
              }

              if (totalSavings > 0) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                  text = "${ApnaStrings.get("total_savings", currentLanguage)} ₹$totalSavings on this order!",
                  fontSize = 12.sp,
                  fontWeight = FontWeight.Bold,
                  color = ApnaDiscountGreen
                )
              }
            }
          }
        }

        // Safe Checkout info
        item {
          Row(
            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(imageVector = Icons.Default.Security, contentDescription = null, tint = ApnaDiscountGreen, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(text = "100% Safe Demo Checkout • Free & Easy Returns", fontSize = 11.sp, color = Color.Gray)
          }
        }
      }

      // Sticky Bottom Bar
      Surface(
        color = Color.White,
        tonalElevation = 6.dp,
        shadowElevation = 8.dp,
        modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth()
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 16.dp, vertical = 10.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text(text = "₹$totalPayable", fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
            Text(text = "View price details", fontSize = 11.sp, color = ApnaBluePrimary)
          }

          Button(
            onClick = onProceedToCheckout,
            colors = ButtonDefaults.buttonColors(containerColor = ApnaActionOrange), // Flipkart Orange for Place Order
            shape = RoundedCornerShape(6.dp),
            modifier = Modifier.height(44.dp).testTag("proceed_to_buy_btn")
          ) {
            Text(text = ApnaStrings.get("proceed_to_buy", currentLanguage), fontSize = 13.sp, fontWeight = FontWeight.Bold)
          }
        }
      }
    }
  }
}

@Composable
private fun CartItemRow(
  cartItem: CartItem,
  onQuantityChange: (Int) -> Unit,
  onRemove: () -> Unit,
  onMoveToWishlist: () -> Unit
) {
  val product = cartItem.product

  Card(
    shape = RoundedCornerShape(8.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    modifier = Modifier.fillMaxWidth().testTag("cart_item_${cartItem.cartItemId}")
  ) {
    Column(modifier = Modifier.padding(10.dp)) {
      Row(modifier = Modifier.fillMaxWidth()) {
        Box(
          modifier = Modifier.size(76.dp).clip(RoundedCornerShape(6.dp)).background(Color(0xFFF7F9FC))
        ) {
          val bannerRes = product.drawableRes ?: R.drawable.apnacart_blue_icon_1793278921772
          Image(
            painter = painterResource(id = bannerRes),
            contentDescription = product.title,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
          )
        }

        Spacer(modifier = Modifier.width(10.dp))

        Column(modifier = Modifier.weight(1f)) {
          Text(text = product.brand, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = ApnaBluePrimary)
          Text(text = product.title, fontSize = 13.sp, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis)
          Spacer(modifier = Modifier.height(2.dp))
          Text(text = "Size: ${cartItem.selectedSize}  •  Color: ${cartItem.selectedColor}", fontSize = 11.sp, color = Color.Gray)
          Spacer(modifier = Modifier.height(4.dp))

          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(text = "₹${product.price}", fontSize = 14.sp, fontWeight = FontWeight.Bold)
            if (product.originalMrp > product.price) {
              Text(text = "₹${product.originalMrp}", fontSize = 11.sp, color = Color.Gray, textDecoration = TextDecoration.LineThrough)
              Text(text = "${product.discountPercent}% off", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = ApnaDiscountGreen)
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(8.dp))
      HorizontalDivider(color = Color(0xFFEEEEEE))
      Spacer(modifier = Modifier.height(6.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        // Quantity Stepper (Bounded by demo stock!)
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.border(1.dp, Color(0xFFE0E0E0), RoundedCornerShape(4.dp)).padding(horizontal = 4.dp, vertical = 2.dp)
        ) {
          IconButton(onClick = { onQuantityChange(cartItem.quantity - 1) }, modifier = Modifier.size(26.dp)) {
            Icon(
              imageVector = if (cartItem.quantity == 1) Icons.Default.Delete else Icons.Default.Remove,
              contentDescription = null,
              tint = if (cartItem.quantity == 1) Color.Red else Color.Black,
              modifier = Modifier.size(14.dp)
            )
          }

          Text(text = "${cartItem.quantity}", fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 8.dp))

          IconButton(
            onClick = { onQuantityChange(cartItem.quantity + 1) },
            enabled = cartItem.quantity < product.stockQuantity,
            modifier = Modifier.size(26.dp)
          ) {
            Icon(imageVector = Icons.Default.Add, contentDescription = null, tint = if (cartItem.quantity < product.stockQuantity) ApnaBluePrimary else Color.Gray, modifier = Modifier.size(14.dp))
          }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          Text(text = "Save for later", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = ApnaBluePrimary, modifier = Modifier.clickable { onMoveToWishlist() }.padding(4.dp))
          Text(text = "Remove", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = Color.Red, modifier = Modifier.clickable { onRemove() }.padding(4.dp))
        }
      }
    }
  }
}

@Composable
private fun PriceRow(label: String, value: String, isDiscount: Boolean = false) {
  Row(
    modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Text(text = label, fontSize = 12.sp, color = Color.Gray)
    Text(
      text = value,
      fontSize = 12.sp,
      fontWeight = FontWeight.SemiBold,
      color = if (isDiscount) ApnaDiscountGreen else Color.Black
    )
  }
}
