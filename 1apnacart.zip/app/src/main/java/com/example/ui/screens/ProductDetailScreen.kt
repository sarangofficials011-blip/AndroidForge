package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.ShoppingBag
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.NotificationsNone
import androidx.compose.material.icons.filled.QuestionAnswer
import androidx.compose.material.icons.filled.Straighten
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.*
import com.example.ui.theme.ApnaActionOrange
import com.example.ui.theme.ApnaBlueContainer
import com.example.ui.theme.ApnaBlueDark
import com.example.ui.theme.ApnaBluePrimary
import com.example.ui.theme.ApnaDiscountGreen
import com.example.ui.theme.ApnaDiscountGreenBg
import com.example.ui.theme.ApnaRatingStar
import com.example.ui.viewmodel.ApnaCartViewModel

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ProductDetailScreen(
  product: Product,
  viewModel: ApnaCartViewModel,
  onBack: () -> Unit,
  onGoToCart: () -> Unit,
  modifier: Modifier = Modifier
) {
  BackHandler { onBack() }

  LaunchedEffect(product.id) {
    viewModel.recordProductView(product.id)
  }

  val wishlistIds by viewModel.wishlistIds.collectAsState()
  val cartItems by viewModel.cartItems.collectAsState()
  val currentPincode by viewModel.deliveryPincode.collectAsState()
  val currentLanguage by viewModel.currentLanguage.collectAsState()
  val isWishlisted = wishlistIds.contains(product.id)

  var selectedSize by remember {
    mutableStateOf(product.availableSizes.firstOrNull() ?: "Standard")
  }
  var selectedColor by remember {
    mutableStateOf(product.availableColors.firstOrNull() ?: "Standard")
  }
  var selectedQuantity by remember { mutableIntStateOf(1) }
  var pincodeInput by remember { mutableStateOf(currentPincode) }
  var pincodeChecked by remember { mutableStateOf(true) }

  // Size Recommendation & Q&A Dialog States
  var showSizeGuideDialog by remember { mutableStateOf(false) }
  var chestInchInput by remember { mutableIntStateOf(38) }
  var waistInchInput by remember { mutableIntStateOf(32) }
  var showAskQuestionDialog by remember { mutableStateOf(false) }
  var questionInputText by remember { mutableStateOf("") }

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
  ) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .verticalScroll(rememberScrollState())
        .padding(bottom = 76.dp)
    ) {
      // 1. Top Custom App Bar
      Surface(
        color = ApnaBluePrimary,
        tonalElevation = 4.dp,
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(horizontal = 8.dp, vertical = 6.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(
              onClick = onBack,
              modifier = Modifier.testTag("detail_back_button")
            ) {
              Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = "Back",
                tint = Color.White
              )
            }
            Text(
              text = product.brand,
              fontSize = 16.sp,
              fontWeight = FontWeight.Bold,
              color = Color.White
            )
          }

          Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(
              onClick = { viewModel.toggleWishlist(product) },
              modifier = Modifier.testTag("detail_wishlist_button")
            ) {
              Icon(
                imageVector = if (isWishlisted) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                contentDescription = "Wishlist",
                tint = if (isWishlisted) Color(0xFFFF5252) else Color.White
              )
            }

            IconButton(
              onClick = onGoToCart,
              modifier = Modifier.testTag("detail_cart_button")
            ) {
              BadgedBox(
                badge = {
                  if (cartItems.isNotEmpty()) {
                    Badge(
                      containerColor = ApnaActionOrange,
                      contentColor = Color.White
                    ) {
                      Text("${cartItems.size}")
                    }
                  }
                }
              ) {
                Icon(
                  imageVector = Icons.Outlined.ShoppingBag,
                  contentDescription = "Cart",
                  tint = Color.White
                )
              }
            }
          }
        }
      }

      // 2. Large Image View
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(280.dp)
          .background(Color.White)
      ) {
        val bannerRes = product.drawableRes ?: R.drawable.apnacart_blue_icon_1793278921772
        Image(
          painter = painterResource(id = bannerRes),
          contentDescription = product.title,
          contentScale = ContentScale.Crop,
          modifier = Modifier.fillMaxSize()
        )

        // Demo Product Watermark
        Box(
          modifier = Modifier
            .padding(12.dp)
            .align(Alignment.TopEnd)
            .clip(RoundedCornerShape(4.dp))
            .background(Color.Black.copy(alpha = 0.6f))
            .padding(horizontal = 8.dp, vertical = 3.dp)
        ) {
          Text(
            text = "DEMO ITEM",
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
          )
        }
      }

      // 3. Title & Price Block
      Card(
        shape = RoundedCornerShape(0.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Text(
            text = product.brand,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = ApnaBluePrimary
          )

          Spacer(modifier = Modifier.height(4.dp))

          Text(
            text = product.title,
            fontSize = 16.sp,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurface,
            lineHeight = 22.sp
          )

          Spacer(modifier = Modifier.height(8.dp))

          // Rating Pill
          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
              .clip(RoundedCornerShape(4.dp))
              .background(ApnaDiscountGreen)
              .padding(horizontal = 8.dp, vertical = 3.dp)
          ) {
            Text(
              text = "%.1f".format(product.rating),
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold,
              color = Color.White
            )
            Spacer(modifier = Modifier.width(3.dp))
            Icon(
              imageVector = Icons.Filled.Star,
              contentDescription = null,
              tint = Color.White,
              modifier = Modifier.size(12.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = "(${product.reviewCount} Ratings)",
              fontSize = 11.sp,
              color = Color.White.copy(alpha = 0.9f)
            )
          }

          Spacer(modifier = Modifier.height(12.dp))

          // Price Row with Price Drop Alert
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
              Text(
                text = "₹${product.price}",
                fontSize = 24.sp,
                fontWeight = FontWeight.ExtraBold,
                color = MaterialTheme.colorScheme.onSurface
              )

              if (product.originalMrp > product.price) {
                Text(
                  text = "₹${product.originalMrp}",
                  fontSize = 14.sp,
                  color = Color.Gray,
                  textDecoration = TextDecoration.LineThrough
                )
              }

              if (product.discountPercent > 0) {
                Text(
                  text = "${product.discountPercent}% off",
                  fontSize = 14.sp,
                  fontWeight = FontWeight.Bold,
                  color = ApnaDiscountGreen
                )
              }
            }

            // Price Drop Alert Bell Toggle
            val priceAlerts by viewModel.priceAlerts.collectAsState()
            val alertActive = priceAlerts[product.id]?.isEnabled == true
            IconButton(
              onClick = { viewModel.togglePriceAlert(product.id, product.price) },
              modifier = Modifier.testTag("product_price_alert_button")
            ) {
              Icon(
                imageVector = if (alertActive) Icons.Default.NotificationsActive else Icons.Default.NotificationsNone,
                contentDescription = "Price Drop Alert",
                tint = if (alertActive) ApnaActionOrange else Color.Gray,
                modifier = Modifier.size(24.dp)
              )
            }
          }

          // Stock quantity banner
          Spacer(modifier = Modifier.height(6.dp))
          if (product.inStock) {
            Text(
              text = "⚡ In Stock: Only ${product.stockQuantity} ${ApnaStrings.get("stock_left", currentLanguage)}",
              fontSize = 12.sp,
              fontWeight = FontWeight.SemiBold,
              color = if (product.stockQuantity <= 5) Color(0xFFD32F2F) else ApnaDiscountGreen
            )
          } else {
            Text(
              text = "⚠️ Out of Demo Stock",
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold,
              color = Color.Red
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      // 4. Quantity Selector (Bounded by stockQuantity)
      if (product.inStock) {
        Card(
          shape = RoundedCornerShape(0.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text(text = "Quantity:", fontSize = 14.sp, fontWeight = FontWeight.Bold)

            Row(verticalAlignment = Alignment.CenterVertically) {
              IconButton(
                onClick = { if (selectedQuantity > 1) selectedQuantity-- },
                enabled = selectedQuantity > 1,
                modifier = Modifier.size(32.dp).border(1.dp, Color.LightGray, RoundedCornerShape(4.dp))
              ) {
                Icon(imageVector = Icons.Default.Remove, contentDescription = "Decrease", modifier = Modifier.size(16.dp))
              }

              Text(
                text = "$selectedQuantity",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 16.dp)
              )

              IconButton(
                onClick = { if (selectedQuantity < product.stockQuantity) selectedQuantity++ },
                enabled = selectedQuantity < product.stockQuantity,
                modifier = Modifier.size(32.dp).border(1.dp, Color.LightGray, RoundedCornerShape(4.dp))
              ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = "Increase", modifier = Modifier.size(16.dp))
              }
            }
          }

          if (product.stockQuantity in 1..5) {
            Spacer(modifier = Modifier.height(10.dp))
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(6.dp))
                .background(Color(0xFFFFF3E0))
                .padding(horizontal = 8.dp, vertical = 6.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = "⚡ Low Stock Alert: Only ${product.stockQuantity} units left in stock!",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFFE65100)
              )
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      // 5. Size Selection
      if (product.availableSizes.isNotEmpty()) {
        Card(
          shape = RoundedCornerShape(0.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = "${ApnaStrings.get("select_size", currentLanguage)}:",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
              )
              TextButton(
                onClick = { showSizeGuideDialog = true },
                contentPadding = PaddingValues(horizontal = 4.dp, vertical = 2.dp)
              ) {
                Icon(
                  imageVector = Icons.Default.Straighten,
                  contentDescription = null,
                  tint = ApnaBluePrimary,
                  modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                  text = "Size Guide & Fit",
                  fontSize = 12.sp,
                  fontWeight = FontWeight.Bold,
                  color = ApnaBluePrimary
                )
              }
            }

            if (showSizeGuideDialog) {
              val recommendation = viewModel.calculateSizeRecommendation(product, chestInchInput, waistInchInput)
              AlertDialog(
                onDismissRequest = { showSizeGuideDialog = false },
                title = {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Straighten, contentDescription = null, tint = ApnaBluePrimary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Size & Fit Recommendation", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                  }
                },
                text = {
                  Column {
                    Text("Select your body measurements:", fontSize = 12.sp, color = Color.Gray)
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                      modifier = Modifier.fillMaxWidth(),
                      horizontalArrangement = Arrangement.SpaceBetween,
                      verticalAlignment = Alignment.CenterVertically
                    ) {
                      Text("Chest: $chestInchInput inches", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                      Row {
                        IconButton(onClick = { if (chestInchInput > 32) chestInchInput -= 2 }, modifier = Modifier.size(32.dp)) {
                          Text("-", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        }
                        IconButton(onClick = { if (chestInchInput < 48) chestInchInput += 2 }, modifier = Modifier.size(32.dp)) {
                          Text("+", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        }
                      }
                    }
                    Row(
                      modifier = Modifier.fillMaxWidth(),
                      horizontalArrangement = Arrangement.SpaceBetween,
                      verticalAlignment = Alignment.CenterVertically
                    ) {
                      Text("Waist: $waistInchInput inches", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                      Row {
                        IconButton(onClick = { if (waistInchInput > 26) waistInchInput -= 2 }, modifier = Modifier.size(32.dp)) {
                          Text("-", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        }
                        IconButton(onClick = { if (waistInchInput < 46) waistInchInput += 2 }, modifier = Modifier.size(32.dp)) {
                          Text("+", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        }
                      }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Box(
                      modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFFE8F5E9))
                        .padding(10.dp)
                    ) {
                      Column {
                        Text(
                          text = "Recommended: Size ${recommendation.recommendedSize}",
                          fontSize = 13.sp,
                          fontWeight = FontWeight.Bold,
                          color = ApnaDiscountGreen
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                          text = recommendation.explanation,
                          fontSize = 11.sp,
                          color = Color(0xFF2E7D32)
                        )
                      }
                    }
                  }
                },
                confirmButton = {
                  Button(
                    onClick = {
                      val rec = viewModel.calculateSizeRecommendation(product, chestInchInput, waistInchInput)
                      selectedSize = rec.recommendedSize
                      showSizeGuideDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ApnaBluePrimary)
                  ) {
                    Text("Apply Recommended Size")
                  }
                },
                dismissButton = {
                  TextButton(onClick = { showSizeGuideDialog = false }) {
                    Text("Close")
                  }
                }
              )
            }

            Spacer(modifier = Modifier.height(10.dp))

            FlowRow(
              horizontalArrangement = Arrangement.spacedBy(8.dp),
              verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              product.availableSizes.forEach { size ->
                val isSelected = selectedSize == size
                Box(
                  modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(if (isSelected) ApnaBluePrimary else Color.White)
                    .border(1.dp, if (isSelected) ApnaBlueDark else Color.LightGray, RoundedCornerShape(6.dp))
                    .clickable { selectedSize = size }
                    .padding(horizontal = 14.dp, vertical = 8.dp)
                    .testTag("size_option_$size")
                ) {
                  Text(
                    text = size,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isSelected) Color.White else Color.Black
                  )
                }
              }
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      // 6. Color Selection
      if (product.availableColors.isNotEmpty()) {
        Card(
          shape = RoundedCornerShape(0.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Text(
              text = "${ApnaStrings.get("select_color", currentLanguage)}:",
              fontSize = 14.sp,
              fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(10.dp))

            FlowRow(
              horizontalArrangement = Arrangement.spacedBy(8.dp),
              verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              product.availableColors.forEach { colorName ->
                val isSelected = selectedColor == colorName
                Box(
                  modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(if (isSelected) ApnaBlueContainer else Color.White)
                    .border(1.dp, if (isSelected) ApnaBluePrimary else Color.LightGray, RoundedCornerShape(6.dp))
                    .clickable { selectedColor = colorName }
                    .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    if (isSelected) {
                      Icon(imageVector = Icons.Default.Check, contentDescription = null, tint = ApnaBluePrimary, modifier = Modifier.size(14.dp))
                      Spacer(modifier = Modifier.width(4.dp))
                    }
                    Text(
                      text = colorName,
                      fontSize = 12.sp,
                      fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                      color = if (isSelected) ApnaBlueDark else Color.Black
                    )
                  }
                }
              }
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      // 7. Pincode Delivery Checker
      Card(
        shape = RoundedCornerShape(0.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Text(text = ApnaStrings.get("check_pincode", currentLanguage), fontSize = 14.sp, fontWeight = FontWeight.Bold)
          Spacer(modifier = Modifier.height(8.dp))

          Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
              value = pincodeInput,
              onValueChange = { if (it.length <= 6 && it.all { c -> c.isDigit() }) pincodeInput = it },
              placeholder = { Text("6-digit PIN") },
              singleLine = true,
              modifier = Modifier.weight(1f).height(48.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Button(
              onClick = {
                if (pincodeInput.length == 6) {
                  viewModel.updateDeliveryPincode(pincodeInput)
                  pincodeChecked = true
                }
              },
              colors = ButtonDefaults.buttonColors(containerColor = ApnaBluePrimary),
              shape = RoundedCornerShape(6.dp),
              modifier = Modifier.height(48.dp)
            ) {
              Text("Check")
            }
          }

          if (pincodeChecked && pincodeInput.length == 6) {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
              text = "✓ Delivery available to $pincodeInput (${product.deliveryEstimate})",
              fontSize = 12.sp,
              color = ApnaDiscountGreen,
              fontWeight = FontWeight.SemiBold
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      // 8. Highlights & Description
      Card(
        shape = RoundedCornerShape(0.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Text(text = ApnaStrings.get("product_highlights", currentLanguage), fontSize = 14.sp, fontWeight = FontWeight.Bold)
          Spacer(modifier = Modifier.height(8.dp))

          product.highlights.forEach { highlight ->
            Row(modifier = Modifier.padding(vertical = 2.dp)) {
              Text(text = "•", color = ApnaBluePrimary, fontWeight = FontWeight.Bold, modifier = Modifier.padding(end = 8.dp))
              Text(text = highlight, fontSize = 13.sp)
            }
          }

          Spacer(modifier = Modifier.height(12.dp))
          HorizontalDivider(color = Color(0xFFEEEEEE))
          Spacer(modifier = Modifier.height(12.dp))

          Text(text = "Description", fontSize = 14.sp, fontWeight = FontWeight.Bold)
          Spacer(modifier = Modifier.height(4.dp))
          Text(text = product.description, fontSize = 12.sp, color = Color.Gray, lineHeight = 18.sp)
        }
      }

      // 9. Product Q&A Section
      val allQuestions by viewModel.productQuestions.collectAsState()
      val productQAs: List<ProductQuestion> = remember(allQuestions, product.id) {
        allQuestions.filter { it.productId == product.id && it.isApproved }
      }

      Spacer(modifier = Modifier.height(8.dp))
      Card(
        shape = RoundedCornerShape(0.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = Icons.Default.QuestionAnswer,
                contentDescription = null,
                tint = ApnaBluePrimary,
                modifier = Modifier.size(18.dp)
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(text = "Questions & Answers (${productQAs.size})", fontSize = 14.sp, fontWeight = FontWeight.Bold)
            }
            TextButton(
              onClick = { showAskQuestionDialog = true },
              contentPadding = PaddingValues(horizontal = 4.dp, vertical = 2.dp)
            ) {
              Text("+ Ask a Question", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = ApnaBluePrimary)
            }
          }

          if (productQAs.isEmpty()) {
            Spacer(modifier = Modifier.height(6.dp))
            Text(text = "No questions yet. Have a doubt? Ask the seller and community!", fontSize = 12.sp, color = Color.Gray)
          } else {
            Spacer(modifier = Modifier.height(8.dp))
            productQAs.forEach { qa ->
              Column(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(vertical = 6.dp)
              ) {
                Row(verticalAlignment = Alignment.Top) {
                  Text(text = "Q: ", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = ApnaBluePrimary)
                  Text(text = qa.questionText, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                }
                if (!qa.answerText.isNullOrBlank()) {
                  Spacer(modifier = Modifier.height(3.dp))
                  Row(verticalAlignment = Alignment.Top) {
                    Text(text = "A: ", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = ApnaDiscountGreen)
                    Column {
                      Text(text = qa.answerText, fontSize = 12.sp, color = Color(0xFF374151))
                      Text(
                        text = "— ${qa.answeredBy ?: "ApnaCart Verified Seller"} (${qa.answeredDate ?: "Recent"})",
                        fontSize = 10.sp,
                        color = Color.Gray
                      )
                    }
                  }
                }
                Spacer(modifier = Modifier.height(6.dp))
                HorizontalDivider(color = Color(0xFFF1F5F9))
              }
            }
          }
        }
      }

      if (showAskQuestionDialog) {
        AlertDialog(
          onDismissRequest = { showAskQuestionDialog = false },
          title = { Text("Ask a Question", fontSize = 16.sp, fontWeight = FontWeight.Bold) },
          text = {
            Column {
              Text("Ask anything about size, fabric, color, or care instructions:", fontSize = 12.sp, color = Color.Gray)
              Spacer(modifier = Modifier.height(8.dp))
              OutlinedTextField(
                value = questionInputText,
                onValueChange = { questionInputText = it },
                placeholder = { Text("Type your question...", fontSize = 12.sp) },
                modifier = Modifier.fillMaxWidth()
              )
            }
          },
          confirmButton = {
            Button(
              onClick = {
                if (questionInputText.isNotBlank()) {
                  viewModel.askProductQuestion(product.id, questionInputText.trim())
                  questionInputText = ""
                }
                showAskQuestionDialog = false
              },
              colors = ButtonDefaults.buttonColors(containerColor = ApnaBluePrimary)
            ) {
              Text("Submit")
            }
          },
          dismissButton = {
            TextButton(onClick = { showAskQuestionDialog = false }) {
              Text("Cancel")
            }
          }
        )
      }

      // Similar Category Recommendations
      val similarProducts = remember(product.id) { viewModel.getSimilarProducts(product) }
      if (similarProducts.isNotEmpty()) {
        Spacer(modifier = Modifier.height(8.dp))
        Card(
          shape = RoundedCornerShape(0.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Text(
              text = "Similar Products in this Category",
              fontSize = 14.sp,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(10.dp))
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
              horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
              similarProducts.forEach { simProd ->
                Card(
                  shape = RoundedCornerShape(8.dp),
                  colors = CardDefaults.cardColors(containerColor = Color.White),
                  elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                  modifier = Modifier
                    .width(140.dp)
                    .clickable { viewModel.navigateTo(com.example.ui.viewmodel.ScreenDestination.ProductDetail(simProd)) }
                ) {
                  Column(modifier = Modifier.padding(8.dp)) {
                    Box(
                      modifier = Modifier
                        .fillMaxWidth()
                        .height(110.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color(0xFFF1F5F9)),
                      contentAlignment = Alignment.Center
                    ) {
                      if (simProd.drawableRes != null) {
                        Image(
                          painter = painterResource(id = simProd.drawableRes),
                          contentDescription = simProd.title,
                          contentScale = ContentScale.Crop,
                          modifier = Modifier.fillMaxSize()
                        )
                      }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(text = simProd.title, fontSize = 11.sp, maxLines = 1, fontWeight = FontWeight.SemiBold)
                    Text(text = "₹${simProd.price}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = ApnaBlueDark)
                  }
                }
              }
            }
          }
        }
      }
    }

    // 9. Sticky Bottom Action Bar (Flipkart Style: Yellow/White Cart + Orange Buy Now)
    Surface(
      color = Color.White,
      tonalElevation = 6.dp,
      shadowElevation = 8.dp,
      modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth()
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .navigationBarsPadding()
          .height(56.dp)
      ) {
        // Add to Cart
        Box(
          modifier = Modifier
            .weight(1f)
            .fillMaxSize()
            .background(Color.White)
            .clickable(enabled = product.inStock) {
              viewModel.addToCart(product, selectedSize, selectedColor, selectedQuantity)
            }
            .testTag("detail_add_to_cart_btn"),
          contentAlignment = Alignment.Center
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(imageVector = Icons.Default.ShoppingBag, contentDescription = null, tint = ApnaBluePrimary, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = ApnaStrings.get("add_to_cart", currentLanguage),
              fontSize = 14.sp,
              fontWeight = FontWeight.Bold,
              color = ApnaBluePrimary
            )
          }
        }

        // Buy Now (Flipkart Signature Orange)
        Box(
          modifier = Modifier
            .weight(1f)
            .fillMaxSize()
            .background(if (product.inStock) ApnaActionOrange else Color.LightGray)
            .clickable(enabled = product.inStock) {
              viewModel.addToCart(product, selectedSize, selectedColor, selectedQuantity)
              viewModel.navigateTo(com.example.ui.viewmodel.ScreenDestination.Checkout)
            }
            .testTag("detail_buy_now_btn"),
          contentAlignment = Alignment.Center
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(imageVector = Icons.Default.FlashOn, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = ApnaStrings.get("buy_now", currentLanguage),
              fontSize = 14.sp,
              fontWeight = FontWeight.Bold,
              color = Color.White
            )
          }
        }
      }
    }
  }
}
