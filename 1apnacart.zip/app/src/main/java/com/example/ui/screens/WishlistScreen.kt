package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.ApnaStrings
import com.example.model.Product
import com.example.ui.theme.ApnaBluePrimary
import com.example.ui.theme.ApnaDiscountGreen
import com.example.ui.viewmodel.ApnaCartViewModel
import com.example.ui.viewmodel.MainTab

@Composable
fun WishlistScreen(
  viewModel: ApnaCartViewModel,
  onProductClick: (Product) -> Unit,
  modifier: Modifier = Modifier
) {
  val wishlistProducts by viewModel.wishlistProducts.collectAsState()
  val currentLanguage by viewModel.currentLanguage.collectAsState()

  if (wishlistProducts.isEmpty()) {
    Box(
      modifier = modifier
        .fillMaxSize()
        .background(MaterialTheme.colorScheme.background)
        .padding(24.dp),
      contentAlignment = Alignment.Center
    ) {
      Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
      ) {
        Text(text = "❤️", fontSize = 56.sp)
        Spacer(modifier = Modifier.height(14.dp))
        Text(
          text = ApnaStrings.get("empty_wishlist", currentLanguage),
          fontSize = 18.sp,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onSurface
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
          text = "Tap the heart icon on any product to save it here!",
          fontSize = 12.sp,
          color = Color.Gray
        )
        Spacer(modifier = Modifier.height(20.dp))
        Button(
          onClick = { viewModel.setTab(MainTab.HOME) },
          colors = ButtonDefaults.buttonColors(containerColor = ApnaBluePrimary),
          shape = RoundedCornerShape(8.dp),
          modifier = Modifier.height(44.dp).testTag("wishlist_explore_btn")
        ) {
          Text("Explore Products", fontWeight = FontWeight.Bold)
        }
      }
    }
  } else {
    LazyColumn(
      modifier = modifier
        .fillMaxSize()
        .background(MaterialTheme.colorScheme.background),
      contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 14.dp, bottom = 96.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "${ApnaStrings.get("my_wishlist", currentLanguage)} (${wishlistProducts.size})",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
          )
        }
      }

      items(wishlistProducts, key = { it.id }) { product ->
        Card(
          shape = RoundedCornerShape(10.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
          modifier = Modifier
            .fillMaxWidth()
            .clickable { onProductClick(product) }
            .testTag("wishlist_card_${product.id}")
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Box(
              modifier = Modifier
                .size(76.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(Color(0xFFF7F9FC))
            ) {
              val bannerRes = product.drawableRes ?: R.drawable.apnacart_blue_icon_1793278921772
              Image(
                painter = painterResource(id = bannerRes),
                contentDescription = product.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
              )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = product.brand,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = ApnaBluePrimary
              )
              Text(
                text = product.title,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
              )

              Spacer(modifier = Modifier.height(3.dp))

              Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
              ) {
                Text(
                  text = "₹${product.price}",
                  fontSize = 14.sp,
                  fontWeight = FontWeight.Bold
                )
                if (product.originalMrp > product.price) {
                  Text(
                    text = "₹${product.originalMrp}",
                    fontSize = 11.sp,
                    color = Color.Gray,
                    textDecoration = TextDecoration.LineThrough
                  )
                  Text(
                    text = "${product.discountPercent}% off",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = ApnaDiscountGreen
                  )
                }
              }

              Spacer(modifier = Modifier.height(6.dp))

              Button(
                onClick = {
                  val defaultSize = product.availableSizes.firstOrNull() ?: "Standard"
                  val defaultColor = product.availableColors.firstOrNull() ?: "Standard"
                  viewModel.addToCart(product, defaultSize, defaultColor, 1)
                  viewModel.toggleWishlist(product)
                },
                colors = ButtonDefaults.buttonColors(containerColor = ApnaBluePrimary),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.height(32.dp).testTag("wishlist_move_cart_${product.id}")
              ) {
                Icon(
                  imageVector = Icons.Default.ShoppingBag,
                  contentDescription = null,
                  modifier = Modifier.size(13.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text("Move to Cart", fontSize = 11.sp, fontWeight = FontWeight.Bold)
              }
            }

            IconButton(
              onClick = { viewModel.toggleWishlist(product) },
              modifier = Modifier.size(34.dp)
            ) {
              Icon(
                imageVector = Icons.Default.Delete,
                contentDescription = "Remove",
                tint = Color.Gray,
                modifier = Modifier.size(18.dp)
              )
            }
          }
        }
      }
    }
  }
}
