package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
  primary = ApnaBlueDarkPrimary,
  onPrimary = Color.Black,
  primaryContainer = ApnaBlueDarkContainerBg,
  onPrimaryContainer = ApnaBlueLight,
  secondary = ApnaActionOrange,
  onSecondary = Color.White,
  secondaryContainer = ApnaSurfaceVariantDark,
  onSecondaryContainer = ApnaBlueDarkPrimary,
  tertiary = ApnaYellowRating,
  background = ApnaBackgroundDark,
  onBackground = TextPrimaryDark,
  surface = ApnaSurfaceDark,
  onSurface = TextPrimaryDark,
  surfaceVariant = ApnaSurfaceVariantDark,
  onSurfaceVariant = TextSecondaryDark,
  outline = ApnaOutline
)

private val LightColorScheme = lightColorScheme(
  primary = ApnaBluePrimary,
  onPrimary = Color.White,
  primaryContainer = ApnaBlueContainer,
  onPrimaryContainer = ApnaOnBlueContainer,
  secondary = ApnaActionOrange,
  onSecondary = Color.White,
  secondaryContainer = Color(0xFFFFF3E0),
  onSecondaryContainer = Color(0xFFE65100),
  tertiary = ApnaYellowRating,
  onTertiary = Color.White,
  tertiaryContainer = Color(0xFFFFF8E1),
  background = ApnaBackground,
  onBackground = TextPrimary,
  surface = ApnaSurface,
  onSurface = TextPrimary,
  surfaceVariant = ApnaSurfaceVariant,
  onSurfaceVariant = TextSecondary,
  outline = ApnaOutline
)

@Composable
fun ApnaCartTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit
) {
  val colorScheme = when {
    dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
      val context = LocalContext.current
      if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
    }
    darkTheme -> DarkColorScheme
    else -> LightColorScheme
  }

  MaterialTheme(
    colorScheme = colorScheme,
    typography = Typography,
    content = content
  )
}
