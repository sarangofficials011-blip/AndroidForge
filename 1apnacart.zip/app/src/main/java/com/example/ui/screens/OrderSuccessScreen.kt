package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Order
import com.example.ui.theme.ApnaBlueDark
import com.example.ui.theme.ApnaBluePrimary
import com.example.ui.theme.ApnaDiscountGreen
import com.example.ui.theme.ApnaDiscountGreenBg

@Composable
fun OrderSuccessScreen(
  order: Order,
  onTrackOrder: (String) -> Unit,
  onContinueShopping: () -> Unit,
  modifier: Modifier = Modifier
) {
  BackHandler { onContinueShopping() }

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
      .padding(20.dp),
    contentAlignment = Alignment.Center
  ) {
    Column(
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.Center,
      modifier = Modifier.fillMaxWidth()
    ) {
      Box(
        modifier = Modifier
          .size(72.dp)
          .clip(CircleShape)
          .background(ApnaDiscountGreenBg),
        contentAlignment = Alignment.Center
      ) {
        Icon(
          imageVector = Icons.Default.Check,
          contentDescription = "Success",
          tint = ApnaDiscountGreen,
          modifier = Modifier.size(42.dp)
        )
      }

      Spacer(modifier = Modifier.height(16.dp))

      Text(
        text = "Demo Order Confirmed!",
        fontSize = 20.sp,
        fontWeight = FontWeight.ExtraBold,
        color = MaterialTheme.colorScheme.onSurface,
        textAlign = TextAlign.Center
      )

      Spacer(modifier = Modifier.height(4.dp))

      Text(
        text = "Order #${order.orderId} recorded locally on your device in demo mode.",
        fontSize = 12.sp,
        color = Color.Gray,
        textAlign = TextAlign.Center
      )

      Spacer(modifier = Modifier.height(16.dp))

      // Demo safety card
      Card(
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF8E1)),
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
          Icon(imageVector = Icons.Default.Info, contentDescription = null, tint = Color(0xFFE65100), modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "No actual payment was processed. Tracking simulation is local and does not contact any courier partner.",
            fontSize = 11.sp,
            color = Color(0xFF5D4037)
          )
        }
      }

      Spacer(modifier = Modifier.height(16.dp))

      Card(
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(text = "Total Paid (Demo)", fontSize = 12.sp, color = Color.Gray)
            Text(text = "₹${order.finalAmount}", fontSize = 14.sp, fontWeight = FontWeight.Bold)
          }
          Spacer(modifier = Modifier.height(6.dp))
          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(text = "Estimated Delivery", fontSize = 12.sp, color = Color.Gray)
            Text(text = order.estimatedDeliveryDate, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = ApnaDiscountGreen)
          }
          Spacer(modifier = Modifier.height(6.dp))
          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(text = "Deliver To", fontSize = 12.sp, color = Color.Gray)
            Text(text = "${order.deliveryAddress.fullName}, ${order.deliveryAddress.city}", fontSize = 12.sp)
          }
        }
      }

      Spacer(modifier = Modifier.height(20.dp))

      Button(
        onClick = { onTrackOrder(order.orderId) },
        colors = ButtonDefaults.buttonColors(containerColor = ApnaBluePrimary),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.fillMaxWidth().height(46.dp).testTag("track_shipment_btn")
      ) {
        Icon(imageVector = Icons.Default.LocalShipping, contentDescription = null, modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(8.dp))
        Text(text = "Track Demo Shipment", fontSize = 13.sp, fontWeight = FontWeight.Bold)
      }

      Spacer(modifier = Modifier.height(10.dp))

      OutlinedButton(
        onClick = onContinueShopping,
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.fillMaxWidth().height(46.dp).testTag("continue_shopping_btn")
      ) {
        Text(text = "Continue Shopping", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = ApnaBlueDark)
      }
    }
  }
}
