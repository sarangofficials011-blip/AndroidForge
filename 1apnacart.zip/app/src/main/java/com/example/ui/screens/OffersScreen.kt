package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocalOffer
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ApnaStrings
import com.example.ui.theme.ApnaActionOrange
import com.example.ui.theme.ApnaBlueContainer
import com.example.ui.theme.ApnaBlueDark
import com.example.ui.theme.ApnaBluePrimary
import com.example.ui.theme.ApnaDiscountGreen
import com.example.ui.viewmodel.ApnaCartViewModel
import com.example.ui.viewmodel.MainTab

@Composable
fun OffersScreen(
  viewModel: ApnaCartViewModel,
  modifier: Modifier = Modifier
) {
  val availableCoupons by viewModel.availableCoupons.collectAsState()
  val appliedCoupon by viewModel.appliedCoupon.collectAsState()
  val currentLanguage by viewModel.currentLanguage.collectAsState()

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background),
    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 96.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    // Header & Disclaimer
    item {
      Column(modifier = Modifier.fillMaxWidth()) {
        Text(
          text = ApnaStrings.get("offers_and_coupons", currentLanguage),
          fontSize = 20.sp,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onSurface
        )

        Spacer(modifier = Modifier.height(4.dp))

        Row(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .background(Color(0xFFFFF8E1))
            .border(0.5.dp, Color(0xFFFFB300), RoundedCornerShape(6.dp))
            .padding(10.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(
            imageVector = Icons.Default.Info,
            contentDescription = null,
            tint = Color(0xFFE65100),
            modifier = Modifier.size(16.dp)
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "Demo Offers: These coupons are fictional promotional codes for testing cart discount calculations. No real discounts are redeemable.",
            fontSize = 11.sp,
            color = Color(0xFF5D4037),
            lineHeight = 15.sp
          )
        }
      }
    }

    // Active Coupon Banner if applied
    if (appliedCoupon != null) {
      item {
        Card(
          shape = RoundedCornerShape(10.dp),
          colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F5E9)),
          border = CardDefaults.outlinedCardBorder().copy(width = 1.dp, brush = androidx.compose.ui.graphics.SolidColor(ApnaDiscountGreen)),
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Column {
              Text(
                text = "✓ Currently Applied: ${appliedCoupon?.code}",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = ApnaDiscountGreen
              )
              Text(
                text = appliedCoupon?.description ?: "",
                fontSize = 11.sp,
                color = Color(0xFF1B5E20)
              )
            }

            Text(
              text = "Remove",
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold,
              color = Color.Red,
              modifier = Modifier
                .clickable { viewModel.removeCoupon() }
                .padding(4.dp)
            )
          }
        }
      }
    }

    // List of Demo Coupons
    items(availableCoupons, key = { it.code }) { coupon ->
      val isThisApplied = appliedCoupon?.code.equals(coupon.code, ignoreCase = true)

      Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
          .fillMaxWidth()
          .testTag("coupon_card_${coupon.code}")
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            // Coupon Code Pill
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(6.dp))
                .background(ApnaBlueContainer)
                .border(1.dp, ApnaBluePrimary.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                .padding(horizontal = 10.dp, vertical = 5.dp)
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                  imageVector = Icons.Default.LocalOffer,
                  contentDescription = null,
                  tint = ApnaBluePrimary,
                  modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = coupon.code,
                  fontSize = 13.sp,
                  fontWeight = FontWeight.ExtraBold,
                  color = ApnaBlueDark
                )
              }
            }

            if (isThisApplied) {
              Text(
                text = "Applied ✓",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = ApnaDiscountGreen
              )
            } else {
              Button(
                onClick = {
                  viewModel.applyCoupon(coupon.code)
                  viewModel.setTab(MainTab.CART)
                },
                colors = ButtonDefaults.buttonColors(containerColor = ApnaBluePrimary),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.height(32.dp)
              ) {
                Text("Apply & View Cart", fontSize = 11.sp, fontWeight = FontWeight.Bold)
              }
            }
          }

          Spacer(modifier = Modifier.height(8.dp))

          Text(
            text = coupon.title,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
          )

          Spacer(modifier = Modifier.height(2.dp))

          Text(
            text = coupon.description,
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )

          Spacer(modifier = Modifier.height(8.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text(
              text = if (coupon.minCartValue > 0) "Min. cart value: ₹${coupon.minCartValue}" else "No min. cart value",
              fontSize = 11.sp,
              color = Color.Gray
            )

            Text(
              text = "Valid till ${coupon.expiryDate}",
              fontSize = 11.sp,
              color = Color.Gray
            )
          }
        }
      }
    }
  }
}
