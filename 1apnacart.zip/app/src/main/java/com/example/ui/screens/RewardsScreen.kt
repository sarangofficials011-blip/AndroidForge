package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Stars
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.ui.theme.ApnaBluePrimary
import com.example.ui.theme.ApnaDiscountGreen
import com.example.ui.viewmodel.ApnaCartViewModel

@Composable
fun RewardsScreen(
  viewModel: ApnaCartViewModel,
  onBack: () -> Unit,
  modifier: Modifier = Modifier
) {
  BackHandler { onBack() }

  val points by viewModel.rewardPoints.collectAsState()
  val transactions by viewModel.rewardTransactions.collectAsState()

  Surface(
    color = MaterialTheme.colorScheme.background,
    modifier = modifier.fillMaxSize()
  ) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .statusBarsPadding()
    ) {
      // Header
      Surface(
        color = ApnaBluePrimary,
        tonalElevation = 4.dp,
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 12.dp)
        ) {
          IconButton(onClick = onBack) {
            Icon(
              imageVector = Icons.AutoMirrored.Filled.ArrowBack,
              contentDescription = "Back",
              tint = Color.White
            )
          }
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = "ApnaCart SuperCoins & Rewards",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
          )
        }
      }

      LazyColumn(
        modifier = Modifier
          .fillMaxSize()
          .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
      ) {
        // Rewards Balance Card
        item {
          Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1565C0)),
            elevation = CardDefaults.cardElevation(6.dp),
            modifier = Modifier
              .fillMaxWidth()
              .testTag("rewards_balance_card")
          ) {
            Column(modifier = Modifier.padding(20.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text(
                  text = "Available Reward Coins",
                  fontSize = 13.sp,
                  color = Color.White.copy(alpha = 0.85f)
                )
                Icon(
                  imageVector = Icons.Default.Stars,
                  contentDescription = null,
                  tint = Color(0xFFFFD200),
                  modifier = Modifier.size(28.dp)
                )
              }
              Spacer(modifier = Modifier.height(8.dp))
              Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                  text = "$points",
                  fontSize = 36.sp,
                  fontWeight = FontWeight.ExtraBold,
                  color = Color(0xFFFFD200)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                  text = "Coins",
                  fontSize = 18.sp,
                  fontWeight = FontWeight.Bold,
                  color = Color.White
                )
              }
              Spacer(modifier = Modifier.height(6.dp))
              Text(
                text = "1 Coin = ₹1 instant checkout savings • Earn 1 Coin per ₹100 spent",
                fontSize = 11.sp,
                color = Color.White.copy(alpha = 0.85f)
              )
            }
          }
        }

        // How it works card
        item {
          Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(2.dp),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(16.dp)) {
              Text(
                text = "How ApnaCart Rewards Work",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold
              )
              Spacer(modifier = Modifier.height(10.dp))
              RuleBullet(num = "1", title = "Shop & Earn", desc = "Earn reward points automatically on every verified order.")
              Spacer(modifier = Modifier.height(8.dp))
              RuleBullet(num = "2", title = "Checkout Redemption", desc = "Apply coins at checkout for flat ₹ discounts on order total.")
              Spacer(modifier = Modifier.height(8.dp))
              RuleBullet(num = "3", title = "Anti-Manipulation Protection", desc = "Points from cancelled/refunded orders are safely reversed.")
            }
          }
        }

        // History
        item {
          Text(
            text = "Reward Coins History",
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF202124)
          )
        }

        if (transactions.isEmpty()) {
          item {
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 24.dp),
              contentAlignment = Alignment.Center
            ) {
              Text(text = "No coin transactions yet.", fontSize = 13.sp, color = Color.Gray)
            }
          }
        } else {
          items(transactions) { tx ->
            RewardTransactionItem(tx = tx)
          }
        }
      }
    }
  }
}

@Composable
private fun RuleBullet(num: String, title: String, desc: String) {
  Row(verticalAlignment = Alignment.Top) {
    Box(
      modifier = Modifier
        .size(20.dp)
        .clip(CircleShape)
        .background(Color(0xFFE3F2FD)),
      contentAlignment = Alignment.Center
    ) {
      Text(text = num, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = ApnaBluePrimary)
    }
    Spacer(modifier = Modifier.width(8.dp))
    Column {
      Text(text = title, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
      Text(text = desc, fontSize = 11.sp, color = Color.Gray)
    }
  }
}

@Composable
private fun RewardTransactionItem(tx: RewardTransaction) {
  val isEarned = tx.type == "EARNED"
  Card(
    shape = RoundedCornerShape(10.dp),
    colors = CardDefaults.cardColors(containerColor = Color.White),
    elevation = CardDefaults.cardElevation(1.dp),
    modifier = Modifier.fillMaxWidth()
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(14.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
          imageVector = Icons.Default.Stars,
          contentDescription = null,
          tint = if (isEarned) Color(0xFFFFB300) else Color(0xFFD32F2F),
          modifier = Modifier.size(28.dp)
        )
        Spacer(modifier = Modifier.width(12.dp))
        Column {
          Text(text = tx.title, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
          Text(text = tx.timestamp, fontSize = 10.sp, color = Color.Gray)
        }
      }
      Text(
        text = if (isEarned) "+${tx.points} Coins" else "-${tx.points} Coins",
        fontSize = 14.sp,
        fontWeight = FontWeight.Bold,
        color = if (isEarned) ApnaDiscountGreen else Color(0xFFD32F2F)
      )
    }
  }
}
