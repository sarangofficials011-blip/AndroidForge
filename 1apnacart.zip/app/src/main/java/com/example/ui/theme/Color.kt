package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// ApnaCart Clean Blue & White Palette (Flipkart-inspired)
val ApnaBluePrimary = Color(0xFF2874F0)      // Iconic e-commerce royal blue
val ApnaBlueDark = Color(0xFF1259C3)         // Deeper navy blue
val ApnaBlueLight = Color(0xFF5392F9)
val ApnaBlueContainer = Color(0xFFEAF1FE)    // Soft ice blue card / pill
val ApnaOnBlueContainer = Color(0xFF003087)

val ApnaActionOrange = Color(0xFFFB641B)     // Vibrant action orange ("Buy Now")
val ApnaYellowRating = Color(0xFFFF9F00)     // Golden yellow badge
val ApnaRatingStar = Color(0xFFFFB300)

val ApnaDiscountGreen = Color(0xFF388E3C)    // Savings green
val ApnaDiscountGreenBg = Color(0xFFE8F5E9)

val ApnaBackground = Color(0xFFF1F3F6)      // Clean off-white page background
val ApnaSurface = Color(0xFFFFFFFF)         // Crisp pure white cards
val ApnaSurfaceVariant = Color(0xFFF5F7FB)
val ApnaOutline = Color(0xFFE0E0E0)

val TextPrimary = Color(0xFF212121)
val TextSecondary = Color(0xFF757575)
val TextMuted = Color(0xFF9E9E9E)

// Dark Mode Support
val ApnaBlueDarkPrimary = Color(0xFF68A1FC)
val ApnaBlueDarkContainerBg = Color(0xFF0F3268)
val ApnaBackgroundDark = Color(0xFF121418)
val ApnaSurfaceDark = Color(0xFF1C2028)
val ApnaSurfaceVariantDark = Color(0xFF272C38)
val TextPrimaryDark = Color(0xFFF5F7FA)
val TextSecondaryDark = Color(0xFFB4B9C4)
