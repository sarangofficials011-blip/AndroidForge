package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AiChatMessage
import com.example.model.Product
import com.example.ui.theme.ApnaActionOrange
import com.example.ui.theme.ApnaBlueContainer
import com.example.ui.theme.ApnaBluePrimary
import com.example.ui.theme.ApnaDiscountGreen
import com.example.ui.viewmodel.ApnaCartViewModel

@Composable
fun AiShoppingAssistantScreen(
  viewModel: ApnaCartViewModel,
  onBack: () -> Unit,
  onProductClick: (Product) -> Unit,
  modifier: Modifier = Modifier
) {
  BackHandler { onBack() }

  val messages by viewModel.aiChatMessages.collectAsState()
  var inputText by remember { mutableStateOf("") }

  Surface(
    color = MaterialTheme.colorScheme.background,
    modifier = modifier.fillMaxSize()
  ) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .statusBarsPadding()
    ) {
      // Header
      Surface(
        color = ApnaBluePrimary,
        tonalElevation = 4.dp,
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 12.dp)
        ) {
          IconButton(onClick = onBack) {
            Icon(
              imageVector = Icons.AutoMirrored.Filled.ArrowBack,
              contentDescription = "Back",
              tint = Color.White
            )
          }
          Box(
            modifier = Modifier
              .size(38.dp)
              .clip(CircleShape)
              .background(Color(0xFFFFD200)),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = Icons.Default.SmartToy,
              contentDescription = null,
              tint = ApnaBluePrimary,
              modifier = Modifier.size(24.dp)
            )
          }
          Spacer(modifier = Modifier.width(10.dp))
          Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Text(
                text = "ApnaCart AI Assistant",
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
              )
              Spacer(modifier = Modifier.width(6.dp))
              Icon(
                imageVector = Icons.Default.AutoAwesome,
                contentDescription = null,
                tint = Color(0xFFFFD200),
                modifier = Modifier.size(16.dp)
              )
            }
            Text(
              text = "Bilingual (Hindi/English) • Real Catalog Grounded",
              fontSize = 11.sp,
              color = Color.White.copy(alpha = 0.85f)
            )
          }
        }
      }

      // Disclaimer Banner
      Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
          .fillMaxWidth()
          .background(Color(0xFFE8F0FE))
          .padding(horizontal = 16.dp, vertical = 6.dp)
      ) {
        Icon(
          imageVector = Icons.Default.Info,
          contentDescription = null,
          tint = ApnaBluePrimary,
          modifier = Modifier.size(15.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = "Searches verified live ApnaCart products. Does not hallucinate or invent inventory.",
          fontSize = 11.sp,
          color = Color(0xFF1A73E8)
        )
      }

      // Chat Messages List
      LazyColumn(
        modifier = Modifier
          .weight(1f)
          .fillMaxWidth()
          .padding(horizontal = 12.dp),
        contentPadding = PaddingValues(vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        items(messages) { msg ->
          AiMessageBubble(
            msg = msg,
            onQuickReplyClick = { reply ->
              viewModel.sendAiAssistantQuery(reply)
            },
            onProductClick = onProductClick,
            onAddToCart = { product ->
              viewModel.addToCart(product)
            }
          )
        }
      }

      // Input Bar
      Surface(
        color = Color.White,
        tonalElevation = 8.dp,
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
          OutlinedTextField(
            value = inputText,
            onValueChange = { inputText = it },
            placeholder = {
              Text(
                text = "Ask in Hindi or English (e.g., 'Jeans under 700')...",
                fontSize = 13.sp,
                color = Color.Gray
              )
            },
            singleLine = true,
            shape = RoundedCornerShape(24.dp),
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = ApnaBluePrimary,
              unfocusedBorderColor = Color(0xFFD0D7E2),
              focusedContainerColor = Color(0xFFF8F9FA),
              unfocusedContainerColor = Color(0xFFF8F9FA)
            ),
            modifier = Modifier
              .weight(1f)
              .testTag("ai_input_field")
          )

          Spacer(modifier = Modifier.width(8.dp))

          IconButton(
            onClick = {
              if (inputText.isNotBlank()) {
                val query = inputText.trim()
                inputText = ""
                viewModel.sendAiAssistantQuery(query)
              }
            },
            modifier = Modifier
              .size(46.dp)
              .clip(CircleShape)
              .background(ApnaBluePrimary)
              .testTag("ai_send_button")
          ) {
            Icon(
              imageVector = Icons.AutoMirrored.Filled.Send,
              contentDescription = "Send",
              tint = Color.White,
              modifier = Modifier.size(20.dp)
            )
          }
        }
      }
    }
  }
}

@Composable
private fun AiMessageBubble(
  msg: AiChatMessage,
  onQuickReplyClick: (String) -> Unit,
  onProductClick: (Product) -> Unit,
  onAddToCart: (Product) -> Unit
) {
  val isUser = msg.isUser

  Column(
    modifier = Modifier.fillMaxWidth(),
    horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
  ) {
    Box(
      modifier = Modifier
        .clip(
          RoundedCornerShape(
            topStart = 16.dp,
            topEnd = 16.dp,
            bottomStart = if (isUser) 16.dp else 4.dp,
            bottomEnd = if (isUser) 4.dp else 16.dp
          )
        )
        .background(if (isUser) ApnaBluePrimary else Color(0xFFF1F3F4))
        .padding(horizontal = 14.dp, vertical = 10.dp)
        .fillMaxWidth(if (isUser) 0.8f else 0.95f)
    ) {
      Text(
        text = msg.message,
        fontSize = 14.sp,
        color = if (isUser) Color.White else Color(0xFF202124),
        lineHeight = 20.sp
      )
    }

    // Grounded Product Matches from real database
    if (msg.matchedProducts.isNotEmpty()) {
      Spacer(modifier = Modifier.height(8.dp))
      LazyRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        items(msg.matchedProducts) { prod ->
          Card(
            shape = RoundedCornerShape(10.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(2.dp),
            modifier = Modifier
              .width(180.dp)
              .clickable { onProductClick(prod) }
              .testTag("ai_product_${prod.id}")
          ) {
            Column(modifier = Modifier.padding(10.dp)) {
              Text(
                text = prod.brand.uppercase(),
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = Color.Gray
              )
              Text(
                text = prod.title,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1
              )
              Spacer(modifier = Modifier.height(4.dp))
              Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                  text = "₹${prod.price}",
                  fontSize = 14.sp,
                  fontWeight = FontWeight.ExtraBold,
                  color = ApnaBluePrimary
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = "₹${prod.originalMrp}",
                  fontSize = 11.sp,
                  color = Color.Gray,
                  style = MaterialTheme.typography.bodySmall.copy(textDecoration = androidx.compose.ui.text.style.TextDecoration.LineThrough)
                )
              }
              Spacer(modifier = Modifier.height(6.dp))
              Button(
                onClick = { onAddToCart(prod) },
                colors = ButtonDefaults.buttonColors(containerColor = ApnaActionOrange),
                shape = RoundedCornerShape(6.dp),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                modifier = Modifier
                  .fillMaxWidth()
                  .height(32.dp)
              ) {
                Icon(
                  imageVector = Icons.Default.ShoppingBag,
                  contentDescription = null,
                  tint = Color.White,
                  modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(text = "Add to Cart", fontSize = 11.sp, fontWeight = FontWeight.Bold)
              }
            }
          }
        }
      }
    }

    // Quick Action Replies
    if (msg.quickReplies.isNotEmpty()) {
      Spacer(modifier = Modifier.height(6.dp))
      LazyRow(
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        items(msg.quickReplies) { reply ->
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(16.dp))
              .border(1.dp, ApnaBluePrimary.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
              .background(Color.White)
              .clickable { onQuickReplyClick(reply) }
              .padding(horizontal = 12.dp, vertical = 6.dp)
          ) {
            Text(
              text = reply,
              fontSize = 12.sp,
              fontWeight = FontWeight.Medium,
              color = ApnaBluePrimary
            )
          }
        }
      }
    }
  }
}
