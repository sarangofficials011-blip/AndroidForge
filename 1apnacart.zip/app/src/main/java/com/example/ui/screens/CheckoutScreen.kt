package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocalAtm
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Stars
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import com.example.ui.viewmodel.PaymentResultState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Address
import com.example.model.ApnaStrings
import com.example.ui.theme.ApnaActionOrange
import com.example.ui.theme.ApnaBlueContainer
import com.example.ui.theme.ApnaBlueDark
import com.example.ui.theme.ApnaBluePrimary
import com.example.ui.theme.ApnaDiscountGreen
import com.example.ui.viewmodel.ApnaCartViewModel

@Composable
fun CheckoutScreen(
  viewModel: ApnaCartViewModel,
  onBack: () -> Unit,
  onAddNewAddressClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  BackHandler { onBack() }

  val cartItems by viewModel.cartItems.collectAsState()
  val selectedAddress by viewModel.selectedAddress.collectAsState()
  val appliedCoupon by viewModel.appliedCoupon.collectAsState()
  val addresses by viewModel.addresses.collectAsState()
  val currentLanguage by viewModel.currentLanguage.collectAsState()
  val walletBalance by viewModel.walletBalance.collectAsState()
  val rewardPoints by viewModel.rewardPoints.collectAsState()
  val paymentResultState by viewModel.paymentResultState.collectAsState()

  var useWallet by remember { mutableStateOf(false) }
  var useRewardPoints by remember { mutableStateOf(false) }
  var simulateBankFailure by remember { mutableStateOf(false) }

  var selectedPaymentMethod by remember { mutableStateOf("UPI") }
  var upiProvider by remember { mutableStateOf("Google Pay") }
  var upiIdInput by remember { mutableStateOf("demo_user@okhdfcbank") }
  var deliverySpeed by remember { mutableStateOf("Standard") }
  var showAddressPicker by remember { mutableStateOf(false) }

  // Calculation
  val productTotal = cartItems.sumOf { it.itemTotalPrice }
  val couponDiscount = when (appliedCoupon?.discountType) {
    "FLAT" -> appliedCoupon?.discountValue ?: 0
    "PERCENT" -> (((productTotal * (appliedCoupon?.discountValue ?: 0)) / 100)).coerceAtMost(400)
    else -> 0
  }
  val baseDelivery = if (productTotal >= 499 || appliedCoupon?.discountType == "FREESHIP") 0 else 50
  val speedExtra = if (deliverySpeed == "Express") 40 else 0
  val totalDelivery = baseDelivery + speedExtra
  val subTotalAfterDiscount = (productTotal - couponDiscount + totalDelivery).coerceAtLeast(0)
  val walletDeduction = if (useWallet) walletBalance.coerceAtMost(subTotalAfterDiscount) else 0
  val afterWallet = (subTotalAfterDiscount - walletDeduction).coerceAtLeast(0)
  val rewardDeduction = if (useRewardPoints) rewardPoints.coerceAtMost(afterWallet) else 0
  val finalPayable = (afterWallet - rewardDeduction).coerceAtLeast(0)

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
  ) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .verticalScroll(rememberScrollState())
        .padding(bottom = 90.dp)
    ) {
      // 1. Top App Bar
      Surface(
        color = ApnaBluePrimary,
        tonalElevation = 4.dp,
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(horizontal = 8.dp, vertical = 8.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          IconButton(
            onClick = onBack,
            modifier = Modifier.testTag("checkout_back_btn")
          ) {
            Icon(
              imageVector = Icons.AutoMirrored.Filled.ArrowBack,
              contentDescription = "Back",
              tint = Color.White
            )
          }
          Text(
            text = "Order Summary & Demo Payment",
            fontSize = 17.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
          )
        }
      }

      // 2. Mandatory Clear Demo Payment Label
      Card(
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF8E1)),
        border = CardDefaults.outlinedCardBorder().copy(width = 1.dp, brush = androidx.compose.ui.graphics.SolidColor(Color(0xFFFFB300))),
        modifier = Modifier
          .fillMaxWidth()
          .padding(12.dp)
      ) {
        Row(
          modifier = Modifier.padding(12.dp),
          verticalAlignment = Alignment.Top
        ) {
          Icon(imageVector = Icons.Default.Info, contentDescription = null, tint = Color(0xFFE65100), modifier = Modifier.size(20.dp))
          Spacer(modifier = Modifier.width(10.dp))
          Column {
            Text(
              text = "Demo Payment — No Money Charged",
              fontSize = 13.sp,
              fontWeight = FontWeight.Bold,
              color = Color(0xFFE65100)
            )
            Text(
              text = "This application operates in simulated demo mode. No payment credentials are collected or saved. Completing this order records a local demo order for testing.",
              fontSize = 11.sp,
              color = Color(0xFF5D4037),
              lineHeight = 15.sp,
              modifier = Modifier.padding(top = 2.dp)
            )
          }
        }
      }

      // 3. Delivery Address Review
      Card(
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp)
      ) {
        Column(modifier = Modifier.padding(12.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(imageVector = Icons.Default.LocationOn, contentDescription = null, tint = ApnaBluePrimary, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text(text = "Deliver To", fontSize = 14.sp, fontWeight = FontWeight.Bold)
            }

            Text(
              text = if (showAddressPicker) "Close" else "Change",
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold,
              color = ApnaBluePrimary,
              modifier = Modifier.clickable { showAddressPicker = !showAddressPicker }.padding(4.dp)
            )
          }

          Spacer(modifier = Modifier.height(6.dp))

          if (showAddressPicker) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
              addresses.forEach { addr ->
                val isChosen = addr.id == selectedAddress.id
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(6.dp))
                    .background(if (isChosen) ApnaBlueContainer else Color(0xFFF7F9FC))
                    .clickable {
                      viewModel.selectAddress(addr)
                      showAddressPicker = false
                    }
                    .padding(8.dp),
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  RadioButton(
                    selected = isChosen,
                    onClick = {
                      viewModel.selectAddress(addr)
                      showAddressPicker = false
                    },
                    colors = RadioButtonDefaults.colors(selectedColor = ApnaBluePrimary)
                  )
                  Spacer(modifier = Modifier.width(6.dp))
                  Column {
                    Text(text = "${addr.fullName} (${addr.addressType})", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text(text = addr.formattedFullAddress, fontSize = 11.sp, color = Color.Gray)
                  }
                }
              }

              Button(
                onClick = onAddNewAddressClick,
                colors = ButtonDefaults.buttonColors(containerColor = ApnaBluePrimary),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth()
              ) {
                Text("+ Add New Address", fontSize = 12.sp)
              }
            }
          } else {
            Text(
              text = "${selectedAddress.fullName} • Phone: ${selectedAddress.phone}",
              fontSize = 13.sp,
              fontWeight = FontWeight.Bold
            )
            Text(
              text = selectedAddress.formattedFullAddress,
              fontSize = 12.sp,
              color = Color.Gray
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      // 4. Delivery Speed
      Card(
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp)
      ) {
        Column(modifier = Modifier.padding(12.dp)) {
          Text(text = "Delivery Speed", fontSize = 14.sp, fontWeight = FontWeight.Bold)
          Spacer(modifier = Modifier.height(8.dp))

          // Standard
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(6.dp))
              .background(if (deliverySpeed == "Standard") ApnaBlueContainer else Color.Transparent)
              .clickable { deliverySpeed = "Standard" }
              .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            RadioButton(
              selected = deliverySpeed == "Standard",
              onClick = { deliverySpeed = "Standard" },
              colors = RadioButtonDefaults.colors(selectedColor = ApnaBluePrimary)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Column(modifier = Modifier.weight(1f)) {
              Text(text = "Standard Delivery (2-3 Days)", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
              Text(text = if (baseDelivery == 0) "FREE Delivery eligible" else "₹50 delivery charge", fontSize = 11.sp, color = Color.Gray)
            }
            Text(text = if (baseDelivery == 0) "FREE" else "₹50", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (baseDelivery == 0) ApnaDiscountGreen else Color.Black)
          }

          Spacer(modifier = Modifier.height(4.dp))

          // Express
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(6.dp))
              .background(if (deliverySpeed == "Express") ApnaBlueContainer else Color.Transparent)
              .clickable { deliverySpeed = "Express" }
              .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            RadioButton(
              selected = deliverySpeed == "Express",
              onClick = { deliverySpeed = "Express" },
              colors = RadioButtonDefaults.colors(selectedColor = ApnaBluePrimary)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Column(modifier = Modifier.weight(1f)) {
              Text(text = "⚡ Express Air Delivery (Tomorrow by 2 PM)", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
              Text(text = "Simulated BlueDart priority cargo", fontSize = 11.sp, color = Color.Gray)
            }
            Text(text = "₹40", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = ApnaBlueDark)
          }
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      // 4b. ApnaCart Wallet & Reward Points
      Card(
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp).testTag("checkout_perks_card")
      ) {
        Column(modifier = Modifier.padding(12.dp)) {
          Text(text = "ApnaCart Perks & Credits", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = ApnaBlueDark)
          Spacer(modifier = Modifier.height(6.dp))

          // Wallet balance toggle
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(6.dp))
              .background(if (useWallet) ApnaBlueContainer else Color.Transparent)
              .clickable(enabled = walletBalance > 0) { useWallet = !useWallet }
              .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Checkbox(
              checked = useWallet,
              onCheckedChange = { useWallet = it },
              enabled = walletBalance > 0,
              colors = CheckboxDefaults.colors(checkedColor = ApnaBluePrimary)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Icon(imageVector = Icons.Default.AccountBalanceWallet, contentDescription = null, tint = ApnaBluePrimary, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Column(modifier = Modifier.weight(1f)) {
              Text(text = "Use ApnaCart Wallet Balance", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
              Text(
                text = if (walletBalance > 0) "Available: ₹$walletBalance (Saves up to ₹${walletBalance.coerceAtMost(subTotalAfterDiscount)})" else "Wallet balance is ₹0",
                fontSize = 11.sp,
                color = Color.Gray
              )
            }
          }

          // Rewards / SuperCoins toggle
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(6.dp))
              .background(if (useRewardPoints) ApnaBlueContainer else Color.Transparent)
              .clickable(enabled = rewardPoints > 0) { useRewardPoints = !useRewardPoints }
              .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Checkbox(
              checked = useRewardPoints,
              onCheckedChange = { useRewardPoints = it },
              enabled = rewardPoints > 0,
              colors = CheckboxDefaults.colors(checkedColor = ApnaBluePrimary)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Icon(imageVector = Icons.Default.Stars, contentDescription = null, tint = ApnaActionOrange, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Column(modifier = Modifier.weight(1f)) {
              Text(text = "Redeem SuperCoins", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
              Text(
                text = if (rewardPoints > 0) "Available: $rewardPoints Coins (₹1/coin, saves up to ₹${rewardPoints.coerceAtMost(afterWallet)})" else "No SuperCoins available",
                fontSize = 11.sp,
                color = Color.Gray
              )
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      // 5. Payment Selection (Mock)
      Card(
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp)
      ) {
        Column(modifier = Modifier.padding(12.dp)) {
          Text(text = "Payment Method (Simulated)", fontSize = 14.sp, fontWeight = FontWeight.Bold)
          Spacer(modifier = Modifier.height(8.dp))

          // UPI
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(6.dp))
              .background(if (selectedPaymentMethod == "UPI") ApnaBlueContainer else Color.Transparent)
              .clickable { selectedPaymentMethod = "UPI" }
              .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            RadioButton(selected = selectedPaymentMethod == "UPI", onClick = { selectedPaymentMethod = "UPI" }, colors = RadioButtonDefaults.colors(selectedColor = ApnaBluePrimary))
            Spacer(modifier = Modifier.width(8.dp))
            Icon(imageVector = Icons.Default.QrCode2, contentDescription = null, tint = ApnaBluePrimary, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Column {
              Text(text = "Demo UPI (Google Pay, PhonePe, Paytm)", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
              Text(text = "Simulated instant approval", fontSize = 11.sp, color = Color.Gray)
            }
          }

          if (selectedPaymentMethod == "UPI") {
            Row(modifier = Modifier.padding(start = 32.dp, top = 4.dp, bottom = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
              listOf("Google Pay", "PhonePe", "Paytm").forEach { app ->
                val isApp = upiProvider == app
                Box(
                  modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(if (isApp) ApnaBluePrimary else Color(0xFFF1F5F9))
                    .clickable { upiProvider = app }
                    .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                  Text(text = app, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (isApp) Color.White else Color.Black)
                }
              }
            }
          }

          // Cash on Delivery
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(6.dp))
              .background(if (selectedPaymentMethod == "COD") ApnaBlueContainer else Color.Transparent)
              .clickable { selectedPaymentMethod = "COD" }
              .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            RadioButton(selected = selectedPaymentMethod == "COD", onClick = { selectedPaymentMethod = "COD" }, colors = RadioButtonDefaults.colors(selectedColor = ApnaBluePrimary))
            Spacer(modifier = Modifier.width(8.dp))
            Icon(imageVector = Icons.Default.LocalAtm, contentDescription = null, tint = ApnaBluePrimary, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Column {
              Text(text = "Cash on Delivery (Demo COD)", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
              Text(text = "Pay cash or QR at delivery", fontSize = 11.sp, color = Color.Gray)
            }
          }

          // Net Banking
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(6.dp))
              .background(if (selectedPaymentMethod == "NETBANKING") ApnaBlueContainer else Color.Transparent)
              .clickable { selectedPaymentMethod = "NETBANKING" }
              .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            RadioButton(selected = selectedPaymentMethod == "NETBANKING", onClick = { selectedPaymentMethod = "NETBANKING" }, colors = RadioButtonDefaults.colors(selectedColor = ApnaBluePrimary))
            Spacer(modifier = Modifier.width(8.dp))
            Icon(imageVector = Icons.Default.AccountBalance, contentDescription = null, tint = ApnaBluePrimary, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Column {
              Text(text = "Net Banking (Demo Sandbox)", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
              Text(text = "SBI, HDFC, ICICI, Axis Bank", fontSize = 11.sp, color = Color.Gray)
            }
          }

          // Razorpay Indian Gateway
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(6.dp))
              .background(if (selectedPaymentMethod == "RAZORPAY") ApnaBlueContainer else Color.Transparent)
              .clickable { selectedPaymentMethod = "RAZORPAY" }
              .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            RadioButton(selected = selectedPaymentMethod == "RAZORPAY", onClick = { selectedPaymentMethod = "RAZORPAY" }, colors = RadioButtonDefaults.colors(selectedColor = ApnaBluePrimary))
            Spacer(modifier = Modifier.width(8.dp))
            Icon(imageVector = Icons.Default.CreditCard, contentDescription = null, tint = Color(0xFF0C2340), modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Column {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Text(text = "Razorpay Gateway (Test Mode)", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0C2340))
                Spacer(modifier = Modifier.width(6.dp))
                Box(
                  modifier = Modifier
                    .clip(RoundedCornerShape(3.dp))
                    .background(Color(0xFFE0F2FE))
                    .padding(horizontal = 4.dp, vertical = 1.dp)
                ) {
                  Text(text = "SANDBOX", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = ApnaBlueDark)
                }
              }
              Text(text = "Cards, UPI, Netbanking & Wallets in India", fontSize = 11.sp, color = Color.Gray)
            }
          }

          if (selectedPaymentMethod == "RAZORPAY") {
            Box(
              modifier = Modifier
                .padding(start = 28.dp, top = 4.dp, end = 8.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(Color(0xFFF8FAFC))
                .border(0.5.dp, Color(0xFFCBD5E1), RoundedCornerShape(6.dp))
                .padding(8.dp)
            ) {
              Text(
                text = "• Production Flow: Razorpay orders are securely initiated on backend with your Key Secret.\n• Security: Frontend receives only order_id. Client signature verification is strictly validated server-side.\n• Zero secrets stored in client APK.",
                fontSize = 10.sp,
                color = Color.DarkGray,
                lineHeight = 14.sp
              )
            }
          }
        }
      }

      // 5b. Payment Failure Simulation Mode (For Sandbox Testing)
      Card(
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFF1F5F9)),
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 12.dp, vertical = 6.dp)
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(10.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = "Simulate Payment Failure",
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold,
              color = Color(0xFF334155)
            )
            Text(
              text = "Test bank timeout & error recovery UI",
              fontSize = 10.sp,
              color = Color(0xFF64748B)
            )
          }
          Switch(
            checked = simulateBankFailure,
            onCheckedChange = { simulateBankFailure = it },
            colors = SwitchDefaults.colors(
              checkedThumbColor = Color(0xFFDC2626),
              checkedTrackColor = Color(0xFFFCA5A5)
            ),
            modifier = Modifier.testTag("simulate_payment_failure_switch")
          )
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      // 6. Review Order Items
      Card(
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp)
      ) {
        Column(modifier = Modifier.padding(12.dp)) {
          Text(text = "Review Order Items (${cartItems.size})", fontSize = 14.sp, fontWeight = FontWeight.Bold)
          Spacer(modifier = Modifier.height(6.dp))

          cartItems.forEach { item ->
            Row(modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp), horizontalArrangement = Arrangement.SpaceBetween) {
              Text(text = "${item.quantity}x ${item.product.title}", fontSize = 12.sp, color = Color.Black, modifier = Modifier.weight(1f), maxLines = 1)
              Text(text = "₹${item.itemTotalPrice}", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
          }

          if (couponDiscount > 0) {
            Row(modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp), horizontalArrangement = Arrangement.SpaceBetween) {
              Text(text = "Coupon Discount (${appliedCoupon?.code})", fontSize = 12.sp, color = ApnaDiscountGreen)
              Text(text = "-₹$couponDiscount", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = ApnaDiscountGreen)
            }
          }

          if (walletDeduction > 0) {
            Row(modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp), horizontalArrangement = Arrangement.SpaceBetween) {
              Text(text = "ApnaCart Wallet Used", fontSize = 12.sp, color = ApnaBluePrimary)
              Text(text = "-₹$walletDeduction", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = ApnaBluePrimary)
            }
          }

          if (rewardDeduction > 0) {
            Row(modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp), horizontalArrangement = Arrangement.SpaceBetween) {
              Text(text = "SuperCoins Redeemed", fontSize = 12.sp, color = ApnaActionOrange)
              Text(text = "-₹$rewardDeduction", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = ApnaActionOrange)
            }
          }

          Spacer(modifier = Modifier.height(8.dp))
          HorizontalDivider(color = Color(0xFFEEEEEE))
          Spacer(modifier = Modifier.height(8.dp))

          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(text = "Final Payable Amount", fontSize = 14.sp, fontWeight = FontWeight.Bold)
            Text(text = "₹$finalPayable", fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, color = ApnaBluePrimary)
          }
        }
      }
    }

    // Sticky Place Order Button
    Surface(
      color = Color.White,
      tonalElevation = 6.dp,
      shadowElevation = 8.dp,
      modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth()
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .navigationBarsPadding()
          .padding(horizontal = 16.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(text = "₹$finalPayable", fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
          Text(text = "Demo Checkout", fontSize = 11.sp, color = Color.Gray)
        }

        Button(
          onClick = {
            val paymentDesc = when (selectedPaymentMethod) {
              "UPI" -> "Demo UPI ($upiProvider - Simulated)"
              "COD" -> "Cash on Delivery (Demo)"
              "RAZORPAY" -> "Razorpay Gateway (Sandbox)"
              else -> "Net Banking (Demo SBI)"
            }
            viewModel.processOrderPayment(
              paymentMethod = paymentDesc,
              deliverySpeed = deliverySpeed,
              useWallet = useWallet,
              useRewardPoints = useRewardPoints,
              simulateFailure = simulateBankFailure
            )
          },
          enabled = paymentResultState !is PaymentResultState.Processing,
          colors = ButtonDefaults.buttonColors(containerColor = ApnaActionOrange),
          shape = RoundedCornerShape(6.dp),
          modifier = Modifier.height(44.dp).testTag("confirm_place_order_btn")
        ) {
          if (paymentResultState is PaymentResultState.Processing) {
            CircularProgressIndicator(
              modifier = Modifier.size(16.dp),
              color = Color.White,
              strokeWidth = 2.dp
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = "Processing...",
              fontSize = 13.sp,
              fontWeight = FontWeight.Bold
            )
          } else {
            Text(
              text = ApnaStrings.get("place_demo_order", currentLanguage),
              fontSize = 13.sp,
              fontWeight = FontWeight.Bold
            )
          }
        }
      }
    }

    // Payment Processing Modal
    if (paymentResultState is PaymentResultState.Processing) {
      AlertDialog(
        onDismissRequest = {},
        icon = {
          CircularProgressIndicator(
            modifier = Modifier.size(36.dp),
            color = ApnaBluePrimary,
            strokeWidth = 3.dp
          )
        },
        title = {
          Text(
            text = "Connecting to Payment Gateway...",
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold
          )
        },
        text = {
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
              text = "Securing transaction with bank server via sandbox protocol. Please wait...",
              fontSize = 12.sp,
              color = Color.DarkGray
            )
          }
        },
        confirmButton = {}
      )
    }

    // Payment Failure Dialog
    if (paymentResultState is PaymentResultState.Failure) {
      val failure = paymentResultState as PaymentResultState.Failure
      AlertDialog(
        onDismissRequest = { viewModel.clearPaymentError() },
        icon = {
          Icon(
            imageVector = Icons.Default.ErrorOutline,
            contentDescription = "Payment Failure",
            tint = Color(0xFFDC2626),
            modifier = Modifier.size(40.dp)
          )
        },
        title = {
          Text(
            text = "Payment Failed / भुगतान विफल",
            fontSize = 17.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFFDC2626)
          )
        },
        text = {
          Column {
            Text(
              text = failure.reason,
              fontSize = 13.sp,
              color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(8.dp))
            Surface(
              color = Color(0xFFFEF2F2),
              shape = RoundedCornerShape(6.dp),
              modifier = Modifier.fillMaxWidth()
            ) {
              Column(modifier = Modifier.padding(8.dp)) {
                Text(
                  text = "✓ Cart items & applied coupons are saved safely.",
                  fontSize = 11.sp,
                  color = Color(0xFF991B1B)
                )
                Text(
                  text = "✓ No money was deducted from your account.",
                  fontSize = 11.sp,
                  color = Color(0xFF991B1B)
                )
              }
            }
          }
        },
        confirmButton = {
          Button(
            onClick = {
              viewModel.clearPaymentError()
              simulateBankFailure = false
              val paymentDesc = when (selectedPaymentMethod) {
                "UPI" -> "Demo UPI ($upiProvider - Simulated)"
                "COD" -> "Cash on Delivery (Demo)"
                "RAZORPAY" -> "Razorpay Gateway (Sandbox)"
                else -> "Net Banking (Demo SBI)"
              }
              viewModel.processOrderPayment(
                paymentMethod = paymentDesc,
                deliverySpeed = deliverySpeed,
                useWallet = useWallet,
                useRewardPoints = useRewardPoints,
                simulateFailure = false
              )
            },
            colors = ButtonDefaults.buttonColors(containerColor = ApnaBluePrimary),
            modifier = Modifier.testTag("retry_payment_btn")
          ) {
            Icon(imageVector = Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("Retry Payment")
          }
        },
        dismissButton = {
          OutlinedButton(
            onClick = { viewModel.clearPaymentError() },
            modifier = Modifier.testTag("change_payment_method_btn")
          ) {
            Text("Change Method")
          }
        }
      )
    }
  }
}
