package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.ui.theme.ApnaActionOrange
import com.example.ui.theme.ApnaBluePrimary
import com.example.ui.theme.ApnaDiscountGreen
import com.example.ui.viewmodel.ApnaCartViewModel

@Composable
fun WalletScreen(
  viewModel: ApnaCartViewModel,
  onBack: () -> Unit,
  modifier: Modifier = Modifier
) {
  BackHandler { onBack() }

  val balance by viewModel.walletBalance.collectAsState()
  val transactions by viewModel.walletTransactions.collectAsState()

  var giftCardCodeInput by remember { mutableStateOf("") }

  Surface(
    color = MaterialTheme.colorScheme.background,
    modifier = modifier.fillMaxSize()
  ) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .statusBarsPadding()
    ) {
      // Top App Bar
      Surface(
        color = ApnaBluePrimary,
        tonalElevation = 4.dp,
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 12.dp)
        ) {
          IconButton(onClick = onBack) {
            Icon(
              imageVector = Icons.AutoMirrored.Filled.ArrowBack,
              contentDescription = "Back",
              tint = Color.White
            )
          }
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = "ApnaCart Wallet",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
          )
        }
      }

      LazyColumn(
        modifier = Modifier
          .fillMaxSize()
          .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
      ) {
        // Balance Hero Card
        item {
          Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = ApnaBluePrimary),
            elevation = CardDefaults.cardElevation(6.dp),
            modifier = Modifier
              .fillMaxWidth()
              .testTag("wallet_balance_card")
          ) {
            Column(modifier = Modifier.padding(20.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text(
                  text = "Available Balance",
                  fontSize = 13.sp,
                  color = Color.White.copy(alpha = 0.85f)
                )
                Icon(
                  imageVector = Icons.Default.AccountBalanceWallet,
                  contentDescription = null,
                  tint = Color(0xFFFFD200),
                  modifier = Modifier.size(24.dp)
                )
              }
              Spacer(modifier = Modifier.height(8.dp))
              Text(
                text = "₹$balance",
                fontSize = 32.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Color.White
              )
              Spacer(modifier = Modifier.height(6.dp))
              Text(
                text = "Usable instantly at Checkout for discounts and orders",
                fontSize = 11.sp,
                color = Color.White.copy(alpha = 0.75f)
              )
            }
          }
        }

        // Redeem Gift Card Input Box
        item {
          Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(2.dp),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(16.dp)) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                  imageVector = Icons.Default.CardGiftcard,
                  contentDescription = null,
                  tint = ApnaActionOrange,
                  modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                  text = "Have a Gift Card?",
                  fontSize = 15.sp,
                  fontWeight = FontWeight.Bold
                )
              }
              Spacer(modifier = Modifier.height(10.dp))
              Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
              ) {
                OutlinedTextField(
                  value = giftCardCodeInput,
                  onValueChange = { giftCardCodeInput = it.uppercase() },
                  placeholder = { Text("Enter code (e.g., FESTIVE500)", fontSize = 12.sp) },
                  singleLine = true,
                  shape = RoundedCornerShape(8.dp),
                  colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = ApnaBluePrimary,
                    unfocusedBorderColor = Color(0xFFD0D7E2)
                  ),
                  modifier = Modifier
                    .weight(1f)
                    .testTag("gift_card_input")
                )
                Spacer(modifier = Modifier.width(8.dp))
                Button(
                  onClick = {
                    if (giftCardCodeInput.isNotBlank()) {
                      viewModel.redeemGiftCard(giftCardCodeInput)
                      giftCardCodeInput = ""
                    }
                  },
                  colors = ButtonDefaults.buttonColors(containerColor = ApnaBluePrimary),
                  shape = RoundedCornerShape(8.dp),
                  modifier = Modifier.testTag("redeem_gift_card_button")
                ) {
                  Text("Redeem", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
              }
            }
          }
        }

        // Compliance & Security Notice
        item {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(8.dp))
              .background(Color(0xFFE8F5E9))
              .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(
              imageVector = Icons.Default.Lock,
              contentDescription = null,
              tint = ApnaDiscountGreen,
              modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(
              text = "ApnaCart Wallet is an internal store ledger. Supports eligible order refunds and store promotional credits. No unauthorized external cash-outs.",
              fontSize = 11.sp,
              color = Color(0xFF2E7D32),
              lineHeight = 16.sp
            )
          }
        }

        // Transaction History Header
        item {
          Text(
            text = "Transaction History",
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF202124)
          )
        }

        // Transaction List
        if (transactions.isEmpty()) {
          item {
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 24.dp),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = "No wallet transactions yet.",
                fontSize = 13.sp,
                color = Color.Gray
              )
            }
          }
        } else {
          items(transactions) { tx ->
            WalletTransactionItem(tx = tx)
          }
        }
      }
    }
  }
}

@Composable
private fun WalletTransactionItem(tx: WalletTransaction) {
  val isCredit = tx.type == "CREDIT" || tx.type == "REFUND" || tx.type == "GIFT_CARD"
  Card(
    shape = RoundedCornerShape(10.dp),
    colors = CardDefaults.cardColors(containerColor = Color.White),
    elevation = CardDefaults.cardElevation(1.dp),
    modifier = Modifier.fillMaxWidth()
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(14.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
          modifier = Modifier
            .size(36.dp)
            .clip(CircleShape)
            .background(if (isCredit) Color(0xFFE8F5E9) else Color(0xFFFFEBEE)),
          contentAlignment = Alignment.Center
        ) {
          Text(
            text = if (isCredit) "+" else "-",
            fontSize = 18.sp,
            fontWeight = FontWeight.ExtraBold,
            color = if (isCredit) ApnaDiscountGreen else Color(0xFFD32F2F)
          )
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column {
          Text(
            text = tx.title,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold
          )
          Text(
            text = tx.description,
            fontSize = 11.sp,
            color = Color.Gray,
            maxLines = 1
          )
          Text(
            text = tx.timestamp,
            fontSize = 10.sp,
            color = Color.LightGray
          )
        }
      }

      Text(
        text = if (isCredit) "+₹${tx.amount}" else "-₹${tx.amount}",
        fontSize = 15.sp,
        fontWeight = FontWeight.Bold,
        color = if (isCredit) ApnaDiscountGreen else Color(0xFFD32F2F)
      )
    }
  }
}
