package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.AppLanguage
import com.example.model.ApnaStrings
import com.example.model.Product
import com.example.ui.theme.ApnaActionOrange
import com.example.ui.theme.ApnaBlueContainer
import com.example.ui.theme.ApnaBluePrimary
import com.example.ui.theme.ApnaDiscountGreen
import com.example.ui.theme.ApnaDiscountGreenBg

@Composable
fun ProductCard(
  product: Product,
  isWishlisted: Boolean,
  currentLanguage: AppLanguage = AppLanguage.ENGLISH,
  onProductClick: (Product) -> Unit,
  onWishlistToggle: (Product) -> Unit,
  onAddToCart: (Product) -> Unit = {},
  modifier: Modifier = Modifier
) {
  Card(
    shape = RoundedCornerShape(10.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    border = CardDefaults.outlinedCardBorder().copy(width = 0.5.dp, brush = androidx.compose.ui.graphics.SolidColor(Color(0xFFE0E0E0))),
    modifier = modifier
      .fillMaxWidth()
      .clickable { onProductClick(product) }
      .testTag("product_card_${product.id}")
  ) {
    Column(modifier = Modifier.fillMaxWidth()) {
      // Image Section
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(155.dp)
          .background(Color(0xFFF7F9FC))
      ) {
        val bannerRes = product.drawableRes ?: R.drawable.apnacart_blue_icon_1793278921772
        Image(
          painter = painterResource(id = bannerRes),
          contentDescription = product.title,
          contentScale = ContentScale.Crop,
          modifier = Modifier.fillMaxSize()
        )

        // Top Left Badge: Flipkart-style Offer or Bestseller
        if (product.discountPercent >= 40) {
          Box(
            modifier = Modifier
              .padding(6.dp)
              .align(Alignment.TopStart)
              .clip(RoundedCornerShape(4.dp))
              .background(ApnaDiscountGreen)
              .padding(horizontal = 6.dp, vertical = 2.dp)
          ) {
            Text(
              text = "${product.discountPercent}% OFF",
              fontSize = 10.sp,
              fontWeight = FontWeight.Bold,
              color = Color.White
            )
          }
        }

        // Top Right Wishlist Heart Button
        IconButton(
          onClick = { onWishlistToggle(product) },
          modifier = Modifier
            .padding(4.dp)
            .size(34.dp)
            .align(Alignment.TopEnd)
            .clip(CircleShape)
            .background(Color.White.copy(alpha = 0.9f))
            .testTag("wishlist_btn_${product.id}")
        ) {
          Icon(
            imageVector = if (isWishlisted) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
            contentDescription = "Wishlist",
            tint = if (isWishlisted) Color(0xFFE53935) else Color.Gray,
            modifier = Modifier.size(18.dp)
          )
        }

        // Bottom Left Rating Pill (Flipkart green rating pill)
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier
            .padding(6.dp)
            .align(Alignment.BottomStart)
            .clip(RoundedCornerShape(4.dp))
            .background(ApnaDiscountGreen)
            .padding(horizontal = 6.dp, vertical = 2.dp)
        ) {
          Text(
            text = "%.1f".format(product.rating),
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
          )
          Spacer(modifier = Modifier.width(2.dp))
          Icon(
            imageVector = Icons.Filled.Star,
            contentDescription = null,
            tint = Color.White,
            modifier = Modifier.size(10.dp)
          )
        }
      }

      // Details Section
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(8.dp)
      ) {
        // Brand Name
        Text(
          text = product.brand,
          fontSize = 11.sp,
          fontWeight = FontWeight.SemiBold,
          color = ApnaBluePrimary,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis
        )

        Spacer(modifier = Modifier.height(2.dp))

        // Product Title
        Text(
          text = product.title,
          fontSize = 12.sp,
          fontWeight = FontWeight.Medium,
          color = MaterialTheme.colorScheme.onSurface,
          maxLines = 2,
          overflow = TextOverflow.Ellipsis,
          lineHeight = 16.sp,
          modifier = Modifier.height(32.dp)
        )

        Spacer(modifier = Modifier.height(6.dp))

        // Price Row
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          Text(
            text = "₹${product.price}",
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
          )

          if (product.originalMrp > product.price) {
            Text(
              text = "₹${product.originalMrp}",
              fontSize = 11.sp,
              color = Color.Gray,
              textDecoration = TextDecoration.LineThrough
            )
          }
        }

        Spacer(modifier = Modifier.height(2.dp))

        // Stock status & Demo tag
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
          modifier = Modifier.fillMaxWidth()
        ) {
          Text(
            text = if (product.inStock) {
              if (product.price >= 499) "⚡ Free Delivery" else "Demo: ${product.stockQuantity} in stock"
            } else {
              "Out of stock"
            },
            fontSize = 10.sp,
            fontWeight = FontWeight.Medium,
            color = if (product.inStock) ApnaDiscountGreen else Color.Red
          )

          Text(
            text = "Demo",
            fontSize = 9.sp,
            color = Color.Gray
          )
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Blue Primary Action Button
        Button(
          onClick = { onAddToCart(product) },
          enabled = product.inStock,
          colors = ButtonDefaults.buttonColors(
            containerColor = ApnaBluePrimary,
            contentColor = Color.White
          ),
          shape = RoundedCornerShape(6.dp),
          modifier = Modifier
            .fillMaxWidth()
            .height(34.dp)
            .testTag("add_to_cart_${product.id}")
        ) {
          Icon(
            imageVector = Icons.Filled.ShoppingBag,
            contentDescription = null,
            modifier = Modifier.size(13.dp)
          )
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = if (product.inStock) ApnaStrings.get("add_to_cart", currentLanguage) else ApnaStrings.get("out_of_stock", currentLanguage),
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold
          )
        }
      }
    }
  }
}
