package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.R
import com.example.model.Product
import com.example.ui.components.ProductCard
import com.example.ui.theme.ApnaBluePrimary
import com.example.ui.theme.ApnaDiscountGreen
import com.example.ui.viewmodel.ApnaCartViewModel

@Composable
fun PhotoSearchScreen(
  viewModel: ApnaCartViewModel,
  onBack: () -> Unit,
  onProductClick: (Product) -> Unit,
  modifier: Modifier = Modifier
) {
  BackHandler { onBack() }

  var selectedImageUri by remember { mutableStateOf<Uri?>(null) }
  var visualCategory by remember { mutableStateOf("jeans") }
  var visualResults by remember { mutableStateOf<List<Product>>(emptyList()) }

  val photoPickerLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.PickVisualMedia()
  ) { uri ->
    if (uri != null) {
      selectedImageUri = uri
      visualCategory = "jeans"
      visualResults = viewModel.performPhotoSearch("jeans")
    }
  }

  Surface(
    color = MaterialTheme.colorScheme.background,
    modifier = modifier.fillMaxSize()
  ) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .statusBarsPadding()
    ) {
      // Header
      Surface(
        color = ApnaBluePrimary,
        tonalElevation = 4.dp,
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 12.dp)
        ) {
          IconButton(onClick = onBack) {
            Icon(
              imageVector = Icons.AutoMirrored.Filled.ArrowBack,
              contentDescription = "Back",
              tint = Color.White
            )
          }
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = "Visual Photo Search",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
          )
        }
      }

      if (selectedImageUri == null) {
        // Upload Prompt
        Column(
          modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
          horizontalAlignment = Alignment.CenterHorizontally,
          verticalArrangement = Arrangement.Center
        ) {
          Box(
            modifier = Modifier
              .size(110.dp)
              .clip(CircleShape)
              .background(Color(0xFFE3F2FD)),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = Icons.Default.CameraAlt,
              contentDescription = null,
              tint = ApnaBluePrimary,
              modifier = Modifier.size(54.dp)
            )
          }
          Spacer(modifier = Modifier.height(20.dp))
          Text(
            text = "Search by Photo or Style",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF202124)
          )
          Spacer(modifier = Modifier.height(8.dp))
          Text(
            text = "Pick an outfit, fabric, or fashion piece from your gallery. We will analyze color, pattern and category to find matching ApnaCart items.",
            fontSize = 13.sp,
            color = Color.Gray,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
          )
          Spacer(modifier = Modifier.height(32.dp))
          Button(
            onClick = {
              photoPickerLauncher.launch(
                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
              )
            },
            colors = ButtonDefaults.buttonColors(containerColor = ApnaBluePrimary),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
              .fillMaxWidth()
              .height(50.dp)
              .testTag("pick_photo_button")
          ) {
            Icon(imageVector = Icons.Default.PhotoLibrary, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Choose from Gallery / Photos", fontSize = 15.sp, fontWeight = FontWeight.Bold)
          }

          Spacer(modifier = Modifier.height(14.dp))

          // Quick sample search buttons for instant preview
          Text(
            text = "Or try with sample Indian styles:",
            fontSize = 12.sp,
            color = Color.Gray
          )
          Spacer(modifier = Modifier.height(10.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            OutlinedButton(
              onClick = {
                visualCategory = "jeans"
                visualResults = viewModel.performPhotoSearch("jeans")
                selectedImageUri = Uri.parse("android.resource://com.example/drawable/ic_launcher_background")
              },
              modifier = Modifier.weight(1f)
            ) {
              Text("Blue Denim", fontSize = 11.sp)
            }
            OutlinedButton(
              onClick = {
                visualCategory = "kurtis"
                visualResults = viewModel.performPhotoSearch("kurti")
                selectedImageUri = Uri.parse("android.resource://com.example/drawable/ic_launcher_background")
              },
              modifier = Modifier.weight(1f)
            ) {
              Text("Ethnic Kurti", fontSize = 11.sp)
            }
          }
        }
      } else {
        // Results View
        LazyVerticalGrid(
          columns = GridCells.Fixed(2),
          contentPadding = PaddingValues(16.dp),
          horizontalArrangement = Arrangement.spacedBy(10.dp),
          verticalArrangement = Arrangement.spacedBy(12.dp),
          modifier = Modifier.fillMaxSize()
        ) {
          // Photo Preview Banner
          item(span = { androidx.compose.foundation.lazy.grid.GridItemSpan(2) }) {
            Card(
              shape = RoundedCornerShape(12.dp),
              colors = CardDefaults.cardColors(containerColor = Color.White),
              elevation = CardDefaults.cardElevation(2.dp),
              modifier = Modifier.fillMaxWidth()
            ) {
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Box(
                  modifier = Modifier
                    .size(70.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFFF1F3F4)),
                  contentAlignment = Alignment.Center
                ) {
                  AsyncImage(
                    model = selectedImageUri,
                    contentDescription = "Selected Photo",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                  )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                      imageVector = Icons.Default.CheckCircle,
                      contentDescription = null,
                      tint = ApnaDiscountGreen,
                      modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                      text = "Visual Match: ${visualCategory.replaceFirstChar { it.uppercase() }}",
                      fontSize = 13.sp,
                      fontWeight = FontWeight.Bold
                    )
                  }
                  Text(
                    text = "Showing 92% visually similar in-stock items",
                    fontSize = 11.sp,
                    color = Color.Gray
                  )
                }
                IconButton(
                  onClick = {
                    photoPickerLauncher.launch(
                      PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                    )
                  }
                ) {
                  Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = "Retry",
                    tint = ApnaBluePrimary
                  )
                }
              }
            }
          }

          items(visualResults) { product ->
            ProductCard(
              product = product,
              isWishlisted = false,
              onProductClick = { onProductClick(product) },
              onWishlistToggle = { viewModel.toggleWishlist(product) }
            )
          }
        }
      }
    }
  }
}
