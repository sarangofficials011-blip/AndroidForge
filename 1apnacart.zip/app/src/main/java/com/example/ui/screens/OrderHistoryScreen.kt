package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ApnaStrings
import com.example.model.OrderStatus
import com.example.ui.theme.ApnaBlueContainer
import com.example.ui.theme.ApnaBlueDark
import com.example.ui.theme.ApnaBluePrimary
import com.example.ui.theme.ApnaDiscountGreen
import com.example.ui.theme.ApnaDiscountGreenBg
import com.example.ui.viewmodel.ApnaCartViewModel

@Composable
fun OrderHistoryScreen(
  viewModel: ApnaCartViewModel,
  onBack: () -> Unit,
  onTrackOrder: (String) -> Unit,
  modifier: Modifier = Modifier
) {
  BackHandler { onBack() }

  val orders by viewModel.orders.collectAsState()
  val currentLanguage by viewModel.currentLanguage.collectAsState()

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
  ) {
    Surface(
      color = ApnaBluePrimary,
      tonalElevation = 4.dp,
      modifier = Modifier.fillMaxWidth()
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .statusBarsPadding()
          .padding(horizontal = 8.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        IconButton(onClick = onBack, modifier = Modifier.testTag("orders_back_btn")) {
          Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
        }
        Text(text = ApnaStrings.get("my_orders", currentLanguage), fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Color.White)
      }
    }

    if (orders.isEmpty()) {
      Box(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        contentAlignment = Alignment.Center
      ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Text(text = "📦", fontSize = 56.sp)
          Spacer(modifier = Modifier.height(12.dp))
          Text(text = ApnaStrings.get("empty_orders", currentLanguage), fontSize = 17.sp, fontWeight = FontWeight.Bold)
          Spacer(modifier = Modifier.height(4.dp))
          Text(text = "Place a demo order from the cart to test order history!", fontSize = 12.sp, color = Color.Gray)
        }
      }
    } else {
      LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        items(orders, key = { it.orderId }) { order ->
          Card(
            shape = RoundedCornerShape(8.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier.fillMaxWidth().clickable { onTrackOrder(order.orderId) }.testTag("order_card_${order.orderId}")
          ) {
            Column(modifier = Modifier.padding(12.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Column {
                  Text(text = "Order #${order.orderId}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = ApnaBlueDark)
                  Text(text = "Placed on ${order.orderDate}", fontSize = 11.sp, color = Color.Gray)
                }

                Box(
                  modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(
                      when (order.currentStatus) {
                        OrderStatus.DEMO_COMPLETED -> ApnaDiscountGreenBg
                        OrderStatus.DEMO_CANCELLED -> Color(0xFFFFEBEE)
                        else -> ApnaBlueContainer
                      }
                    )
                    .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                  Text(
                    text = order.currentStatus.label,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = when (order.currentStatus) {
                      OrderStatus.DEMO_COMPLETED -> ApnaDiscountGreen
                      OrderStatus.DEMO_CANCELLED -> Color.Red
                      else -> ApnaBlueDark
                    }
                  )
                }
              }

              Spacer(modifier = Modifier.height(8.dp))
              HorizontalDivider(color = Color(0xFFEEEEEE))
              Spacer(modifier = Modifier.height(8.dp))

              order.items.forEach { item ->
                Text(
                  text = "• ${item.quantity}x ${item.product.title}",
                  fontSize = 12.sp,
                  color = Color.Black,
                  maxLines = 1,
                  modifier = Modifier.padding(vertical = 1.dp)
                )
              }

              Spacer(modifier = Modifier.height(8.dp))

              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Column {
                  Text(text = "Total Paid (Demo)", fontSize = 11.sp, color = Color.Gray)
                  Text(text = "₹${order.finalAmount}", fontSize = 15.sp, fontWeight = FontWeight.ExtraBold)
                }

                Button(
                  onClick = { onTrackOrder(order.orderId) },
                  colors = ButtonDefaults.buttonColors(containerColor = ApnaBluePrimary),
                  shape = RoundedCornerShape(6.dp),
                  modifier = Modifier.height(34.dp)
                ) {
                  Icon(imageVector = Icons.Default.LocalShipping, contentDescription = null, modifier = Modifier.size(14.dp))
                  Spacer(modifier = Modifier.width(4.dp))
                  Text(text = "Track Package", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
              }
            }
          }
        }
      }
    }
  }
}
