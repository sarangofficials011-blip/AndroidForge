package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.PinDrop
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.OrderStatus
import com.example.model.TrackingStage
import com.example.ui.theme.ApnaBlueContainer
import com.example.ui.theme.ApnaBlueDark
import com.example.ui.theme.ApnaBluePrimary
import com.example.ui.theme.ApnaDiscountGreen
import com.example.ui.theme.ApnaDiscountGreenBg
import com.example.ui.viewmodel.ApnaCartViewModel

@Composable
fun OrderTrackingScreen(
  orderId: String,
  viewModel: ApnaCartViewModel,
  onBack: () -> Unit,
  modifier: Modifier = Modifier
) {
  BackHandler { onBack() }

  val orders by viewModel.orders.collectAsState()
  val order = orders.find { it.orderId == orderId }

  if (order == null) {
    Box(
      modifier = modifier.fillMaxSize().background(MaterialTheme.colorScheme.background),
      contentAlignment = Alignment.Center
    ) {
      Text("Order not found")
    }
    return
  }

  Box(
    modifier = modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)
  ) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .verticalScroll(rememberScrollState())
        .padding(bottom = 84.dp)
    ) {
      // Top Bar
      Surface(
        color = ApnaBluePrimary,
        tonalElevation = 4.dp,
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(horizontal = 8.dp, vertical = 6.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          IconButton(onClick = onBack, modifier = Modifier.testTag("tracking_back_btn")) {
            Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
          }
          Column {
            Text(text = "Simulated Order Tracking", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Text(text = "Order #${order.orderId}", fontSize = 11.sp, color = Color.White.copy(alpha = 0.85f))
          }
        }
      }

      // Mandatory courier disclaimer
      Card(
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF8E1)),
        border = CardDefaults.outlinedCardBorder().copy(width = 0.5.dp, brush = androidx.compose.ui.graphics.SolidColor(Color(0xFFFFB300))),
        modifier = Modifier.fillMaxWidth().padding(12.dp)
      ) {
        Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.Top) {
          Icon(imageVector = Icons.Default.Info, contentDescription = null, tint = Color(0xFFE65100), modifier = Modifier.size(18.dp))
          Spacer(modifier = Modifier.width(8.dp))
          Column {
            Text(text = "SIMULATED DEMO TRACKING", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFFBF360C))
            Text(
              text = "This tracking timeline is a local demonstration. It does not contact any courier company and no physical shipment is in transit.",
              fontSize = 11.sp,
              color = Color(0xFF5D4037),
              lineHeight = 15.sp
            )
          }
        }
      }

      // Order Info & Status Card
      Card(
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp)
      ) {
        Column(modifier = Modifier.padding(12.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(imageVector = Icons.Default.LocalShipping, contentDescription = null, tint = ApnaBluePrimary, modifier = Modifier.size(20.dp))
              Spacer(modifier = Modifier.width(8.dp))
              Column {
                Text(text = order.courierPartner, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Text(text = "AWB: ${order.awbNumber}", fontSize = 11.sp, color = Color.Gray)
              }
            }

            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(4.dp))
                .background(
                  if (order.currentStatus == OrderStatus.DEMO_COMPLETED) ApnaDiscountGreenBg else ApnaBlueContainer
                )
                .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
              Text(
                text = order.currentStatus.label,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = if (order.currentStatus == OrderStatus.DEMO_COMPLETED) ApnaDiscountGreen else ApnaBlueDark
              )
            }
          }

          Spacer(modifier = Modifier.height(8.dp))
          HorizontalDivider(color = Color(0xFFEEEEEE))
          Spacer(modifier = Modifier.height(8.dp))

          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column {
              Text(text = "Estimated Delivery", fontSize = 11.sp, color = Color.Gray)
              Text(text = order.estimatedDeliveryDate, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = ApnaDiscountGreen)
            }

            Column(horizontalAlignment = Alignment.End) {
              Text(text = "Delivery Destination", fontSize = 11.sp, color = Color.Gray)
              Text(text = "${order.deliveryAddress.city} - ${order.deliveryAddress.pincode}", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Timeline Stepper
      Card(
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp)
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Text(text = "Shipment Milestones (Demo)", fontSize = 14.sp, fontWeight = FontWeight.Bold)
          Spacer(modifier = Modifier.height(12.dp))

          order.trackingStages.forEachIndexed { index, stage ->
            val isLast = index == order.trackingStages.lastIndex
            TrackingStepItem(stage = stage, isLast = isLast)
          }
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Products in Order
      Card(
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp)
      ) {
        Column(modifier = Modifier.padding(12.dp)) {
          Text(text = "Items in this Order (${order.items.size})", fontSize = 13.sp, fontWeight = FontWeight.Bold)
          Spacer(modifier = Modifier.height(6.dp))

          order.items.forEach { item ->
            Row(modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = Arrangement.SpaceBetween) {
              Text(text = "${item.quantity}x ${item.product.title}", fontSize = 12.sp, modifier = Modifier.weight(1f), maxLines = 1)
              Text(text = "₹${item.itemTotalPrice}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = ApnaBlueDark)
            }
          }
        }
      }
    }

    // Sticky Bottom Action Bar
    Surface(
      color = Color.White,
      tonalElevation = 6.dp,
      shadowElevation = 8.dp,
      modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth()
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .navigationBarsPadding()
          .padding(horizontal = 14.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        if (order.currentStatus != OrderStatus.DEMO_COMPLETED && order.currentStatus != OrderStatus.DEMO_CANCELLED) {
          Button(
            onClick = { viewModel.simulateAdvanceTracking(order.orderId) },
            colors = ButtonDefaults.buttonColors(containerColor = ApnaBluePrimary),
            shape = RoundedCornerShape(6.dp),
            modifier = Modifier.weight(1f).height(44.dp).testTag("simulate_next_stage_btn")
          ) {
            Icon(imageVector = Icons.Default.RocketLaunch, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(text = "Advance Tracking Stage", fontSize = 12.sp, fontWeight = FontWeight.Bold)
          }

          OutlinedButton(
            onClick = { viewModel.cancelOrder(order.orderId) },
            shape = RoundedCornerShape(6.dp),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.Red),
            modifier = Modifier.height(44.dp)
          ) {
            Text("Cancel", fontSize = 12.sp)
          }
        } else {
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(6.dp))
              .background(if (order.currentStatus == OrderStatus.DEMO_COMPLETED) ApnaDiscountGreenBg else Color(0xFFFFEBEE))
              .padding(10.dp),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = if (order.currentStatus == OrderStatus.DEMO_COMPLETED) {
                "✓ Demo Order Completed (Simulation Finished)"
              } else {
                "✗ Demo Order Cancelled"
              },
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold,
              color = if (order.currentStatus == OrderStatus.DEMO_COMPLETED) ApnaDiscountGreen else Color.Red
            )
          }
        }
      }
    }
  }
}

@Composable
private fun TrackingStepItem(stage: TrackingStage, isLast: Boolean) {
  Row(modifier = Modifier.fillMaxWidth()) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
      Box(
        modifier = Modifier
          .size(22.dp)
          .clip(CircleShape)
          .background(
            when {
              stage.isCompleted -> ApnaDiscountGreen
              stage.isCurrent -> ApnaBluePrimary
              else -> Color.LightGray
            }
          ),
        contentAlignment = Alignment.Center
      ) {
        if (stage.isCompleted) {
          Icon(imageVector = Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(12.dp))
        } else if (stage.isCurrent) {
          Box(modifier = Modifier.size(6.dp).clip(CircleShape).background(Color.White))
        }
      }

      if (!isLast) {
        Box(
          modifier = Modifier
            .width(2.dp)
            .height(34.dp)
            .background(if (stage.isCompleted) ApnaDiscountGreen else Color(0xFFE0E0E0))
        )
      }
    }

    Spacer(modifier = Modifier.width(10.dp))

    Column(modifier = Modifier.padding(bottom = if (isLast) 0.dp else 12.dp)) {
      Text(
        text = stage.title,
        fontSize = 12.sp,
        fontWeight = if (stage.isCurrent || stage.isCompleted) FontWeight.Bold else FontWeight.Medium,
        color = if (stage.isCurrent) ApnaBluePrimary else Color.Black
      )
      Text(text = stage.subtitle, fontSize = 11.sp, color = Color.Gray)
      Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 2.dp)) {
        Icon(imageVector = Icons.Default.PinDrop, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(11.dp))
        Spacer(modifier = Modifier.width(3.dp))
        Text(text = "${stage.location} • ${stage.timestamp}", fontSize = 10.sp, color = Color.Gray)
      }
    }
  }
}
