package com.example.model

data class Product(
  val id: String,
  val title: String,
  val brand: String,
  val category: String, // "mens_clothing", "womens_clothing", "jeans", "kurtis", "sarees", "accessories"
  val price: Int, // INR
  val originalMrp: Int, // INR
  val rating: Float = 4.5f,
  val reviewCount: Int = 120,
  val drawableRes: Int? = null,
  val description: String,
  val highlights: List<String> = emptyList(),
  val availableSizes: List<String> = emptyList(),
  val availableColors: List<String> = emptyList(),
  val stockQuantity: Int = 12, // Demo stock
  val isBestseller: Boolean = false,
  val isUnder499: Boolean = false,
  val deliveryEstimate: String = "2-3 Days"
) {
  val inStock: Boolean
    get() = stockQuantity > 0

  val discountPercent: Int
    get() = if (originalMrp > price) (((originalMrp - price).toFloat() / originalMrp) * 100).toInt() else 0

  val savingsAmount: Int
    get() = (originalMrp - price).coerceAtLeast(0)
}

data class CartItem(
  val cartItemId: String,
  val product: Product,
  val selectedSize: String,
  val selectedColor: String,
  val quantity: Int
) {
  val itemTotalPrice: Int
    get() = product.price * quantity

  val itemTotalMrp: Int
    get() = product.originalMrp * quantity
}

data class CategoryItem(
  val id: String,
  val nameKey: String, // String key matching ApnaStrings
  val iconEmoji: String,
  val badge: String? = null
)

data class Address(
  val id: String,
  val fullName: String,
  val phone: String,
  val houseNoBuilding: String,
  val roadAreaColony: String,
  val pincode: String,
  val city: String,
  val state: String,
  val addressType: String = "Home",
  val isDefault: Boolean = false
) {
  val formattedFullAddress: String
    get() = "$houseNoBuilding, $roadAreaColony, $city, $state - $pincode"
}

data class UserProfile(
  val fullName: String = "Priya Sharma",
  val phone: String = "9876543210",
  val email: String = "priya.sharma@example.com",
  val isDemoAccount: Boolean = true
)

data class OfferCoupon(
  val code: String,
  val title: String,
  val description: String,
  val discountType: String, // "FLAT", "PERCENT", "FREESHIP"
  val discountValue: Int,
  val minCartValue: Int,
  val expiryDate: String = "30 Nov 2026"
)

enum class OrderStatus(val label: String, val hindiLabel: String) {
  DEMO_PLACED("Demo Order Placed", "डेमो ऑर्डर दर्ज"),
  DEMO_PROCESSING("Demo Processing", "डेमो प्रोसेसिंग"),
  DEMO_SHIPPED("Demo Shipped", "डेमो भेजा गया"),
  DEMO_OUT_FOR_DELIVERY("Demo Out for Delivery", "डिलीवरी के लिए निकला"),
  DEMO_COMPLETED("Demo Completed", "डेमो पूर्ण हुआ"),
  DEMO_CANCELLED("Demo Cancelled", "डेमो रद्द किया गया")
}

data class TrackingStage(
  val status: OrderStatus,
  val title: String,
  val subtitle: String,
  val timestamp: String,
  val location: String,
  val isCompleted: Boolean,
  val isCurrent: Boolean
)

data class Order(
  val orderId: String,
  val orderDate: String,
  val items: List<CartItem>,
  val subtotalMrp: Int,
  val productDiscount: Int,
  val couponDiscount: Int,
  val deliveryFee: Int,
  val finalAmount: Int,
  val paymentMethod: String,
  val deliveryAddress: Address,
  val currentStatus: OrderStatus,
  val trackingStages: List<TrackingStage>,
  val estimatedDeliveryDate: String,
  val courierPartner: String = "Simulated Express (Delhivery/BlueDart Demo)",
  val awbNumber: String = "APNA${(10000000..99999999).random()}",
  val customerId: String = "CUST_9876543210"
) {
  val id: String get() = orderId
  val totalAmount: Int get() = finalAmount
  val createdAt: Long get() = System.currentTimeMillis()
}

data class AuthUser(
  val customerId: String,
  val phone: String,
  val fullName: String,
  val email: String,
  val role: String = "CUSTOMER", // "CUSTOMER" or "ADMIN"
  val isVerified: Boolean = true
)

data class AppNotification(
  val id: String,
  val title: String,
  val message: String,
  val timestamp: String,
  val type: String = "ORDER", // "ORDER", "OFFER", "STOCK"
  val isRead: Boolean = false
)

data class AdminDashboardStats(
  val totalProducts: Int,
  val totalOrders: Int,
  val totalRevenue: Int,
  val lowStockCount: Int,
  val cancelledOrdersCount: Int
)

data class AdminStatus(
  val isAuthorizedOwner: Boolean = false,
  val isConfiguredInBackend: Boolean = false,
  val uid: String? = null,
  val email: String? = null,
  val role: String? = null,
  val statusMessage: String = "Admin access requires authorized owner verification."
)

data class StoreSettings(
  val upiEnabled: Boolean = true,
  val codEnabled: Boolean = true,
  val cardsEnabled: Boolean = true,
  val courierPartner: String = "Delhivery Surface",
  val standardShippingFee: Int = 50,
  val freeShippingThreshold: Int = 499,
  val rewardPointsPerHundred: Int = 1, // 1 point per ₹100
  val referralRewardAmount: Int = 100 // ₹100 credit on referral
)

data class PriceAlert(
  val productId: String,
  val savedPrice: Int,
  val targetPrice: Int = savedPrice,
  val createdDate: String = "2026-10-30",
  val isEnabled: Boolean = true
)

data class WalletTransaction(
  val id: String,
  val type: String, // "CREDIT", "DEBIT", "REFUND", "GIFT_CARD"
  val amount: Int,
  val title: String,
  val description: String,
  val timestamp: String,
  val orderId: String? = null
)

data class RewardTransaction(
  val id: String,
  val type: String, // "EARNED", "REDEEMED", "REVERSED"
  val points: Int,
  val title: String,
  val timestamp: String,
  val orderId: String? = null
)

data class GiftCard(
  val code: String,
  val initialAmount: Int,
  val remainingBalance: Int = initialAmount,
  val expiryDate: String = "31 Dec 2026",
  val isRedeemed: Boolean = false,
  val redeemedByUid: String? = null,
  val createdAt: String = "2026-10-30"
) {
  val amount: Int get() = initialAmount
}

data class ProductQuestion(
  val id: String,
  val productId: String,
  val questionText: String,
  val askedBy: String,
  val askedDate: String,
  val answerText: String? = null,
  val answeredBy: String? = null,
  val answeredDate: String? = null,
  val isApproved: Boolean = true
) {
  val question: String get() = questionText
  val customerName: String get() = askedBy
  val answer: String? get() = answerText
}

enum class MembershipTier(
  val label: String,
  val badgeColorHex: Long,
  val minSpend: Int,
  val discountPercent: Int,
  val perk: String
) {
  SILVER("Silver Club", 0xFF9E9E9E, 0, 0, "Standard Member • 1x Rewards"),
  GOLD("Gold VIP", 0xFFFFB300, 2000, 5, "5% Extra Discount • Free Delivery"),
  PLATINUM("Platinum Elite", 0xFF6200EE, 5000, 10, "10% Extra Discount • Priority Courier")
}

data class CustomerMembership(
  val tier: MembershipTier = MembershipTier.SILVER,
  val totalSpend: Int = 0,
  val validUntil: String = "31 Dec 2026",
  val nextTierProgress: Float = 0.45f
)

data class ReferralEntry(
  val refereeName: String,
  val date: String,
  val rewardAmount: Int,
  val status: String // "PENDING", "QUALIFIED"
)

data class ReferralData(
  val referralCode: String = "APNA100",
  val totalInvited: Int = 3,
  val earnedCredits: Int = 300,
  val history: List<ReferralEntry> = emptyList()
)

data class FraudAlert(
  val id: String,
  val orderId: String,
  val customerUid: String,
  val reason: String,
  val riskLevel: String, // "LOW", "MEDIUM", "HIGH"
  val timestamp: String,
  val isReviewed: Boolean = false
) {
  val type: String get() = "Velocity Risk ($riskLevel)"
  val description: String get() = reason
  val resolved: Boolean get() = isReviewed
}

data class AiChatMessage(
  val id: String,
  val isUser: Boolean,
  val message: String,
  val timestamp: String,
  val matchedProducts: List<Product> = emptyList(),
  val quickReplies: List<String> = emptyList()
)

data class SizeChartRow(
  val size: String,
  val chestInch: Int,
  val waistInch: Int,
  val lengthInch: Int,
  val heightCm: String
)

data class SizeRecommendation(
  val recommendedSize: String,
  val explanation: String,
  val chartRows: List<SizeChartRow> = emptyList()
)
