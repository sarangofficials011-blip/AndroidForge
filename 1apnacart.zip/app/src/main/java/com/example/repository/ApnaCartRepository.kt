package com.example.repository

import android.content.Context
import android.util.Log
import com.example.R
import com.example.data.DemoDataProvider
import com.example.data.OperationType
import com.example.data.handleFirestoreError
import com.example.model.*
import com.google.firebase.auth.AuthCredential
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

class ApnaCartRepository(
  private val db: FirebaseFirestore?,
  private val context: Context?
) {

  private val coroutineScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
  private val auth: FirebaseAuth? = try {
    FirebaseAuth.getInstance()
  } catch (e: Exception) {
    null
  }
  private val prefs = context?.getSharedPreferences("apnacart_demo_storage", Context.MODE_PRIVATE)

  // Secondary constructor resolving database ID from string resource
  constructor(context: Context?) : this(
    try {
      FirebaseFirestore.getInstance(
        context?.getString(R.string.firestore_database_id)
          ?: "ai-studio-android-remixapn-0e062485-546c-433c-a441-c84298dec7d5"
      )
    } catch (e: Exception) {
      null
    },
    context
  )

  // Fallback constructor
  constructor() : this(null, null)

  // Firebase Auth Current User Flow
  private val _firebaseUser = MutableStateFlow<FirebaseUser?>(auth?.currentUser)
  val firebaseUser: StateFlow<FirebaseUser?> = _firebaseUser.asStateFlow()

  // Server-Verified Admin Status
  private val _adminStatus = MutableStateFlow(AdminStatus())
  val adminStatus: StateFlow<AdminStatus> = _adminStatus.asStateFlow()

  // Language State
  private val _currentLanguage = MutableStateFlow(
    if (prefs?.getString("pref_language", "en") == "hi") AppLanguage.HINDI else AppLanguage.ENGLISH
  )
  val currentLanguage: StateFlow<AppLanguage> = _currentLanguage.asStateFlow()

  // Customer Profile
  private val _userProfile = MutableStateFlow(
    UserProfile(
      fullName = prefs?.getString("user_name", "Priya Sharma") ?: "Priya Sharma",
      phone = prefs?.getString("user_phone", "9876543210") ?: "9876543210",
      email = prefs?.getString("user_email", "priya.sharma@example.com") ?: "priya.sharma@example.com"
    )
  )
  val userProfile: StateFlow<UserProfile> = _userProfile.asStateFlow()

  // Products Catalog (Live synced with Firestore)
  private val _products = MutableStateFlow<List<Product>>(DemoDataProvider.initialProducts)
  val products: StateFlow<List<Product>> = _products.asStateFlow()

  // Wishlist
  private val _wishlistIds = MutableStateFlow<Set<String>>(setOf("p_jeans_1", "p_kurti_1", "p_saree_1"))
  val wishlistIds: StateFlow<Set<String>> = _wishlistIds.asStateFlow()

  // Cart
  private val _cartItems = MutableStateFlow<List<CartItem>>(
    listOf(
      CartItem(
        cartItemId = "cart_init_1",
        product = DemoDataProvider.initialProducts.first { it.id == "p_jeans_1" },
        selectedSize = "32",
        selectedColor = "Dark Indigo",
        quantity = 1
      ),
      CartItem(
        cartItemId = "cart_init_2",
        product = DemoDataProvider.initialProducts.first { it.id == "p_kurti_1" },
        selectedSize = "M (38)",
        selectedColor = "Sky Blue",
        quantity = 1
      )
    )
  )
  val cartItems: StateFlow<List<CartItem>> = _cartItems.asStateFlow()

  // Addresses
  private val _addresses = MutableStateFlow(DemoDataProvider.initialAddresses)
  val addresses: StateFlow<List<Address>> = _addresses.asStateFlow()

  private val _selectedAddress = MutableStateFlow(DemoDataProvider.initialAddresses[0])
  val selectedAddress: StateFlow<Address> = _selectedAddress.asStateFlow()

  // Orders
  private val _orders = MutableStateFlow<List<Order>>(DemoDataProvider.createInitialOrders())
  val orders: StateFlow<List<Order>> = _orders.asStateFlow()

  // Coupons
  private val _availableCoupons = MutableStateFlow(DemoDataProvider.sampleCoupons)
  val availableCoupons: StateFlow<List<OfferCoupon>> = _availableCoupons.asStateFlow()

  private val _appliedCoupon = MutableStateFlow<OfferCoupon?>(null)
  val appliedCoupon: StateFlow<OfferCoupon?> = _appliedCoupon.asStateFlow()

  // Delivery Pincode
  private val _deliveryPincode = MutableStateFlow(prefs?.getString("pref_pincode", "400050") ?: "400050")
  val deliveryPincode: StateFlow<String> = _deliveryPincode.asStateFlow()

  // Customer Account Session
  private val _authUser = MutableStateFlow<AuthUser?>(
    if (prefs?.getBoolean("auth_logged_in", true) == true) {
      AuthUser(
        customerId = prefs.getString("auth_cust_id", "CUST_9876543210") ?: "CUST_9876543210",
        phone = prefs.getString("user_phone", "9876543210") ?: "9876543210",
        fullName = prefs.getString("user_name", "Priya Sharma") ?: "Priya Sharma",
        email = prefs.getString("user_email", "priya.sharma@example.com") ?: "priya.sharma@example.com",
        role = "CUSTOMER",
        isVerified = true
      )
    } else null
  )
  val authUser: StateFlow<AuthUser?> = _authUser.asStateFlow()

  // Store Integrations & Settings
  private val _storeSettings = MutableStateFlow(StoreSettings())
  val storeSettings: StateFlow<StoreSettings> = _storeSettings.asStateFlow()

  // Recently Viewed Product IDs
  private val _recentlyViewedIds = MutableStateFlow<List<String>>(listOf("p_jeans_1", "p_kurti_1"))
  val recentlyViewedIds: StateFlow<List<String>> = _recentlyViewedIds.asStateFlow()

  // Notifications
  private val _notifications = MutableStateFlow<List<AppNotification>>(
    listOf(
      AppNotification(
        id = "notif_1",
        title = "Diwali Mega Sale Live! 🪔",
        message = "Get flat ₹200 off on your order with code FESTIVE200. Authentic ethnic wear deals.",
        timestamp = "Today, 10:00 AM",
        type = "OFFER"
      ),
      AppNotification(
        id = "notif_2",
        title = "Simulated Delivery Tracking",
        message = "Your demo order APNA10001 is out for delivery. Test tracking in Order History.",
        timestamp = "Yesterday",
        type = "ORDER"
      )
    )
  )
  val notifications: StateFlow<List<AppNotification>> = _notifications.asStateFlow()

  // 1. ApnaCart Wallet
  private val _walletBalance = MutableStateFlow(250) // ₹250 promotional welcome credit
  val walletBalance: StateFlow<Int> = _walletBalance.asStateFlow()

  private val _walletTransactions = MutableStateFlow<List<WalletTransaction>>(
    listOf(
      WalletTransaction(
        id = "wtx_init",
        type = "CREDIT",
        amount = 250,
        title = "Welcome Credit",
        description = "Promotional welcome balance added to your ApnaCart Wallet",
        timestamp = "Registration"
      )
    )
  )
  val walletTransactions: StateFlow<List<WalletTransaction>> = _walletTransactions.asStateFlow()

  // 2. Rewards (SuperCoins)
  private val _rewardPoints = MutableStateFlow(120)
  val rewardPoints: StateFlow<Int> = _rewardPoints.asStateFlow()

  private val _rewardTransactions = MutableStateFlow<List<RewardTransaction>>(
    listOf(
      RewardTransaction(
        id = "rtx_init",
        type = "EARNED",
        points = 120,
        title = "Onboarding Bonus",
        timestamp = "Yesterday"
      )
    )
  )
  val rewardTransactions: StateFlow<List<RewardTransaction>> = _rewardTransactions.asStateFlow()

  // 3. Price Drop Alerts (Map of productId -> PriceAlert)
  private val _priceAlerts = MutableStateFlow<Map<String, PriceAlert>>(
    mapOf(
      "p_jeans_1" to PriceAlert(
        productId = "p_jeans_1",
        savedPrice = 899,
        targetPrice = 799,
        createdDate = "28 Oct 2026",
        isEnabled = true
      )
    )
  )
  val priceAlerts: StateFlow<Map<String, PriceAlert>> = _priceAlerts.asStateFlow()

  // 4. Gift Cards Ledger
  private val _giftCards = MutableStateFlow<List<GiftCard>>(
    listOf(
      GiftCard(
        code = "FESTIVE500",
        initialAmount = 500,
        remainingBalance = 500,
        expiryDate = "31 Dec 2026",
        isRedeemed = false
      ),
      GiftCard(
        code = "APNA1000",
        initialAmount = 1000,
        remainingBalance = 1000,
        expiryDate = "31 Mar 2027",
        isRedeemed = false
      )
    )
  )
  val giftCards: StateFlow<List<GiftCard>> = _giftCards.asStateFlow()

  // 5. Product Q&A
  private val _productQuestions = MutableStateFlow<List<ProductQuestion>>(
    listOf(
      ProductQuestion(
        id = "qa_1",
        productId = "p_jeans_1",
        questionText = "Is this 100% denim cotton or stretchable blend?",
        askedBy = "Amit K.",
        askedDate = "26 Oct 2026",
        answerText = "It is 98% cotton and 2% elastane, giving comfortable mild stretch for daily all-day wear.",
        answeredBy = "ApnaCart Verified Seller",
        answeredDate = "27 Oct 2026",
        isApproved = true
      ),
      ProductQuestion(
        id = "qa_2",
        productId = "p_kurti_1",
        questionText = "Does color bleed after first hand wash?",
        askedBy = "Sneha R.",
        askedDate = "27 Oct 2026",
        answerText = "No bleeding, color is fast dyed. Recommended to wash separately in gentle cold water.",
        answeredBy = "ApnaCart Verified Seller",
        answeredDate = "28 Oct 2026",
        isApproved = true
      )
    )
  )
  val productQuestions: StateFlow<List<ProductQuestion>> = _productQuestions.asStateFlow()

  // 6. Loyalty Membership (ApnaClub)
  private val _membership = MutableStateFlow(
    CustomerMembership(
      tier = MembershipTier.SILVER,
      totalSpend = 1298,
      validUntil = "31 Dec 2026",
      nextTierProgress = 0.65f
    )
  )
  val membership: StateFlow<CustomerMembership> = _membership.asStateFlow()

  // 7. Referral Program
  private val _referralData = MutableStateFlow(
    ReferralData(
      referralCode = "APNA100",
      totalInvited = 2,
      earnedCredits = 200,
      history = listOf(
        ReferralEntry("Rajesh Verma", "22 Oct 2026", 100, "QUALIFIED"),
        ReferralEntry("Kiran Desai", "26 Oct 2026", 100, "QUALIFIED")
      )
    )
  )
  val referralData: StateFlow<ReferralData> = _referralData.asStateFlow()

  // 8. Fraud Alerts
  private val _fraudAlerts = MutableStateFlow<List<FraudAlert>>(emptyList())
  val fraudAlerts: StateFlow<List<FraudAlert>> = _fraudAlerts.asStateFlow()

  // 9. AI Shopping Assistant Messages
  private val _aiChatMessages = MutableStateFlow<List<AiChatMessage>>(
    listOf(
      AiChatMessage(
        id = "ai_msg_init",
        isUser = false,
        message = "Namaste! I am your ApnaCart AI Shopping Assistant. Ask me anything in English or Hindi — for example: 'Show me jeans under ₹700', 'कुर्ती दिखाओ', or check size/delivery help!",
        timestamp = "Just now",
        quickReplies = listOf("Jeans under ₹800", "Ethnic Kurtis", "What is Return Policy?", "Size Chart Help")
      )
    )
  )
  val aiChatMessages: StateFlow<List<AiChatMessage>> = _aiChatMessages.asStateFlow()

  private var adminListener: ListenerRegistration? = null
  private var productsListener: ListenerRegistration? = null
  private var ordersListener: ListenerRegistration? = null
  private var settingsListener: ListenerRegistration? = null

  init {
    // 1. Observe Firebase Auth state
    auth?.addAuthStateListener { firebaseAuth ->
      val user = firebaseAuth.currentUser
      _firebaseUser.value = user
      if (user != null) {
        _authUser.value = AuthUser(
          customerId = user.uid,
          phone = user.phoneNumber ?: _userProfile.value.phone,
          fullName = user.displayName ?: _userProfile.value.fullName,
          email = user.email ?: _userProfile.value.email,
          role = "CUSTOMER",
          isVerified = user.isEmailVerified
        )
        _userProfile.update {
          it.copy(
            fullName = user.displayName ?: it.fullName,
            email = user.email ?: it.email
          )
        }
        verifyServerSideAdminRole(user)
        listenToOrders(user.uid, isAdmin = false)
      } else {
        adminListener?.remove()
        ordersListener?.remove()
        _adminStatus.value = AdminStatus(
          isAuthorizedOwner = false,
          isConfiguredInBackend = false,
          statusMessage = "Admin access requires authorized owner verification."
        )
      }
    }

    // 2. Attach live Firestore listener to published products & settings if db present
    if (db != null) {
      listenToProducts()
      listenToStoreSettings()
    }
  }

  private fun listenToProducts() {
    val database = db ?: return
    productsListener?.remove()
    productsListener = database.collection("products").addSnapshotListener { snapshot, error ->
      if (error != null) {
        handleFirestoreError(error, OperationType.LIST, "products")
        return@addSnapshotListener
      }
      if (snapshot != null && !snapshot.isEmpty) {
        val firestoreList = snapshot.documents.mapNotNull { doc ->
          try {
            Product(
              id = doc.id,
              title = doc.getString("title") ?: "",
              brand = doc.getString("brand") ?: "",
              category = doc.getString("category") ?: "clothing",
              price = (doc.getLong("price") ?: 0L).toInt(),
              originalMrp = (doc.getLong("originalMrp") ?: (doc.getLong("price") ?: 0L)).toInt(),
              rating = (doc.getDouble("rating") ?: 4.5).toFloat(),
              reviewCount = (doc.getLong("reviewCount") ?: 12L).toInt(),
              description = doc.getString("description") ?: "",
              highlights = (doc.get("highlights") as? List<*>)?.mapNotNull { it?.toString() } ?: emptyList(),
              availableSizes = (doc.get("availableSizes") as? List<*>)?.mapNotNull { it?.toString() } ?: listOf("S", "M", "L", "XL"),
              availableColors = (doc.get("availableColors") as? List<*>)?.mapNotNull { it?.toString() } ?: listOf("Default"),
              stockQuantity = (doc.getLong("stockQuantity") ?: 10L).toInt(),
              isBestseller = doc.getBoolean("isBestseller") ?: false,
              isUnder499 = ((doc.getLong("price") ?: 0L) <= 499L)
            )
          } catch (e: Exception) {
            null
          }
        }
        if (firestoreList.isNotEmpty()) {
          _products.value = firestoreList
        }
      }
    }
  }

  private fun listenToStoreSettings() {
    val database = db ?: return
    settingsListener?.remove()
    settingsListener = database.collection("settings").document("integrations").addSnapshotListener { snapshot, error ->
      if (error != null) {
        // Not fatal, settings are admin-only
        return@addSnapshotListener
      }
      if (snapshot != null && snapshot.exists()) {
        val s = StoreSettings(
          upiEnabled = snapshot.getBoolean("upiEnabled") ?: true,
          codEnabled = snapshot.getBoolean("codEnabled") ?: true,
          cardsEnabled = snapshot.getBoolean("cardsEnabled") ?: true,
          courierPartner = snapshot.getString("courierPartner") ?: "Delhivery Surface",
          standardShippingFee = (snapshot.getLong("standardShippingFee") ?: 50L).toInt(),
          freeShippingThreshold = (snapshot.getLong("freeShippingThreshold") ?: 499L).toInt()
        )
        _storeSettings.value = s
      }
    }
  }

  private fun verifyServerSideAdminRole(user: FirebaseUser) {
    val database = db ?: return
    adminListener?.remove()
    adminListener = database.collection("admins").document(user.uid).addSnapshotListener { snapshot, error ->
      if (error != null) {
        handleFirestoreError(error, OperationType.GET, "admins/${user.uid}")
        _adminStatus.value = AdminStatus(
          isAuthorizedOwner = false,
          isConfiguredInBackend = false,
          uid = user.uid,
          email = user.email,
          statusMessage = "Admin access denied: ${error.localizedMessage}"
        )
        return@addSnapshotListener
      }

      val role = snapshot?.getString("role")
      if (snapshot != null && snapshot.exists() && (role == "owner" || role == "admin")) {
        _adminStatus.value = AdminStatus(
          isAuthorizedOwner = true,
          isConfiguredInBackend = true,
          uid = user.uid,
          email = user.email,
          role = role,
          statusMessage = "Authorized Owner Verified ($role)"
        )
        // If owner, observe all customer orders
        listenToOrders(user.uid, isAdmin = true)
      } else {
        _adminStatus.value = AdminStatus(
          isAuthorizedOwner = false,
          isConfiguredInBackend = false,
          uid = user.uid,
          email = user.email,
          role = null,
          statusMessage = "Owner account '${user.email}' (UID: ${user.uid}) is not configured as owner in Cloud Firestore /admins collection."
        )
      }
    }
  }

  private fun listenToOrders(userId: String, isAdmin: Boolean) {
    val database = db ?: return
    ordersListener?.remove()
    val query = if (isAdmin) {
      database.collection("orders")
    } else {
      database.collection("orders").whereEqualTo("customerId", userId)
    }

    ordersListener = query.addSnapshotListener { snapshot, error ->
      if (error != null) {
        handleFirestoreError(error, OperationType.LIST, "orders")
        return@addSnapshotListener
      }
      if (snapshot != null && !snapshot.isEmpty) {
        val loadedOrders = snapshot.documents.mapNotNull { doc ->
          try {
            val statusStr = doc.getString("currentStatus") ?: OrderStatus.DEMO_PLACED.name
            val orderStatus = try {
              OrderStatus.valueOf(statusStr)
            } catch (e: Exception) {
              OrderStatus.DEMO_PLACED
            }
            val dateStr = doc.getString("orderDate") ?: "Recently"

            Order(
              orderId = doc.id,
              orderDate = dateStr,
              items = _cartItems.value.take(2).ifEmpty {
                listOf(
                  CartItem(
                    cartItemId = "c_${doc.id}",
                    product = _products.value.firstOrNull() ?: DemoDataProvider.initialProducts[0],
                    selectedSize = "M",
                    selectedColor = "Default",
                    quantity = 1
                  )
                )
              },
              subtotalMrp = (doc.getLong("totalAmount") ?: 1299L).toInt(),
              productDiscount = (doc.getLong("discountAmount") ?: 200L).toInt(),
              couponDiscount = 0,
              deliveryFee = 0,
              finalAmount = (doc.getLong("finalAmount") ?: 1099L).toInt(),
              paymentMethod = doc.getString("paymentMethod") ?: "UPI / Online",
              deliveryAddress = _selectedAddress.value,
              currentStatus = orderStatus,
              trackingStages = createInitialTrackingStages(dateStr),
              estimatedDeliveryDate = "Within 2-3 Days",
              courierPartner = doc.getString("courierPartner") ?: "Delhivery Surface",
              awbNumber = doc.getString("awbNumber") ?: "APNA${(10000000..99999999).random()}",
              customerId = doc.getString("customerId") ?: userId
            )
          } catch (e: Exception) {
            null
          }
        }
        if (loadedOrders.isNotEmpty()) {
          _orders.value = loadedOrders
        }
      }
    }
  }

  suspend fun signInWithCredential(credential: AuthCredential): Result<FirebaseUser> {
    return try {
      val authClient = auth ?: error("Firebase Auth not initialized")
      val authResult = authClient.signInWithCredential(credential).await()
      val user = authResult.user ?: error("No user returned from Firebase Auth")
      _firebaseUser.value = user
      Result.success(user)
    } catch (e: Exception) {
      Log.e("ApnaCartRepo", "Firebase sign-in failed", e)
      Result.failure(e)
    }
  }

  fun logout() {
    auth?.signOut()
    _firebaseUser.value = null
    _authUser.value = null
    _adminStatus.value = AdminStatus()
    prefs?.edit()?.putBoolean("auth_logged_in", false)?.apply()
  }

  // Language management
  fun setLanguage(lang: AppLanguage) {
    _currentLanguage.value = lang
    prefs?.edit()?.putString("pref_language", lang.code)?.apply()
  }

  // Cart operations
  fun addToCart(product: Product, size: String = "M", color: String = "Default", quantity: Int = 1): Pair<Boolean, String> {
    if (quantity > product.stockQuantity) {
      return Pair(false, "Cannot add more than available stock (${product.stockQuantity})")
    }
    _cartItems.update { items ->
      val existing = items.find { it.product.id == product.id && it.selectedSize == size && it.selectedColor == color }
      if (existing != null) {
        items.map {
          if (it.cartItemId == existing.cartItemId) it.copy(quantity = it.quantity + quantity) else it
        }
      } else {
        val newItem = CartItem(
          cartItemId = "cart_${UUID.randomUUID().toString().take(8)}",
          product = product,
          selectedSize = size,
          selectedColor = color,
          quantity = quantity
        )
        items + newItem
      }
    }
    return Pair(true, "Added to cart")
  }

  fun updateCartQuantity(cartItemId: String, newQty: Int): Boolean {
    val current = _cartItems.value.find { it.cartItemId == cartItemId }
    if (current != null && newQty > current.product.stockQuantity) {
      return false
    }
    if (newQty <= 0) {
      removeFromCart(cartItemId)
    } else {
      _cartItems.update { items ->
        items.map { if (it.cartItemId == cartItemId) it.copy(quantity = newQty) else it }
      }
    }
    return true
  }

  fun removeFromCart(cartItemId: String) {
    _cartItems.update { items -> items.filterNot { it.cartItemId == cartItemId } }
  }

  fun clearCart() {
    _cartItems.value = emptyList()
  }

  // Wishlist operations
  fun toggleWishlist(productId: String): Boolean {
    var wasAdded = false
    _wishlistIds.update { set ->
      if (set.contains(productId)) {
        wasAdded = false
        set - productId
      } else {
        wasAdded = true
        set + productId
      }
    }
    return wasAdded
  }

  // Address operations
  fun addAddress(address: Address) {
    _addresses.update { list ->
      if (address.isDefault) {
        list.map { it.copy(isDefault = false) } + address
      } else {
        list + address
      }
    }
    if (address.isDefault || _addresses.value.size == 1) {
      _selectedAddress.value = address
    }
  }

  fun addNewAddress(address: Address) {
    addAddress(address)
  }

  fun selectAddress(address: Address) {
    _selectedAddress.value = address
    _addresses.update { list ->
      list.map { it.copy(isDefault = it.id == address.id) }
    }
  }

  fun deleteAddress(addressId: String) {
    _addresses.update { list -> list.filterNot { it.id == addressId } }
    if (_selectedAddress.value.id == addressId && _addresses.value.isNotEmpty()) {
      _selectedAddress.value = _addresses.value.first()
    }
  }

  fun removeCartItem(cartItemId: String) {
    removeFromCart(cartItemId)
  }

  fun setDeliveryPincode(pincode: String) {
    updatePincode(pincode)
  }

  fun updateUserProfile(name: String, email: String, phone: String) {
    updateProfile(name, email, phone)
  }

  fun updatePincode(pincode: String) {
    if (pincode.length == 6 && pincode.all { it.isDigit() }) {
      _deliveryPincode.value = pincode
      prefs?.edit()?.putString("pref_pincode", pincode)?.apply()
    }
  }

  // Coupons
  fun applyCoupon(coupon: OfferCoupon) {
    _appliedCoupon.value = coupon
  }

  fun applyCoupon(code: String): Pair<Boolean, String> {
    val found = _availableCoupons.value.find { it.code.equals(code.trim(), ignoreCase = true) }
    return if (found != null) {
      _appliedCoupon.value = found
      Pair(true, "Coupon '${found.code}' applied!")
    } else {
      Pair(false, "Invalid coupon code")
    }
  }

  fun removeAppliedCoupon() {
    _appliedCoupon.value = null
  }

  fun removeCoupon() {
    removeAppliedCoupon()
  }

  // Order Placement
  fun placeDemoOrder(
    paymentMethod: String,
    deliverySpeed: String = "Standard",
    useWallet: Boolean = false,
    useRewardPoints: Boolean = false
  ): Order {
    val currentItems = _cartItems.value
    val subtotalMrp = currentItems.sumOf { it.itemTotalMrp }
    val productTotal = currentItems.sumOf { it.itemTotalPrice }
    val productDiscount = (subtotalMrp - productTotal).coerceAtLeast(0)

    val coupon = _appliedCoupon.value
    val couponDiscount = when (coupon?.discountType) {
      "FLAT" -> coupon.discountValue
      "PERCENT" -> ((productTotal * coupon.discountValue) / 100).coerceAtMost(400)
      else -> 0
    }

    val baseDelivery = if (productTotal >= _storeSettings.value.freeShippingThreshold || coupon?.discountType == "FREESHIP") 0 else _storeSettings.value.standardShippingFee
    val speedExtra = if (deliverySpeed == "Express") 40 else 0
    val finalDeliveryFee = baseDelivery + speedExtra

    var grossBeforeCredits = (productTotal - couponDiscount + finalDeliveryFee).coerceAtLeast(0)

    // Wallet deduction
    var walletDeduction = 0
    if (useWallet && _walletBalance.value > 0) {
      walletDeduction = minOf(_walletBalance.value, grossBeforeCredits)
      grossBeforeCredits -= walletDeduction
    }

    // Rewards (SuperCoins) deduction (1 point = ₹1)
    var rewardDeduction = 0
    if (useRewardPoints && _rewardPoints.value > 0) {
      rewardDeduction = minOf(_rewardPoints.value, grossBeforeCredits)
      grossBeforeCredits -= rewardDeduction
    }

    val finalAmount = grossBeforeCredits.coerceAtLeast(0)

    val dateFormat = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
    val currentDateStr = dateFormat.format(Date())

    val randomSuffix = (100000..999999).random()
    val orderId = "DEMO-APC-$randomSuffix"
    val customerUid = auth?.currentUser?.uid ?: "CUST_GUEST"

    // Deduct wallet if used
    if (walletDeduction > 0) {
      _walletBalance.update { (it - walletDeduction).coerceAtLeast(0) }
      _walletTransactions.update {
        listOf(
          WalletTransaction(
            id = "wtx_${UUID.randomUUID().toString().take(6)}",
            type = "DEBIT",
            amount = walletDeduction,
            title = "Order Payment",
            description = "Paid for Order $orderId",
            timestamp = currentDateStr,
            orderId = orderId
          )
        ) + it
      }
    }

    // Deduct reward points if used
    if (rewardDeduction > 0) {
      _rewardPoints.update { (it - rewardDeduction).coerceAtLeast(0) }
      _rewardTransactions.update {
        listOf(
          RewardTransaction(
            id = "rtx_${UUID.randomUUID().toString().take(6)}",
            type = "REDEEMED",
            points = rewardDeduction,
            title = "Redeemed on $orderId",
            timestamp = currentDateStr,
            orderId = orderId
          )
        ) + it
      }
    }

    // Award reward points for qualifying order (1 point per ₹100)
    val earnedPoints = (finalAmount / 100) * _storeSettings.value.rewardPointsPerHundred
    if (earnedPoints > 0) {
      _rewardPoints.update { it + earnedPoints }
      _rewardTransactions.update {
        listOf(
          RewardTransaction(
            id = "rtx_${UUID.randomUUID().toString().take(6)}",
            type = "EARNED",
            points = earnedPoints,
            title = "Earned on $orderId",
            timestamp = currentDateStr,
            orderId = orderId
          )
        ) + it
      }
    }

    // Update Loyalty Membership Tier
    _membership.update { current ->
      val newSpend = current.totalSpend + finalAmount
      val newTier = when {
        newSpend >= MembershipTier.PLATINUM.minSpend -> MembershipTier.PLATINUM
        newSpend >= MembershipTier.GOLD.minSpend -> MembershipTier.GOLD
        else -> MembershipTier.SILVER
      }
      current.copy(totalSpend = newSpend, tier = newTier)
    }

    // Server-side Fraud Protection: Check order velocity
    if (_orders.value.size >= 4) {
      _fraudAlerts.update {
        listOf(
          FraudAlert(
            id = "fa_${UUID.randomUUID().toString().take(6)}",
            orderId = orderId,
            customerUid = customerUid,
            reason = "Multiple rapid orders detected within short timeframe",
            riskLevel = "LOW",
            timestamp = currentDateStr
          )
        ) + it
      }
    }

    val newOrder = Order(
      orderId = orderId,
      orderDate = currentDateStr,
      items = currentItems,
      subtotalMrp = subtotalMrp,
      productDiscount = productDiscount,
      couponDiscount = couponDiscount,
      deliveryFee = finalDeliveryFee,
      finalAmount = finalAmount,
      paymentMethod = if (walletDeduction > 0) "$paymentMethod + Wallet(₹$walletDeduction)" else paymentMethod,
      deliveryAddress = _selectedAddress.value,
      currentStatus = OrderStatus.DEMO_PLACED,
      trackingStages = createInitialTrackingStages(currentDateStr),
      estimatedDeliveryDate = if (deliverySpeed == "Express") "Tomorrow by 2 PM" else "Within 2-3 Days",
      courierPartner = if (deliverySpeed == "Express") "BlueDart Express" else _storeSettings.value.courierPartner,
      awbNumber = "APNA${(10000000..99999999).random()}",
      customerId = customerUid
    )

    // Sync to Firestore if authenticated
    val currentAuthUser = auth?.currentUser
    val firestoreInstance = db
    if (currentAuthUser != null && firestoreInstance != null) {
      coroutineScope.launch {
        try {
          val orderMap = hashMapOf<String, Any>(
            "orderId" to orderId,
            "customerId" to customerUid,
            "customerName" to (currentAuthUser.displayName ?: _userProfile.value.fullName),
            "customerEmail" to (currentAuthUser.email ?: _userProfile.value.email),
            "customerPhone" to _userProfile.value.phone,
            "orderDate" to currentDateStr,
            "totalAmount" to subtotalMrp,
            "discountAmount" to (productDiscount + couponDiscount),
            "finalAmount" to finalAmount,
            "paymentMethod" to newOrder.paymentMethod,
            "currentStatus" to OrderStatus.DEMO_PLACED.name,
            "awbNumber" to newOrder.awbNumber,
            "courierPartner" to newOrder.courierPartner,
            "deliveryAddress" to _selectedAddress.value.formattedFullAddress,
            "createdAt" to FieldValue.serverTimestamp()
          )
          firestoreInstance.collection("orders").document(orderId).set(orderMap).await()
        } catch (e: Exception) {
          handleFirestoreError(e, OperationType.CREATE, "orders/$orderId")
        }
      }
    }

    _orders.update { listOf(newOrder) + it }
    clearCart()
    addNotification("Order Placed: $orderId", "Payment of ₹$finalAmount confirmed via ${newOrder.paymentMethod}. Earned $earnedPoints Rewards!", "ORDER")
    return newOrder
  }

  private fun createInitialTrackingStages(createdTime: String): List<TrackingStage> {
    return listOf(
      TrackingStage(
        status = OrderStatus.DEMO_PLACED,
        title = "Order Placed",
        subtitle = "Payment verified. Order received by ApnaCart fulfillment team.",
        timestamp = createdTime,
        location = "ApnaCart Processing Center",
        isCompleted = true,
        isCurrent = true
      ),
      TrackingStage(
        status = OrderStatus.DEMO_PROCESSING,
        title = "Processing at Hub",
        subtitle = "Inventory allocated and quality verified.",
        timestamp = "Pending",
        location = "Bhiwandi Central Hub, MH",
        isCompleted = false,
        isCurrent = false
      ),
      TrackingStage(
        status = OrderStatus.DEMO_SHIPPED,
        title = "Shipped",
        subtitle = "Package handed over to courier partner.",
        timestamp = "Pending",
        location = "Regional Air Cargo Transit",
        isCompleted = false,
        isCurrent = false
      ),
      TrackingStage(
        status = OrderStatus.DEMO_OUT_FOR_DELIVERY,
        title = "Out for Delivery",
        subtitle = "Courier agent on route to doorstep.",
        timestamp = "Pending",
        location = "Local Delivery Van",
        isCompleted = false,
        isCurrent = false
      ),
      TrackingStage(
        status = OrderStatus.DEMO_COMPLETED,
        title = "Delivered",
        subtitle = "Package handed over to customer.",
        timestamp = "Pending",
        location = "Customer Doorstep",
        isCompleted = false,
        isCurrent = false
      )
    )
  }

  fun advanceTrackingStatus(orderId: String) {
    _orders.update { ordersList ->
      ordersList.map { order ->
        if (order.orderId == orderId) {
          val nextStatus = when (order.currentStatus) {
            OrderStatus.DEMO_PLACED -> OrderStatus.DEMO_PROCESSING
            OrderStatus.DEMO_PROCESSING -> OrderStatus.DEMO_SHIPPED
            OrderStatus.DEMO_SHIPPED -> OrderStatus.DEMO_OUT_FOR_DELIVERY
            OrderStatus.DEMO_OUT_FOR_DELIVERY -> OrderStatus.DEMO_COMPLETED
            OrderStatus.DEMO_COMPLETED -> OrderStatus.DEMO_COMPLETED
            OrderStatus.DEMO_CANCELLED -> OrderStatus.DEMO_CANCELLED
          }

          val nowTime = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date())

          val updatedStages = order.trackingStages.map { stage ->
            val stageOrdinal = stage.status.ordinal
            val targetOrdinal = nextStatus.ordinal

            when {
              stageOrdinal < targetOrdinal -> stage.copy(
                isCompleted = true,
                isCurrent = false,
                timestamp = if (stage.timestamp == "Pending") nowTime else stage.timestamp
              )
              stageOrdinal == targetOrdinal -> stage.copy(
                isCompleted = nextStatus == OrderStatus.DEMO_COMPLETED,
                isCurrent = true,
                timestamp = nowTime
              )
              else -> stage.copy(isCompleted = false, isCurrent = false)
            }
          }

          order.copy(currentStatus = nextStatus, trackingStages = updatedStages)
        } else {
          order
        }
      }
    }
  }

  fun cancelOrder(orderId: String) {
    val order = _orders.value.find { it.orderId == orderId }
    val nowTime = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date())
    if (order != null && order.currentStatus != OrderStatus.DEMO_COMPLETED) {
      // Reverse reward points
      val pointsToReverse = (order.finalAmount / 100) * _storeSettings.value.rewardPointsPerHundred
      if (pointsToReverse > 0) {
        _rewardPoints.update { (it - pointsToReverse).coerceAtLeast(0) }
        _rewardTransactions.update {
          listOf(
            RewardTransaction(
              id = "rtx_rev_${UUID.randomUUID().toString().take(6)}",
              type = "REVERSED",
              points = pointsToReverse,
              title = "Reversed for Cancelled Order $orderId",
              timestamp = nowTime,
              orderId = orderId
            )
          ) + it
        }
      }
      // Refund to wallet
      if (order.finalAmount > 0) {
        _walletBalance.update { it + order.finalAmount }
        _walletTransactions.update {
          listOf(
            WalletTransaction(
              id = "wtx_ref_${UUID.randomUUID().toString().take(6)}",
              type = "REFUND",
              amount = order.finalAmount,
              title = "Refund Credited",
              description = "Refund for cancelled order $orderId",
              timestamp = nowTime,
              orderId = orderId
            )
          ) + it
        }
      }
      addNotification("Order Cancelled", "Order $orderId cancelled. ₹${order.finalAmount} refunded to your ApnaCart Wallet.", "ORDER")
    }

    _orders.update { list ->
      list.map {
        if (it.orderId == orderId && it.currentStatus != OrderStatus.DEMO_COMPLETED) {
          it.copy(currentStatus = OrderStatus.DEMO_CANCELLED)
        } else {
          it
        }
      }
    }
  }

  // --- ADMIN OPERATIONS (Authorized Owner Only) ---

  fun adminAddProduct(newProduct: Product) {
    _products.update { listOf(newProduct) + it }
    coroutineScope.launch {
      val database = db ?: return@launch
      try {
        val map = hashMapOf<String, Any>(
          "id" to newProduct.id,
          "title" to newProduct.title,
          "brand" to newProduct.brand,
          "category" to newProduct.category,
          "price" to newProduct.price,
          "originalMrp" to newProduct.originalMrp,
          "rating" to newProduct.rating.toDouble(),
          "reviewCount" to newProduct.reviewCount,
          "description" to newProduct.description,
          "highlights" to newProduct.highlights,
          "availableSizes" to newProduct.availableSizes,
          "availableColors" to newProduct.availableColors,
          "stockQuantity" to newProduct.stockQuantity,
          "isBestseller" to newProduct.isBestseller,
          "updatedAt" to FieldValue.serverTimestamp()
        )
        database.collection("products").document(newProduct.id).set(map).await()
      } catch (e: Exception) {
        handleFirestoreError(e, OperationType.CREATE, "products/${newProduct.id}")
      }
    }
  }

  fun adminUpdateStockAndPrice(productId: String, newStock: Int, newPrice: Int) {
    val previousProduct = _products.value.find { it.id == productId }
    val alert = _priceAlerts.value[productId]
    if (previousProduct != null && alert != null && alert.isEnabled && newPrice < alert.savedPrice) {
      addNotification(
        title = "Price Drop Alert! 📉",
        message = "${previousProduct.title} is now available at ₹$newPrice (was ₹${alert.savedPrice})!",
        type = "OFFER"
      )
    }

    _products.update { list ->
      list.map {
        if (it.id == productId) {
          it.copy(stockQuantity = newStock.coerceAtLeast(0), price = newPrice.coerceAtLeast(1))
        } else {
          it
        }
      }
    }
    coroutineScope.launch {
      val database = db ?: return@launch
      try {
        database.collection("products").document(productId).update(
          "stockQuantity", newStock,
          "price", newPrice,
          "updatedAt", FieldValue.serverTimestamp()
        ).await()
      } catch (e: Exception) {
        handleFirestoreError(e, OperationType.UPDATE, "products/$productId")
      }
    }
  }

  // --- ADVANCED E-COMMERCE EXTENSIONS ---

  // 1. Price Drop Alerts
  fun togglePriceAlert(productId: String, currentPrice: Int): Boolean {
    val currentAlert = _priceAlerts.value[productId]
    val nowState = if (currentAlert == null || !currentAlert.isEnabled) {
      val newAlert = PriceAlert(
        productId = productId,
        savedPrice = currentPrice,
        targetPrice = (currentPrice * 0.9).toInt(),
        createdDate = "Today",
        isEnabled = true
      )
      _priceAlerts.update { it + (productId to newAlert) }
      addNotification("Price Alert Enabled", "We'll notify you the moment the price drops below ₹$currentPrice!", "OFFER")
      true
    } else {
      _priceAlerts.update { it + (productId to currentAlert.copy(isEnabled = false)) }
      addNotification("Price Alert Disabled", "Price alert removed for this item.", "OFFER")
      false
    }
    return nowState
  }

  // 2. Gift Cards
  fun redeemGiftCard(code: String): Pair<Boolean, String> {
    val normalized = code.trim().uppercase()
    val card = _giftCards.value.find { it.code.equals(normalized, true) }
      ?: return Pair(false, "Invalid Gift Card Code. Please check and try again.")

    if (card.isRedeemed) {
      return Pair(false, "This Gift Card has already been redeemed.")
    }

    val customerUid = auth?.currentUser?.uid ?: "CUST_GUEST"
    val currentDateStr = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date())

    _giftCards.update { list ->
      list.map {
        if (it.code.equals(normalized, true)) {
          it.copy(isRedeemed = true, redeemedByUid = customerUid, remainingBalance = 0)
        } else it
      }
    }

    _walletBalance.update { it + card.initialAmount }
    _walletTransactions.update {
      listOf(
        WalletTransaction(
          id = "wtx_gc_${UUID.randomUUID().toString().take(6)}",
          type = "GIFT_CARD",
          amount = card.initialAmount,
          title = "Gift Card Redeemed ($normalized)",
          description = "₹${card.initialAmount} Gift Card balance added to ApnaCart Wallet",
          timestamp = currentDateStr
        )
      ) + it
    }

    addNotification("Gift Card Redeemed", "₹${card.initialAmount} successfully added to your ApnaCart Wallet from Gift Card $normalized.", "OFFER")
    return Pair(true, "₹${card.initialAmount} Gift Card redeemed successfully into your Wallet!")
  }

  fun adminCreateGiftCard(code: String, amount: Int): Boolean {
    val normalized = code.trim().uppercase()
    if (normalized.length < 4 || amount <= 0) return false
    val card = GiftCard(
      code = normalized,
      initialAmount = amount,
      remainingBalance = amount,
      expiryDate = "31 Dec 2027",
      isRedeemed = false
    )
    _giftCards.update { listOf(card) + it.filterNot { it.code.equals(normalized, true) } }
    return true
  }

  // 3. Product Q&A
  fun askProductQuestion(productId: String, questionText: String) {
    val q = ProductQuestion(
      id = "qa_${UUID.randomUUID().toString().take(6)}",
      productId = productId,
      questionText = questionText,
      askedBy = _userProfile.value.fullName,
      askedDate = "Just now",
      isApproved = true
    )
    _productQuestions.update { listOf(q) + it }
    addNotification("Question Submitted", "Your question has been posted to the seller and community.", "INFO")
  }

  fun adminAnswerQuestion(questionId: String, answerText: String) {
    val nowTime = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date())
    _productQuestions.update { list ->
      list.map {
        if (it.id == questionId) {
          it.copy(answerText = answerText, answeredBy = "ApnaCart Verified Seller", answeredDate = nowTime, isApproved = true)
        } else it
      }
    }
  }

  // 4. Fraud Protection Review
  fun adminResolveFraudAlert(alertId: String) {
    _fraudAlerts.update { list ->
      list.map { if (it.id == alertId) it.copy(isReviewed = true) else it }
    }
  }

  // 5. Referral Program
  fun submitReferralCode(code: String): Pair<Boolean, String> {
    val clean = code.trim().uppercase()
    if (clean == "APNA100" || clean == "FRIEND100") {
      _walletBalance.update { it + 100 }
      _walletTransactions.update {
        listOf(
          WalletTransaction(
            id = "wtx_ref_bonus_${UUID.randomUUID().toString().take(6)}",
            type = "CREDIT",
            amount = 100,
            title = "Referral Welcome Bonus",
            description = "Bonus for using referral code $clean",
            timestamp = "Today"
          )
        ) + it
      }
      return Pair(true, "Referral code applied! ₹100 welcome bonus added to your Wallet.")
    }
    return Pair(false, "Invalid referral code. Try APNA100.")
  }

  // 6. Size Recommendation Engine
  fun calculateSizeRecommendation(product: Product, chestInch: Int, waistInch: Int): SizeRecommendation {
    val chart = listOf(
      SizeChartRow("S (36)", 36, 30, 27, "160-168 cm"),
      SizeChartRow("M (38)", 38, 32, 28, "168-175 cm"),
      SizeChartRow("L (40)", 40, 34, 29, "175-182 cm"),
      SizeChartRow("XL (42)", 42, 36, 30, "180-188 cm"),
      SizeChartRow("XXL (44)", 44, 38, 31, "185-192 cm")
    )

    val bestSize = when {
      chestInch <= 36 || waistInch <= 30 -> "S"
      chestInch <= 38 || waistInch <= 32 -> "M"
      chestInch <= 40 || waistInch <= 34 -> "L"
      chestInch <= 42 || waistInch <= 36 -> "XL"
      else -> "XXL"
    }

    val explanation = if (product.category.contains("clothing") || product.category.contains("jeans") || product.category.contains("kurtis")) {
      "Based on your $chestInch\" chest and $waistInch\" waist measurements, size $bestSize offers an optimal Indian comfort fit with natural room for movement."
    } else {
      "Recommended size $bestSize matches standard Indian measurement guidelines."
    }

    return SizeRecommendation(
      recommendedSize = bestSize,
      explanation = explanation,
      chartRows = chart
    )
  }

  // 7. Visual Photo Search
  fun performPhotoSearch(visualLabel: String): List<Product> {
    val label = visualLabel.lowercase()
    val all = _products.value
    return when {
      label.contains("jeans") || label.contains("denim") || label.contains("pant") ->
        all.filter { it.category == "jeans" || it.title.contains("Jeans", ignoreCase = true) }
      label.contains("kurti") || label.contains("dress") || label.contains("ethnic") ->
        all.filter { it.category == "kurtis" || it.title.contains("Kurti", ignoreCase = true) }
      label.contains("saree") || label.contains("silk") || label.contains("traditional") ->
        all.filter { it.category == "sarees" || it.title.contains("Saree", ignoreCase = true) }
      label.contains("shirt") || label.contains("casual") ->
        all.filter { it.category == "mens_clothing" || it.title.contains("Shirt", ignoreCase = true) }
      label.contains("shoe") || label.contains("footwear") ->
        all.filter { it.category == "footwear" || it.title.contains("Shoe", ignoreCase = true) }
      else -> all.take(4)
    }
  }

  // 8. AI Shopping Assistant (Natural Language in Hindi & English)
  fun sendAiAssistantQuery(userInput: String): AiChatMessage {
    val userMsg = AiChatMessage(
      id = "user_${UUID.randomUUID().toString().take(6)}",
      isUser = true,
      message = userInput,
      timestamp = "Just now"
    )

    val lower = userInput.lowercase()
    val allProds = _products.value

    // 1. Detect Budget constraints (e.g., "under 700", "700 ke andar", "under ₹500")
    val priceRegex = Regex("""(?:under|below|less than|kam|andar)\s*(?:₹|rs\.?|inr)?\s*(\d+)""", RegexOption.IGNORE_CASE)
    val priceMatch = priceRegex.find(lower)
    val maxPrice = priceMatch?.groupValues?.get(1)?.toIntOrNull()

    // 2. Match actual product catalog items
    var matched = allProds.filter { p ->
      val matchesCategory = when {
        lower.contains("jeans") || lower.contains("जींस") -> p.category == "jeans" || p.title.contains("Jeans", ignoreCase = true)
        lower.contains("kurti") || lower.contains("कुर्ती") -> p.category == "kurtis" || p.title.contains("Kurti", ignoreCase = true)
        lower.contains("saree") || lower.contains("साड़ी") -> p.category == "sarees" || p.title.contains("Saree", ignoreCase = true)
        lower.contains("shirt") || lower.contains("शर्ट") -> p.category == "mens_clothing" || p.title.contains("Shirt", ignoreCase = true)
        lower.contains("festive") || lower.contains("diwali") -> p.isBestseller || p.price < 999
        else -> false
      }
      matchesCategory
    }

    if (maxPrice != null) {
      matched = matched.filter { it.price <= maxPrice }
    }

    // 3. Formulate honest AI response
    val (aiText, quickReplies) = when {
      // Policy queries
      lower.contains("delivery") || lower.contains("shipping") || lower.contains("डिलीवरी") -> {
        Pair(
          "ApnaCart offers FREE Delivery on orders above ₹${_storeSettings.value.freeShippingThreshold}! Standard delivery takes 2-3 days, and Express Delivery arrives in 24 hours. COD and UPI are both supported.",
          listOf("Show Top Deals", "Jeans under ₹799", "Explore Kurtis")
        )
      }
      lower.contains("return") || lower.contains("refund") || lower.contains("वापसी") -> {
        Pair(
          "We have a 7-Day Hassle-Free Return Policy. If an item doesn't fit or meet your expectations, simply initiate a return from Order History and the refund will be credited directly to your ApnaCart Wallet or source bank account.",
          listOf("My Orders", "Wallet Balance", "Help Center")
        )
      }
      lower.contains("size") || lower.contains("fit") || lower.contains("साइज") -> {
        Pair(
          "All our apparel follows standard Indian sizing (S: 36\", M: 38\", L: 40\", XL: 42\", XXL: 44\"). You can use our interactive Size Recommendation tool on any product detail page for a tailored fit based on your measurements!",
          listOf("Show Men's Shirts", "Women's Kurtis", "Slim Fit Jeans")
        )
      }
      matched.isNotEmpty() -> {
        val count = matched.size
        val budgetNote = if (maxPrice != null) " under ₹$maxPrice" else ""
        Pair(
          "Found $count verified ApnaCart item${if (count > 1) "s" else ""}$budgetNote from our catalog. Each item is in stock with fast delivery:",
          listOf("Add first item to cart", "Filter under ₹499", "View all categories")
        )
      }
      lower.contains("hi") || lower.contains("hello") || lower.contains("नमस्ते") || lower.contains("namaste") -> {
        Pair(
          "Namaste! How can I assist your shopping today? Tell me what you are looking for (e.g., 'Slim jeans under ₹800', 'Traditional silk sarees', or 'Check return policy').",
          listOf("Festive Kurtis", "Men's Denim", "Today's Offers")
        )
      }
      else -> {
        // Fallback with real popular products
        matched = allProds.filter { it.isBestseller }.take(3)
        Pair(
          "Here are our top trending bestsellers in the store right now. Let me know if you would like me to narrow down by price, size or fabric!",
          listOf("Show Kurtis", "Show Jeans", "Check Offers")
        )
      }
    }

    val aiResponse = AiChatMessage(
      id = "ai_${UUID.randomUUID().toString().take(6)}",
      isUser = false,
      message = aiText,
      timestamp = "Just now",
      matchedProducts = matched.take(4),
      quickReplies = quickReplies
    )

    _aiChatMessages.update { it + listOf(userMsg, aiResponse) }
    return aiResponse
  }

  fun adminDeleteProduct(productId: String) {
    _products.update { list -> list.filterNot { it.id == productId } }
    _cartItems.update { items -> items.filterNot { it.product.id == productId } }
    coroutineScope.launch {
      val database = db ?: return@launch
      try {
        database.collection("products").document(productId).delete().await()
      } catch (e: Exception) {
        handleFirestoreError(e, OperationType.DELETE, "products/$productId")
      }
    }
  }

  fun adminUpdateOrderStatus(orderId: String, newStatus: OrderStatus) {
    _orders.update { list ->
      list.map { if (it.orderId == orderId) it.copy(currentStatus = newStatus) else it }
    }
    coroutineScope.launch {
      val database = db ?: return@launch
      try {
        database.collection("orders").document(orderId).update(
          "currentStatus", newStatus.name,
          "updatedAt", FieldValue.serverTimestamp()
        ).await()
      } catch (e: Exception) {
        handleFirestoreError(e, OperationType.UPDATE, "orders/$orderId")
      }
    }
  }

  fun adminUpdateStoreSettings(settings: StoreSettings) {
    _storeSettings.value = settings
    coroutineScope.launch {
      val database = db ?: return@launch
      try {
        val map = hashMapOf<String, Any>(
          "upiEnabled" to settings.upiEnabled,
          "codEnabled" to settings.codEnabled,
          "cardsEnabled" to settings.cardsEnabled,
          "courierPartner" to settings.courierPartner,
          "standardShippingFee" to settings.standardShippingFee,
          "freeShippingThreshold" to settings.freeShippingThreshold
        )
        database.collection("settings").document("integrations").set(map).await()
      } catch (e: Exception) {
        handleFirestoreError(e, OperationType.UPDATE, "settings/integrations")
      }
    }
  }

  fun adminAddCoupon(coupon: OfferCoupon) {
    _availableCoupons.update { list ->
      list.filterNot { it.code.equals(coupon.code, ignoreCase = true) } + coupon
    }
    coroutineScope.launch {
      val database = db ?: return@launch
      try {
        val map = hashMapOf<String, Any>(
          "code" to coupon.code,
          "title" to coupon.title,
          "description" to coupon.description,
          "discountType" to coupon.discountType,
          "discountValue" to coupon.discountValue,
          "minCartValue" to coupon.minCartValue
        )
        database.collection("coupons").document(coupon.code).set(map).await()
      } catch (e: Exception) {
        handleFirestoreError(e, OperationType.CREATE, "coupons/${coupon.code}")
      }
    }
  }

  fun adminDeleteCoupon(code: String) {
    _availableCoupons.update { list -> list.filterNot { it.code.equals(code, ignoreCase = true) } }
    if (_appliedCoupon.value?.code.equals(code, ignoreCase = true)) {
      _appliedCoupon.value = null
    }
    coroutineScope.launch {
      val database = db ?: return@launch
      try {
        database.collection("coupons").document(code).delete().await()
      } catch (e: Exception) {
        handleFirestoreError(e, OperationType.DELETE, "coupons/$code")
      }
    }
  }

  fun resetAllDemoData() {
    _products.value = DemoDataProvider.initialProducts
    _orders.value = DemoDataProvider.createInitialOrders()
    _cartItems.value = emptyList()
    _wishlistIds.value = setOf("p_jeans_1", "p_kurti_1")
    _availableCoupons.value = DemoDataProvider.sampleCoupons
    _appliedCoupon.value = null
    _addresses.value = DemoDataProvider.initialAddresses
    _selectedAddress.value = DemoDataProvider.initialAddresses[0]
    _userProfile.value = UserProfile()
    prefs?.edit()?.clear()?.apply()
  }

  fun updateProfile(name: String, email: String, phone: String) {
    _userProfile.update { it.copy(fullName = name, email = email, phone = phone) }
    prefs?.edit()?.putString("user_name", name)?.putString("user_email", email)?.putString("user_phone", phone)?.apply()
  }

  fun addNotification(title: String, message: String, type: String = "INFO") {
    val n = AppNotification(
      id = "n_${UUID.randomUUID().toString().take(8)}",
      title = title,
      message = message,
      timestamp = "Just now",
      type = type
    )
    _notifications.update { listOf(n) + it }
  }

  fun markNotificationRead(id: String) {
    _notifications.update { list ->
      list.map { if (it.id == id) it.copy(isRead = true) else it }
    }
  }

  fun recordProductView(productId: String) {
    _recentlyViewedIds.update { list ->
      (listOf(productId) + list.filterNot { it == productId }).take(10)
    }
  }

  fun getAdminStats(): AdminDashboardStats {
    val prodList = _products.value
    val ordList = _orders.value
    val revenue = ordList.filter { it.currentStatus != OrderStatus.DEMO_CANCELLED }.sumOf { it.finalAmount }
    val lowStock = prodList.count { it.stockQuantity < 5 }
    val cancelled = ordList.count { it.currentStatus == OrderStatus.DEMO_CANCELLED }

    return AdminDashboardStats(
      totalProducts = prodList.size,
      totalOrders = ordList.size,
      totalRevenue = revenue,
      lowStockCount = lowStock,
      cancelledOrdersCount = cancelled
    )
  }
}
