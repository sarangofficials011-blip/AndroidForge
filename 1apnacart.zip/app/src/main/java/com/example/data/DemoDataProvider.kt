package com.example.data

import com.example.R
import com.example.model.Address
import com.example.model.CartItem
import com.example.model.CategoryItem
import com.example.model.OfferCoupon
import com.example.model.Order
import com.example.model.OrderStatus
import com.example.model.Product
import com.example.model.TrackingStage
import com.example.model.UserProfile

object DemoDataProvider {

  val heroBanners = listOf(
    BannerItem(
      id = "b_blue_1",
      title = "Big Fashion Festival",
      tagline = "Up to 70% Off on Jeans, Kurtis & Sarees",
      drawableRes = R.drawable.blue_mega_sale_banner_1793278954563,
      categoryTarget = "all"
    ),
    BannerItem(
      id = "b_blue_2",
      title = "Ethnic Glamour Trends",
      tagline = "Pure Silk Sarees & Designer Kurtis",
      drawableRes = R.drawable.ethnic_fashion_banner_1793263820939,
      categoryTarget = "kurtis"
    ),
    BannerItem(
      id = "b_blue_3",
      title = "Denim & Casuals Utsav",
      tagline = "Top Brands Jeans & Shirts from ₹599",
      drawableRes = R.drawable.blue_mega_sale_banner_1793278954563,
      categoryTarget = "jeans"
    )
  )

  data class BannerItem(
    val id: String,
    val title: String,
    val tagline: String,
    val drawableRes: Int,
    val categoryTarget: String
  )

  val categories = listOf(
    CategoryItem("all", "all_products", "🛍️"),
    CategoryItem("mens_clothing", "mens_clothing", "👔", "New"),
    CategoryItem("womens_clothing", "womens_clothing", "👗", "Trending"),
    CategoryItem("jeans", "jeans", "👖", "Popular"),
    CategoryItem("kurtis", "kurtis", "🥻", "Hot"),
    CategoryItem("sarees", "sarees", "🌺", "Festive"),
    CategoryItem("accessories", "accessories", "👜")
  )

  val sampleCoupons = listOf(
    OfferCoupon(
      code = "APNA150",
      title = "Flat ₹150 OFF",
      description = "Get flat ₹150 discount on orders above ₹799",
      discountType = "FLAT",
      discountValue = 150,
      minCartValue = 799,
      expiryDate = "30 Nov 2026"
    ),
    OfferCoupon(
      code = "FLIP20",
      title = "20% Instant Discount",
      description = "Enjoy 20% discount up to ₹300 on fashion items",
      discountType = "PERCENT",
      discountValue = 20,
      minCartValue = 499,
      expiryDate = "15 Dec 2026"
    ),
    OfferCoupon(
      code = "FREESHIP",
      title = "Free Delivery",
      description = "Zero shipping charges on any cart value",
      discountType = "FREESHIP",
      discountValue = 50,
      minCartValue = 0,
      expiryDate = "31 Dec 2026"
    ),
    OfferCoupon(
      code = "APNA50",
      title = "Welcome ₹50 Voucher",
      description = "Flat ₹50 savings on your cart",
      discountType = "FLAT",
      discountValue = 50,
      minCartValue = 299,
      expiryDate = "25 Nov 2026"
    )
  )

  val initialProducts = listOf(
    // JEANS
    Product(
      id = "p_jeans_1",
      title = "Men's Slim Fit Stretchable Denim Jeans (Dark Indigo)",
      brand = "Flying Machine",
      category = "jeans",
      price = 899,
      originalMrp = 1999,
      rating = 4.4f,
      reviewCount = 1840,
      drawableRes = R.drawable.blue_mega_sale_banner_1793278954563,
      description = "Premium washed cotton stretch denim with 5 pockets, durable zip fly, and comfortable waistband. Specially tailored for Indian weather with breathable yarn.",
      highlights = listOf(
        "98% Cotton, 2% Elastane stretch",
        "Mid-rise slim tapered fit",
        "Machine washable fast indigo dye",
        "Includes reinforced coin pocket"
      ),
      availableSizes = listOf("30", "32", "34", "36", "38"),
      availableColors = listOf("Dark Indigo", "Stone Washed Blue", "Midnight Black"),
      stockQuantity = 14,
      isBestseller = true,
      deliveryEstimate = "Tomorrow by 5 PM"
    ),
    Product(
      id = "p_jeans_2",
      title = "Women's High-Rise Wide-Leg Retro Boyfriend Jeans",
      brand = "Roadster",
      category = "jeans",
      price = 949,
      originalMrp = 2199,
      rating = 4.6f,
      reviewCount = 920,
      drawableRes = R.drawable.blue_mega_sale_banner_1793278954563,
      description = "Trending relaxed wide-leg high waist jeans crafted from 100% durable non-stretch denim. Pairs effortlessly with cropped tees and ethnic kurtis.",
      highlights = listOf(
        "100% Pure Cotton Rigid Denim",
        "High-rise with relaxed hip-to-ankle cut",
        "5-pocket signature vintage wash",
        "Zip fly with metal shank button"
      ),
      availableSizes = listOf("26", "28", "30", "32", "34"),
      availableColors = listOf("Light Ice Blue", "Medium Indigo", "Charcoal Grey"),
      stockQuantity = 9,
      isBestseller = true,
      deliveryEstimate = "2 Days"
    ),

    // KURTIS
    Product(
      id = "p_kurti_1",
      title = "Women's Embroidered Chikankari Cotton Anarkali Kurti",
      brand = "Biba Trends",
      category = "kurtis",
      price = 799,
      originalMrp = 1799,
      rating = 4.7f,
      reviewCount = 3120,
      drawableRes = R.drawable.ethnic_fashion_banner_1793263820939,
      description = "Handcrafted Lucknowi Chikankari embroidered long anarkali kurti in breathable mulmul cotton. Detailed floral motifs across yoke and sleeves with gota border.",
      highlights = listOf(
        "100% Soft Mulmul Breathable Cotton",
        "Authentic Lucknow Hand Embroidery",
        "Flared Calf-Length Silhouette (46 inches)",
        "Gentle Hand Wash Recommended"
      ),
      availableSizes = listOf("S (36)", "M (38)", "L (40)", "XL (42)", "XXL (44)"),
      availableColors = listOf("Sky Blue", "Pastel Pink", "Off White", "Mint Green"),
      stockQuantity = 18,
      isBestseller = true,
      deliveryEstimate = "Tomorrow by 2 PM"
    ),
    Product(
      id = "p_kurti_2",
      title = "Printed Straight Cotton Casual Dailywear Kurti with Pockets",
      brand = "Libas",
      category = "kurtis",
      price = 449,
      originalMrp = 999,
      rating = 4.3f,
      reviewCount = 1450,
      drawableRes = R.drawable.ethnic_fashion_banner_1793263820939,
      description = "Everyday printed straight cotton kurti featuring round keyhole neck, 3/4th sleeves, and 1 convenient side pocket for phone. Zero fading guaranteed.",
      highlights = listOf(
        "100% Color-Fast Cotton",
        "Side utility pocket included",
        "Mandarin neck with subtle button accent",
        "Perfect for college and office wear"
      ),
      availableSizes = listOf("XS", "S", "M", "L", "XL"),
      availableColors = listOf("Royal Blue Floral", "Maroon Geometric", "Yellow Ikat"),
      stockQuantity = 22,
      isUnder499 = true,
      deliveryEstimate = "Tomorrow by 6 PM"
    ),

    // SAREES
    Product(
      id = "p_saree_1",
      title = "Banarasi Silk Blend Jacquard Zari Festive Saree with Blouse Piece",
      brand = "Varanasi Silk",
      category = "sarees",
      price = 1299,
      originalMrp = 3499,
      rating = 4.8f,
      reviewCount = 2250,
      drawableRes = R.drawable.ethnic_fashion_banner_1793263820939,
      description = "Traditional Banarasi art silk jacquard woven saree with rich gold zari floral jaal, heavy contrast pallu, and unstitched brocade blouse piece.",
      highlights = listOf(
        "Length: 5.5m Saree + 0.8m Blouse",
        "Woven Gold Zari Traditional Motifs",
        "Ideal for Weddings, Diwali & Festivals",
        "Dry Clean Recommended"
      ),
      availableSizes = listOf("Free Size (6.3m Total)"),
      availableColors = listOf("Royal Peacock Blue", "Crimson Red", "Magenta Pink", "Emerald Green"),
      stockQuantity = 11,
      isBestseller = true,
      deliveryEstimate = "2 Days"
    ),
    Product(
      id = "p_saree_2",
      title = "Lightweight Chiffon Floral Daily Saree with Lace Border",
      brand = "Suta Touch",
      category = "sarees",
      price = 489,
      originalMrp = 1199,
      rating = 4.2f,
      reviewCount = 670,
      drawableRes = R.drawable.ethnic_fashion_banner_1793263820939,
      description = "Super lightweight airy chiffon saree featuring delicate watercolor floral prints and a scalloped golden lace border. Drapes effortlessly in seconds.",
      highlights = listOf(
        "Feather-light Chiffon fabric",
        "Wrinkle-resistant easy drape",
        "Includes matching running blouse piece",
        "Machine wash friendly"
      ),
      availableSizes = listOf("Free Size (5.5m + 0.8m)"),
      availableColors = listOf("Powder Blue", "Lavender", "Peach Glow"),
      stockQuantity = 16,
      isUnder499 = true,
      deliveryEstimate = "3 Days"
    ),

    // MEN'S CLOTHING
    Product(
      id = "p_men_1",
      title = "Men's 100% Pure Linen Solid Mandarin Collar Casual Shirt",
      brand = "Allen Solly",
      category = "mens_clothing",
      price = 849,
      originalMrp = 1899,
      rating = 4.5f,
      reviewCount = 1380,
      drawableRes = R.drawable.blue_mega_sale_banner_1793278954563,
      description = "Breathable pure linen blend full-sleeve shirt with a stylish Chinese band collar, curved hem, and mother-of-pearl finish buttons. Keeps you cool all day.",
      highlights = listOf(
        "Premium Linen Cotton Blend",
        "Mandarin / Nehru Collar styling",
        "Curved hem for untucked styling",
        "Pre-washed for zero shrinkage"
      ),
      availableSizes = listOf("S (38)", "M (40)", "L (42)", "XL (44)"),
      availableColors = listOf("Ice Blue", "Crisp White", "Olive Green", "Light Pink"),
      stockQuantity = 15,
      deliveryEstimate = "Tomorrow by 3 PM"
    ),
    Product(
      id = "p_men_2",
      title = "Men's Festive Silk Blend Kurta Churidar Pajama Set",
      brand = "Manyavar Style",
      category = "mens_clothing",
      price = 1199,
      originalMrp = 2599,
      rating = 4.6f,
      reviewCount = 1120,
      drawableRes = R.drawable.ethnic_fashion_banner_1793263820939,
      description = "Royal dupion silk blend knee-length kurta with subtle thread embroidery on collar and cuffs. Comes complete with comfortable drawstring churidar pajama.",
      highlights = listOf(
        "Dupion Silk Blend Fabric",
        "Includes Kurta & Churidar Pajama",
        "Full sleeves with pocket",
        "Perfect for Puja & Weddings"
      ),
      availableSizes = listOf("M (38)", "L (40)", "XL (42)", "XXL (44)"),
      availableColors = listOf("Cobalt Blue", "Golden Beige", "Ruby Maroon"),
      stockQuantity = 8,
      isBestseller = true,
      deliveryEstimate = "2 Days"
    ),

    // WOMEN'S CLOTHING
    Product(
      id = "p_women_1",
      title = "Women's Floral Tiered Fit & Flare Maxi Dress with Belt",
      brand = "Vero Moda",
      category = "womens_clothing",
      price = 799,
      originalMrp = 1999,
      rating = 4.5f,
      reviewCount = 890,
      drawableRes = R.drawable.blue_mega_sale_banner_1793278954563,
      description = "Flowy tiered georgette maxi dress featuring romantic bohemian floral prints, square neckline, elasticated flutter sleeves, and a matching waist tie belt.",
      highlights = listOf(
        "Lightweight Georgette with inner lining",
        "Tiered ruffle flared skirt",
        "Smocked back for flexible fit",
        "Flattering ankle-length cut"
      ),
      availableSizes = listOf("XS", "S", "M", "L", "XL"),
      availableColors = listOf("Ocean Blue Floral", "Blush Pink", "Sunflower Yellow"),
      stockQuantity = 12,
      deliveryEstimate = "Tomorrow by 6 PM"
    ),

    // ACCESSORIES
    Product(
      id = "p_acc_1",
      title = "Handcrafted Vegan Leather Tote Handbag with Detachable Sling",
      brand = "Lavie Chic",
      category = "accessories",
      price = 899,
      originalMrp = 2299,
      rating = 4.7f,
      reviewCount = 2190,
      drawableRes = R.drawable.apnacart_blue_icon_1793278921772,
      description = "Spacious structured vegan leather tote bag with 3 zip compartments, dedicated phone pocket, sturdy double handles, and an adjustable shoulder strap.",
      highlights = listOf(
        "Cruelty-free Premium PU Leather",
        "Holds 13-inch laptop, water bottle & diary",
        "Water-resistant interior lining",
        "Gold-toned rust-resistant hardware"
      ),
      availableSizes = listOf("Standard Tote (14 x 11 x 5 in)"),
      availableColors = listOf("Navy Blue", "Tan Brown", "Classic Black"),
      stockQuantity = 10,
      isBestseller = true,
      deliveryEstimate = "Tomorrow by 2 PM"
    ),
    Product(
      id = "p_acc_2",
      title = "Men's Genuine Leather Reversible Formal & Casual Belt (Black & Brown)",
      brand = "Urban Buckle",
      category = "accessories",
      price = 399,
      originalMrp = 899,
      rating = 4.4f,
      reviewCount = 1430,
      drawableRes = R.drawable.apnacart_blue_icon_1793278921772,
      description = "2-in-1 rotatable buckle reversible genuine leather belt. Switch effortlessly between polished formal black and warm casual brown with a single twist.",
      highlights = listOf(
        "100% Top Grain Reversible Leather",
        "360-degree Rotatable Zinc Alloy Buckle",
        "Fits waist sizes from 28 to 44 inches",
        "Comes in a sleek gift box"
      ),
      availableSizes = listOf("Free Size (Adjustable up to 44 in)"),
      availableColors = listOf("Black / Tan Brown Duo"),
      stockQuantity = 25,
      isUnder499 = true,
      deliveryEstimate = "Tomorrow by 1 PM"
    ),
    Product(
      id = "p_acc_3",
      title = "Traditional Kundan & Pearls Gold-Plated Jhumka Earrings",
      brand = "Zaveri Touch",
      category = "accessories",
      price = 349,
      originalMrp = 999,
      rating = 4.6f,
      reviewCount = 1890,
      drawableRes = R.drawable.ethnic_fashion_banner_1793263820939,
      description = "Intricately designed Rajasthani dome jhumkas with hand-inlaid Kundan stones, delicate hanging pearl drops, and skin-friendly hypoallergenic push back.",
      highlights = listOf(
        "22K Micron Gold Plated",
        "Lightweight on earlobes (18g pair)",
        "Lead and nickel safe for sensitive skin",
        "Includes extra silicone push stoppers"
      ),
      availableSizes = listOf("Standard Dangler (2.5 inches)"),
      availableColors = listOf("Royal Blue Kundan", "Emerald Green", "Ruby Red"),
      stockQuantity = 20,
      isUnder499 = true,
      deliveryEstimate = "Same Day Dispatch"
    )
  )

  val initialAddresses = listOf(
    Address(
      id = "addr_1",
      fullName = "Priya Sharma",
      phone = "9876543210",
      houseNoBuilding = "Flat 402, Lotus Residency",
      roadAreaColony = "Linking Road, Bandra West",
      pincode = "400050",
      city = "Mumbai",
      state = "Maharashtra",
      addressType = "Home",
      isDefault = true
    ),
    Address(
      id = "addr_2",
      fullName = "Priya Sharma",
      phone = "9876543210",
      houseNoBuilding = "Tower B, 7th Floor, Tech Park",
      roadAreaColony = "Outer Ring Road, Bellandur",
      pincode = "560103",
      city = "Bengaluru",
      state = "Karnataka",
      addressType = "Work",
      isDefault = false
    )
  )

  fun createInitialOrders(): List<Order> {
    val sampleKurti = initialProducts.first { it.id == "p_kurti_1" }
    val sampleJeans = initialProducts.first { it.id == "p_jeans_1" }

    return listOf(
      Order(
        orderId = "DEMO-APC-914820",
        orderDate = "28 Oct 2026, 11:30 AM",
        items = listOf(
          CartItem(
            cartItemId = "ci_past_1",
            product = sampleKurti,
            selectedSize = "M (38)",
            selectedColor = "Sky Blue",
            quantity = 1
          ),
          CartItem(
            cartItemId = "ci_past_2",
            product = sampleJeans,
            selectedSize = "32",
            selectedColor = "Dark Indigo",
            quantity = 1
          )
        ),
        subtotalMrp = 3798,
        productDiscount = 2100,
        couponDiscount = 150,
        deliveryFee = 0,
        finalAmount = 1548,
        paymentMethod = "Demo UPI (Google Pay - Simulated)",
        deliveryAddress = initialAddresses[0],
        currentStatus = OrderStatus.DEMO_SHIPPED,
        trackingStages = listOf(
          TrackingStage(
            status = OrderStatus.DEMO_PLACED,
            title = "Demo Order Placed",
            subtitle = "Simulated payment verified. Fictional order logged locally.",
            timestamp = "28 Oct, 11:30 AM",
            location = "Local Device Sandbox",
            isCompleted = true,
            isCurrent = false
          ),
          TrackingStage(
            status = OrderStatus.DEMO_PROCESSING,
            title = "Demo Processing at Hub",
            subtitle = "Sample inventory allocated and packed in demo warehouse.",
            timestamp = "28 Oct, 03:15 PM",
            location = "Bhiwandi Demo Hub, MH",
            isCompleted = true,
            isCurrent = false
          ),
          TrackingStage(
            status = OrderStatus.DEMO_SHIPPED,
            title = "Demo Shipped (Simulated)",
            subtitle = "Package dispatched via simulated courier linehaul.",
            timestamp = "29 Oct, 08:30 AM",
            location = "Mumbai Regional Transit (Simulated)",
            isCompleted = true,
            isCurrent = true
          ),
          TrackingStage(
            status = OrderStatus.DEMO_OUT_FOR_DELIVERY,
            title = "Demo Out for Delivery",
            subtitle = "Simulated agent scheduled for delivery.",
            timestamp = "Expected Tomorrow",
            location = "Bandra Delivery Hub",
            isCompleted = false,
            isCurrent = false
          ),
          TrackingStage(
            status = OrderStatus.DEMO_COMPLETED,
            title = "Demo Completed",
            subtitle = "Simulated delivery marked complete.",
            timestamp = "Pending",
            location = "Recipient Doorstep",
            isCompleted = false,
            isCurrent = false
          )
        ),
        estimatedDeliveryDate = "Tomorrow by 5 PM (Simulated)",
        courierPartner = "Simulated Express (Delhivery/BlueDart Demo)",
        awbNumber = "APNA8829471"
      )
    )
  }
}
