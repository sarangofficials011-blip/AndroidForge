package com.example

import com.example.data.DemoDataProvider
import com.example.model.Address
import com.example.model.AppLanguage
import com.example.model.OrderStatus
import com.example.model.Product
import com.example.repository.ApnaCartRepository
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class ApnaCartRepositoryTest {

  private lateinit var repository: ApnaCartRepository

  @Before
  fun setUp() {
    repository = ApnaCartRepository(context = null)
  }

  @Test
  fun testWishlistToggle() {
    val productId = "prod_sample"
    // Initially not in wishlist
    val added = repository.toggleWishlist(productId)
    assertTrue("Should be added to wishlist", added)
    assertTrue(repository.wishlistIds.value.contains(productId))

    val removed = repository.toggleWishlist(productId)
    assertFalse("Should be removed from wishlist", removed)
    assertFalse(repository.wishlistIds.value.contains(productId))
  }

  @Test
  fun testCartOperationsAndStockLimits() {
    repository.clearCart()
    val product = DemoDataProvider.initialProducts[0]

    val (added, _) = repository.addToCart(product, "32", "Dark Indigo", 1)
    assertTrue(added)
    assertEquals(1, repository.cartItems.value.size)

    // Add same item again -> increments quantity
    repository.addToCart(product, "32", "Dark Indigo", 1)
    val item = repository.cartItems.value.find { it.product.id == product.id && it.selectedSize == "32" }
    assertNotNull(item)
    assertEquals(2, item?.quantity)

    // Test updating quantity
    val updated = repository.updateCartQuantity(item!!.cartItemId, 3)
    assertTrue(updated)
    val updatedItem = repository.cartItems.value.find { it.cartItemId == item.cartItemId }
    assertEquals(3, updatedItem?.quantity)

    // Updating beyond stock should cap or fail
    val overStock = repository.updateCartQuantity(item.cartItemId, product.stockQuantity + 50)
    assertFalse(overStock)
  }

  @Test
  fun testCouponApplication() {
    val (valid, _) = repository.applyCoupon("APNA150")
    assertTrue("APNA150 coupon should be valid", valid)
    assertNotNull(repository.appliedCoupon.value)
    assertEquals("APNA150", repository.appliedCoupon.value?.code)

    repository.removeCoupon()
    assertNull(repository.appliedCoupon.value)

    val (invalid, _) = repository.applyCoupon("UNKNOWN999")
    assertFalse("Invalid coupon code should be rejected", invalid)
  }

  @Test
  fun testDemoOrderPlacementAndSimulatedTracking() {
    val order = repository.placeDemoOrder("UPI (Google Pay / PhonePe)", "Standard")
    assertNotNull(order.orderId)
    assertTrue(order.orderId.startsWith("DEMO-APC-"))
    assertEquals(OrderStatus.DEMO_PLACED, order.currentStatus)

    // Advance simulated tracking
    repository.advanceTrackingStatus(order.orderId)
    val updatedOrder = repository.orders.value.find { it.orderId == order.orderId }
    assertEquals(OrderStatus.DEMO_PROCESSING, updatedOrder?.currentStatus)
  }

  @Test
  fun testAddressManagement() {
    val newAddress = Address(
      id = "addr_test_1",
      fullName = "Vikram Sharma",
      phone = "9876543210",
      houseNoBuilding = "Flat 402, Royal Palms",
      roadAreaColony = "100 Feet Road, Indiranagar",
      pincode = "560001",
      city = "Bengaluru",
      state = "Karnataka",
      isDefault = false
    )

    repository.addNewAddress(newAddress)
    assertTrue(repository.addresses.value.any { it.id == "addr_test_1" })

    repository.selectAddress(newAddress)
    assertEquals("addr_test_1", repository.selectedAddress.value.id)
  }

  @Test
  fun testAdminProductManagement() {
    val newProd = Product(
      id = "test_jeans_99",
      title = "Slim Stretch Demo Jeans",
      brand = "DenimKart",
      category = "jeans",
      price = 1499,
      originalMrp = 2999,
      rating = 4.4f,
      reviewCount = 80,
      description = "Test description",
      availableSizes = listOf("30", "32", "34"),
      availableColors = listOf("Blue", "Black"),
      stockQuantity = 25
    )

    repository.adminAddProduct(newProd)
    assertTrue(repository.products.value.any { it.id == "test_jeans_99" })

    // Update stock and price
    repository.adminUpdateStockAndPrice(productId = "test_jeans_99", newStock = 40, newPrice = 1299)
    val updated = repository.products.value.find { it.id == "test_jeans_99" }
    assertEquals(1299, updated?.price ?: 0)
    assertEquals(40, updated?.stockQuantity)

    // Delete product
    repository.adminDeleteProduct("test_jeans_99")
    assertFalse(repository.products.value.any { it.id == "test_jeans_99" })
  }

  @Test
  fun testLanguageSwitching() {
    repository.setLanguage(AppLanguage.HINDI)
    assertEquals(AppLanguage.HINDI, repository.currentLanguage.value)

    repository.setLanguage(AppLanguage.ENGLISH)
    assertEquals(AppLanguage.ENGLISH, repository.currentLanguage.value)
  }
}
